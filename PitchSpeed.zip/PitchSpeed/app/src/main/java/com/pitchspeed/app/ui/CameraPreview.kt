package com.pitchspeed.app.ui

import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.pitchspeed.app.camera.CaptureConfig

/**
 * 카메라 미리보기 (SurfaceView).
 *
 * Surface 크기를 촬영 해상도와 똑같이 고정한다 (고속 촬영 세션의 요구 조건).
 * Surface가 준비되면 onSurfaceReady, 사라지면 onSurfaceDestroyed가 불린다.
 * 앱이 백그라운드로 가면 Surface가 사라졌다가 돌아오면 다시 생기므로,
 * 카메라 열기/닫기를 이 두 콜백에 맞추면 생명주기가 자동으로 처리된다.
 */
@Composable
fun CameraPreview(
    config: CaptureConfig,
    modifier: Modifier,
    onSurfaceReady: (SurfaceView, Surface) -> Unit,
    onSurfaceDestroyed: () -> Unit
) {
    val currentOnReady by rememberUpdatedState(onSurfaceReady)
    val currentOnDestroyed by rememberUpdatedState(onSurfaceDestroyed)

    AndroidView(
        modifier = modifier.aspectRatio(
            ratio = config.width.toFloat() / config.height,
            matchHeightConstraintsFirst = true
        ),
        factory = { viewContext ->
            val view = SurfaceView(viewContext)
            view.holder.setFixedSize(config.width, config.height)
            view.holder.addCallback(object : SurfaceHolder.Callback {
                var ready = false

                override fun surfaceCreated(holder: SurfaceHolder) {
                }

                override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                    // 고정한 크기로 바뀐 뒤에 한 번만 알린다
                    if (!ready && width == config.width && height == config.height) {
                        ready = true
                        currentOnReady(view, holder.surface)
                    }
                }

                override fun surfaceDestroyed(holder: SurfaceHolder) {
                    if (ready) {
                        ready = false
                        currentOnDestroyed()
                    }
                }
            })
            view
        }
    )
}

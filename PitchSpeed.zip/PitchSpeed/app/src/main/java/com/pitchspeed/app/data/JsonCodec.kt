package com.pitchspeed.app.data

import android.content.Context
import com.pitchspeed.app.analysis.Calibration
import com.pitchspeed.app.analysis.LensModel
import com.pitchspeed.app.analysis.TrackPoint
import org.json.JSONArray
import org.json.JSONObject

/** 보정 정보와 분석 결과를 JSON 문자열로 바꾸고 되돌리는 함수들 */
object JsonCodec {

    fun calibrationToJson(c: Calibration): JSONObject {
        val json = JSONObject()
        json.put("ax", c.ax)
        json.put("ay", c.ay)
        json.put("bx", c.bx)
        json.put("by", c.by)
        json.put("realMeters", c.realMeters)
        json.put("imageWidth", c.imageWidth)
        json.put("imageHeight", c.imageHeight)
        json.put("useLensCorrection", c.useLensCorrection)
        val lens = c.lens
        if (lens != null) {
            val l = JSONObject()
            l.put("fx", lens.fx)
            l.put("fy", lens.fy)
            l.put("cx", lens.cx)
            l.put("cy", lens.cy)
            l.put("k1", lens.k1)
            l.put("k2", lens.k2)
            l.put("k3", lens.k3)
            l.put("p1", lens.p1)
            l.put("p2", lens.p2)
            l.put("activeWidth", lens.activeWidth)
            l.put("activeHeight", lens.activeHeight)
            json.put("lens", l)
        }
        return json
    }

    fun calibrationFromJson(json: JSONObject): Calibration {
        var lens: LensModel? = null
        if (json.has("lens")) {
            val l = json.getJSONObject("lens")
            lens = LensModel(
                fx = l.getDouble("fx"),
                fy = l.getDouble("fy"),
                cx = l.getDouble("cx"),
                cy = l.getDouble("cy"),
                k1 = l.getDouble("k1"),
                k2 = l.getDouble("k2"),
                k3 = l.getDouble("k3"),
                p1 = l.getDouble("p1"),
                p2 = l.getDouble("p2"),
                activeWidth = l.getInt("activeWidth"),
                activeHeight = l.getInt("activeHeight")
            )
        }
        return Calibration(
            ax = json.getDouble("ax"),
            ay = json.getDouble("ay"),
            bx = json.getDouble("bx"),
            by = json.getDouble("by"),
            realMeters = json.getDouble("realMeters"),
            imageWidth = json.getInt("imageWidth"),
            imageHeight = json.getInt("imageHeight"),
            lens = lens,
            useLensCorrection = json.getBoolean("useLensCorrection")
        )
    }

    /** 분석 결과 → JSON 문자열 (속도 값은 저장하지 않고, 불러올 때 점들로 다시 계산한다) */
    fun resultToJson(data: ResultData): String {
        val json = JSONObject()
        json.put("videoPath", data.videoPath)
        json.put("isImported", data.isImported)
        json.put("frameWidth", data.frameWidth)
        json.put("frameHeight", data.frameHeight)
        json.put("rotation", data.rotation)
        json.put("calibration", calibrationToJson(data.calibration))
        json.put("timestampsExact", data.timestampsExact)
        json.put("rollingShutterSkewNs", data.rollingShutterSkewNs)
        json.put("exposureNs", data.exposureNs)
        json.put("iso", data.iso)
        json.put("nominalFps", data.nominalFps)
        json.put("windowStartFrame", data.windowStartFrame)
        json.put("windowStartPtsUs", data.windowStartPtsUs)
        json.put("replayHalfRes", data.replayHalfRes)

        val times = JSONArray()
        for (time in data.windowTimesNs) {
            times.put(time)
        }
        json.put("windowTimesNs", times)

        val points = JSONArray()
        for (p in data.points) {
            val o = JSONObject()
            o.put("f", p.frameIndex)
            o.put("t", p.timeNs)
            o.put("x", p.x)
            o.put("y", p.y)
            o.put("m", p.isManual)
            points.put(o)
        }
        json.put("points", points)
        return json.toString()
    }

    fun resultFromJson(text: String): ResultData {
        val json = JSONObject(text)

        val timesJson = json.getJSONArray("windowTimesNs")
        val times = LongArray(timesJson.length())
        for (i in 0 until timesJson.length()) {
            times[i] = timesJson.getLong(i)
        }

        val pointsJson = json.getJSONArray("points")
        val points = ArrayList<TrackPoint>()
        for (i in 0 until pointsJson.length()) {
            val o = pointsJson.getJSONObject(i)
            points.add(
                TrackPoint(
                    frameIndex = o.getInt("f"),
                    timeNs = o.getLong("t"),
                    x = o.getDouble("x"),
                    y = o.getDouble("y"),
                    isManual = o.getBoolean("m")
                )
            )
        }

        return ResultData(
            videoPath = json.getString("videoPath"),
            isImported = json.getBoolean("isImported"),
            frameWidth = json.getInt("frameWidth"),
            frameHeight = json.getInt("frameHeight"),
            rotation = json.getInt("rotation"),
            calibration = calibrationFromJson(json.getJSONObject("calibration")),
            timestampsExact = json.getBoolean("timestampsExact"),
            rollingShutterSkewNs = json.getLong("rollingShutterSkewNs"),
            exposureNs = json.getLong("exposureNs"),
            iso = json.getInt("iso"),
            nominalFps = json.getInt("nominalFps"),
            windowStartFrame = json.getInt("windowStartFrame"),
            windowStartPtsUs = json.getLong("windowStartPtsUs"),
            windowTimesNs = times,
            replayHalfRes = json.getBoolean("replayHalfRes"),
            points = points,
            speed = null
        )
    }
}

/** 실시간 촬영용 거리 보정을 앱 설정에 저장해 두고 다음에도 쓴다 */
object CalibrationStore {
    private const val PREFS_NAME = "pitchspeed"
    private const val KEY_CALIBRATION = "live_calibration"

    fun save(context: Context, calibration: Calibration) {
        val text = JsonCodec.calibrationToJson(calibration).toString()
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CALIBRATION, text)
            .apply()
    }

    fun load(context: Context): Calibration? {
        val text = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CALIBRATION, null) ?: return null
        return try {
            JsonCodec.calibrationFromJson(JSONObject(text))
        } catch (e: Exception) {
            null
        }
    }
}

package com.pitchspeed.app.ui

import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// 앱 전체에서 쓰는 색
val ColorAccent = Color(0xFFFF5A36)     // 주황: 주요 버튼, 속도 숫자
val ColorSecondary = Color(0xFF3A3F4B)  // 회색: 보조 버튼
val ColorWarning = Color(0xFFFFD54F)    // 노랑: 경고
val ColorGood = Color(0xFF66BB6A)       // 초록: 정상
val ColorDim = Color(0xFFA0A4AD)        // 흐린 글자

private val DarkColors = darkColorScheme(
    primary = ColorAccent,
    onPrimary = Color.White,
    secondary = Color(0xFF4FC3F7),
    onSecondary = Color.Black,
    background = Color(0xFF101114),
    onBackground = Color(0xFFECECEC),
    surface = Color(0xFF1A1C21),
    onSurface = Color(0xFFECECEC),
    surfaceVariant = Color(0xFF262A32),
    onSurfaceVariant = Color(0xFFC8CCD4)
)

/** 다크 테마 고정 */
@Composable
fun PitchSpeedTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}

/** 큰 버튼 */
@Composable
fun BigButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    color: Color = ColorAccent
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 60.dp),
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
    ) {
        Text(text = text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

/** 작은 보조 버튼 */
@Composable
fun SmallButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    color: Color = ColorSecondary
) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp),
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White)
    ) {
        Text(text = text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** 셔터 속도를 "1/2000" 모양으로 */
fun formatShutter(exposureNs: Long): String {
    if (exposureNs <= 0L) return "-"
    val denominator = (1_000_000_000.0 / exposureNs).roundToInt()
    return "1/$denominator"
}

/** 소수 한 자리 */
fun formatOne(value: Double): String {
    if (value.isNaN()) return "-"
    return String.format("%.1f", value)
}

/** 소수 두 자리 */
fun formatTwo(value: Double): String {
    if (value.isNaN()) return "-"
    return String.format("%.2f", value)
}

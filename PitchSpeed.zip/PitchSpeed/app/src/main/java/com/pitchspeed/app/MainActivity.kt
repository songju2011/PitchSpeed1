package com.pitchspeed.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pitchspeed.app.data.AppSession
import com.pitchspeed.app.data.PitchDatabase
import com.pitchspeed.app.ui.AnalyzeScreen
import com.pitchspeed.app.ui.CalibCaptureScreen
import com.pitchspeed.app.ui.CalibrationScreen
import com.pitchspeed.app.ui.GuideScreen
import com.pitchspeed.app.ui.HistoryScreen
import com.pitchspeed.app.ui.HomeScreen
import com.pitchspeed.app.ui.MeasureScreen
import com.pitchspeed.app.ui.PitchSpeedTheme
import com.pitchspeed.app.ui.ResultScreen
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 측정 대기 중에 화면이 꺼지지 않게 한다
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // 상태바·내비게이션바 숨기기 (가로 화면을 넓게 쓴다)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())

        deleteUnsavedClips()

        setContent {
            PitchSpeedTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }

    /** 기록에 저장하지 않은 영상 파일은 앱을 켤 때 지운다 */
    private fun deleteUnsavedClips() {
        val clipDirectory = File(filesDir, "clips")
        lifecycleScope.launch(Dispatchers.IO) {
            val files = clipDirectory.listFiles()
            if (files != null) {
                val savedPaths = PitchDatabase.get(applicationContext).pitchDao().getAllVideoPaths()
                // 지금 화면에서 쓰고 있는 영상은 건드리지 않는다
                val inUse1 = AppSession.currentResult?.videoPath
                val inUse2 = AppSession.pendingClip?.videoPath
                for (file in files) {
                    val path = file.absolutePath
                    if (path == inUse1 || path == inUse2) continue
                    if (!savedPaths.contains(path)) {
                        file.delete()
                    }
                }
            }
        }
    }
}

/** 화면 이동 정의 */
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(navController) }                    // 시작 화면
        composable("guide") { GuideScreen(navController) }                  // 1. 촬영 가이드
        composable("calib_capture") { CalibCaptureScreen(navController) }   // 2-1. 보정용 화면 캡처
        composable("calibrate") { CalibrationScreen(navController) }        // 2-2. 거리 보정
        composable("measure") { MeasureScreen(navController) }              // 3. 측정 대기
        composable("analyze") { AnalyzeScreen(navController) }              // 분석 중
        composable("result") { ResultScreen(navController) }                // 4. 결과
        composable("history") { HistoryScreen(navController) }              // 5. 기록
    }
}

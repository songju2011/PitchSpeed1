package com.pitchspeed.app.analysis

import kotlin.math.abs

/**
 * 한 축(x 또는 y)에 대한 칼만 필터.
 * 상태는 [위치, 속도] 두 개이고, 가속도는 잡음으로 취급한다(등속 모델).
 * x축용 하나, y축용 하나를 따로 만들어서 쓴다.
 */
class Kalman1D(
    initialPosition: Double,
    initialVelocity: Double,
    measurementNoise: Double,   // 측정 잡음 표준편차 (픽셀)
    initialDt: Double           // 처음 두 점 사이 시간 (초) — 초기 속도 불확실성 계산용
) {
    var position = initialPosition
    var velocity = initialVelocity

    // 측정 잡음 분산
    private val r = measurementNoise * measurementNoise

    // 공분산 행렬 P (2x2, 대칭이라 3개만 저장)
    private var pPosPos = r
    private var pPosVel = r / initialDt
    private var pVelVel = 2.0 * r / (initialDt * initialDt)

    /**
     * dt초 뒤 상태를 예측한다.
     * 프레임 간격이 불규칙해도 실제 dt를 넣으면 된다.
     * accelNoise: 가속도 잡음 표준편차 (픽셀/초²)
     */
    fun predict(dt: Double, accelNoise: Double) {
        // 상태 예측: 위치 += 속도 * dt
        position += velocity * dt

        // 공분산 예측: P = F P F' + Q
        val newPosPos = pPosPos + 2.0 * dt * pPosVel + dt * dt * pVelVel
        val newPosVel = pPosVel + dt * pVelVel
        val newVelVel = pVelVel

        val q = accelNoise * accelNoise
        val adt = abs(dt)
        pPosPos = newPosPos + q * adt * adt * adt * adt / 4.0
        pPosVel = newPosVel + q * adt * adt * adt / 2.0 * (if (dt >= 0) 1.0 else -1.0)
        pVelVel = newVelVel + q * adt * adt
    }

    /** 측정값(공 중심 위치)으로 상태를 고친다 */
    fun update(measuredPosition: Double) {
        val innovation = measuredPosition - position
        val s = pPosPos + r
        val gainPos = pPosPos / s
        val gainVel = pPosVel / s

        position += gainPos * innovation
        velocity += gainVel * innovation

        val newPosPos = (1.0 - gainPos) * pPosPos
        val newPosVel = (1.0 - gainPos) * pPosVel
        val newVelVel = pVelVel - gainVel * pPosVel
        pPosPos = newPosPos
        pPosVel = newPosVel
        pVelVel = newVelVel
    }
}

package com.pitchspeed.app.camera

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Range
import android.view.Surface
import android.view.WindowManager
import com.pitchspeed.app.analysis.LensModel
import kotlin.math.roundToInt

/** 화면에 보여줄 카메라 상태 */
class CameraStatus(
    val measuredFps: Double,        // 센서 타임스탬프로 잰 실제 fps
    val exposureNs: Long,           // 실제 셔터 속도 (나노초)
    val iso: Int,
    val exposureLocked: Boolean,    // 노출이 고정됐는지 (고정된 뒤에 측정을 시작한다)
    val exposureModeText: String,
    val warning: String
)

/**
 * Camera2 카메라 제어.
 *
 * - 고속 촬영 세션(CameraConstrainedHighSpeedCaptureSession)을 열고
 * - 미리보기 Surface와 인코더 Surface로 프레임을 보내고
 * - 프레임마다 SENSOR_TIMESTAMP를 모아 두고
 * - 셔터 속도를 1/2000초 이하로 고정하려고 시도한다.
 *
 * 노출 고정 순서:
 *   1) 자동 노출로 1.5초 동안 밝기를 잰다.
 *   2) 수동 노출을 지원하면: 셔터 = 1/2000초 이하, ISO = 같은 밝기가 되도록 계산해서 고정.
 *   3) 수동 값이 실제로 적용됐는지 결과에서 확인한다.
 *      (고속 촬영에서는 수동 노출을 무시하는 기기가 많다)
 *   4) 무시됐으면: 자동 노출 + 노출 보정 -1EV로 셔터를 짧게 유도한 뒤 AE 잠금.
 */
class HighSpeedCameraController(private val context: Context) {

    /** 상태가 바뀔 때 메인 스레드에서 불린다 */
    var onStatus: ((CameraStatus) -> Unit)? = null

    /** 오류가 났을 때 메인 스레드에서 불린다 */
    var onError: ((String) -> Unit)? = null

    /** 렌즈 왜곡 모델 (기기가 값을 주고, 기기 스스로 보정하지 않을 때만) */
    var lensModel: LensModel? = null

    /** 녹화 영상을 똑바로 세우려면 돌려야 하는 각도 */
    var recordingRotation: Int = 0

    // 렌즈 초점거리 (센서 픽셀 단위). 0이면 모름
    private var focalSensorPx: Double = 0.0
    private var sensorActiveWidth: Int = 0
    private var sensorActiveHeight: Int = 0

    @Volatile var rollingShutterSkewNs: Long = 0L
    @Volatile var lastExposureNs: Long = 0L
    @Volatile var lastIso: Int = 0
    @Volatile var exposureLocked: Boolean = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var config: CaptureConfig? = null
    private var previewSurface: Surface? = null
    private var encoderSurface: Surface? = null
    @Volatile private var closed = true

    // ---- 기기 능력 ----
    private var manualSensorSupported = false
    private var exposureRangeLowerNs = 0L
    private var isoRangeUpper = 0
    private var isoRangeLower = 0
    private var compensationForMinusOneEv = 0
    private var distortionCorrectionMode = -1   // -1이면 지원 안 함

    // ---- 센서 타임스탬프 링 버퍼 ----
    private val timestampLock = Any()
    private val timestampRing = LongArray(TIMESTAMP_RING_SIZE)
    private var timestampCount = 0L

    // ---- fps 측정 ----
    private var fpsWindowStartNs = 0L
    private var fpsFrameCount = 0
    @Volatile private var measuredFps = 0.0

    // ---- 노출 단계 ----
    private var phase = PHASE_METERING
    private var phaseStartMs = 0L
    private var targetExposureNs = 0L
    private var targetIso = 0
    @Volatile private var exposureModeText = "노출 측정 중"
    @Volatile private var warning = ""

    companion object {
        private const val TIMESTAMP_RING_SIZE = 8192

        // 목표 셔터 속도: 1/2000초
        private const val TARGET_SHUTTER_NS = 500_000L

        private const val PHASE_METERING = 0        // 자동 노출로 밝기 재는 중
        private const val PHASE_MANUAL_CHECK = 1    // 수동 노출을 걸고 실제로 적용되는지 확인 중
        private const val PHASE_LOCKED_MANUAL = 2   // 수동 노출 고정 완료
        private const val PHASE_AUTO_SETTLE = 3     // 자동 노출(-1EV)이 안정되길 기다리는 중
        private const val PHASE_LOCKED_AUTO = 4     // 자동 노출 잠금 완료

        private const val EXPOSURE_AUTO = 0
        private const val EXPOSURE_MANUAL = 1
        private const val EXPOSURE_AUTO_DARKER = 2
        private const val EXPOSURE_AUTO_LOCKED = 3
    }

    // ------------------------------------------------------------------
    // 열기 / 닫기
    // ------------------------------------------------------------------

    /**
     * 카메라를 연다. encoderSurface가 null이면 미리보기만 한다 (거리 보정 화면용).
     * CAMERA 권한은 화면에 들어오기 전에 이미 받았다고 가정한다.
     */
    @SuppressLint("MissingPermission")
    fun open(config: CaptureConfig, previewSurface: Surface, encoderSurface: Surface?) {
        close()

        this.config = config
        this.previewSurface = previewSurface
        this.encoderSurface = encoderSurface
        closed = false
        exposureLocked = false
        exposureModeText = "노출 측정 중"
        warning = ""
        measuredFps = 0.0
        fpsWindowStartNs = 0L
        synchronized(timestampLock) {
            timestampCount = 0L
        }

        val thread = HandlerThread("camera")
        thread.start()
        cameraThread = thread
        val handler = Handler(thread.looper)
        cameraHandler = handler

        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            readCharacteristics(manager.getCameraCharacteristics(config.cameraId))
            manager.openCamera(config.cameraId, deviceCallback, handler)
        } catch (e: Exception) {
            reportError("카메라를 열 수 없습니다: " + e.message)
        }
    }

    fun close() {
        closed = true
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        try {
            device?.close()
        } catch (e: Exception) {
        }
        device = null
        cameraThread?.quitSafely()
        cameraThread = null
        cameraHandler = null
    }

    /**
     * 촬영 영상(가로 imageWidth × 세로 imageHeight) 픽셀 단위의 초점거리. 모르면 0.
     * 영상은 센서 활성 영역 가운데를 영상 비율로 잘라 축소한 것이라고 본다.
     */
    fun focalPxForImage(imageWidth: Int, imageHeight: Int): Double {
        if (focalSensorPx <= 0.0 || sensorActiveWidth <= 0 || sensorActiveHeight <= 0) return 0.0
        val scaleX = sensorActiveWidth.toDouble() / imageWidth
        val scaleY = sensorActiveHeight.toDouble() / imageHeight
        val sensorPerImagePixel = if (scaleX < scaleY) scaleX else scaleY
        return focalSensorPx / sensorPerImagePixel
    }

    /** 노출을 처음부터 다시 맞춘다 (밝기가 바뀌었을 때) */
    fun restartExposureMetering() {
        val handler = cameraHandler ?: return
        handler.post {
            if (!closed && session != null) {
                exposureLocked = false
                exposureModeText = "노출 측정 중"
                warning = ""
                enterPhase(PHASE_METERING)
                startRepeating(EXPOSURE_AUTO)
            }
        }
    }

    /** 최근 프레임들의 SENSOR_TIMESTAMP(나노초)를 시간 순서대로 돌려준다 */
    fun copyRecentSensorTimestamps(): LongArray {
        synchronized(timestampLock) {
            val available = if (timestampCount < TIMESTAMP_RING_SIZE) timestampCount.toInt() else TIMESTAMP_RING_SIZE
            val result = LongArray(available)
            val start = timestampCount - available
            for (i in 0 until available) {
                result[i] = timestampRing[((start + i) % TIMESTAMP_RING_SIZE).toInt()]
            }
            return result
        }
    }

    // ------------------------------------------------------------------
    // 기기 능력 읽기
    // ------------------------------------------------------------------

    private fun readCharacteristics(characteristics: CameraCharacteristics) {
        // 수동 노출 지원 여부
        manualSensorSupported = false
        val capabilities = characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
        if (capabilities != null) {
            for (capability in capabilities) {
                if (capability == CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) {
                    manualSensorSupported = true
                }
            }
        }
        val exposureRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val isoRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        if (exposureRange == null || isoRange == null) {
            manualSensorSupported = false
        } else {
            exposureRangeLowerNs = exposureRange.lower
            isoRangeLower = isoRange.lower
            isoRangeUpper = isoRange.upper
        }

        // 노출 보정 -1EV에 해당하는 값
        compensationForMinusOneEv = 0
        val compensationRange = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        val compensationStep = characteristics.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)
        if (compensationRange != null && compensationStep != null && compensationStep.toDouble() > 0.0) {
            var value = (-1.0 / compensationStep.toDouble()).roundToInt()
            if (value < compensationRange.lower) value = compensationRange.lower
            compensationForMinusOneEv = value
        }

        // 녹화 영상 회전 각도 = 센서 방향 - 화면 방향
        val sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        @Suppress("DEPRECATION")
        val displayRotation = (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        val displayDegrees = when (displayRotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
        recordingRotation = (sensorOrientation - displayDegrees + 360) % 360

        // 초점거리 (센서 픽셀): 렌즈 보정값이 있으면 그걸, 없으면 초점거리(mm) ÷ 센서 크기(mm) × 픽셀 수
        focalSensorPx = 0.0
        val activeForFocal = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        if (activeForFocal != null) {
            sensorActiveWidth = activeForFocal.width()
            sensorActiveHeight = activeForFocal.height()
        }
        if (Build.VERSION.SDK_INT >= 28) {
            val intrinsicsForFocal = characteristics.get(CameraCharacteristics.LENS_INTRINSIC_CALIBRATION)
            if (intrinsicsForFocal != null && intrinsicsForFocal.size >= 2 && intrinsicsForFocal[0] > 0f) {
                focalSensorPx = intrinsicsForFocal[0].toDouble()
            }
        }
        if (focalSensorPx <= 0.0) {
            val focalLengths = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            val physicalSize = characteristics.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val pixelArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
            if (focalLengths != null && focalLengths.isNotEmpty() && physicalSize != null && pixelArray != null &&
                physicalSize.width > 0f
            ) {
                val focalMm = focalLengths[0].toDouble()
                focalSensorPx = focalMm / physicalSize.width.toDouble() * pixelArray.width
            }
        }

        // 렌즈 왜곡
        lensModel = null
        distortionCorrectionMode = -1
        if (Build.VERSION.SDK_INT >= 28) {
            // 기기가 스스로 왜곡을 펴 주는 모드가 있으면 그걸 켠다 (그러면 앱에서 또 펴면 안 된다)
            val modes = characteristics.get(CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES)
            if (modes != null) {
                for (mode in modes) {
                    if (mode == CameraMetadata.DISTORTION_CORRECTION_MODE_HIGH_QUALITY) {
                        distortionCorrectionMode = mode
                    }
                }
                if (distortionCorrectionMode < 0) {
                    for (mode in modes) {
                        if (mode == CameraMetadata.DISTORTION_CORRECTION_MODE_FAST) {
                            distortionCorrectionMode = mode
                        }
                    }
                }
            }

            if (distortionCorrectionMode < 0) {
                // 기기가 안 펴 주면 LENS_DISTORTION, LENS_INTRINSIC_CALIBRATION 값으로 앱에서 편다
                val distortion = characteristics.get(CameraCharacteristics.LENS_DISTORTION)
                val intrinsics = characteristics.get(CameraCharacteristics.LENS_INTRINSIC_CALIBRATION)
                var activeArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_PRE_CORRECTION_ACTIVE_ARRAY_SIZE)
                if (activeArray == null) {
                    activeArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                }
                if (distortion != null && distortion.size >= 5 &&
                    intrinsics != null && intrinsics.size >= 4 &&
                    intrinsics[0] > 0f && intrinsics[1] > 0f && activeArray != null
                ) {
                    var anyNonZero = false
                    for (i in 0 until 5) {
                        if (distortion[i] != 0f) anyNonZero = true
                    }
                    if (anyNonZero) {
                        lensModel = LensModel(
                            fx = intrinsics[0].toDouble(),
                            fy = intrinsics[1].toDouble(),
                            cx = intrinsics[2].toDouble(),
                            cy = intrinsics[3].toDouble(),
                            k1 = distortion[0].toDouble(),
                            k2 = distortion[1].toDouble(),
                            k3 = distortion[2].toDouble(),
                            p1 = distortion[3].toDouble(),
                            p2 = distortion[4].toDouble(),
                            activeWidth = activeArray.width(),
                            activeHeight = activeArray.height()
                        )
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // 카메라 / 세션 콜백
    // ------------------------------------------------------------------

    private val deviceCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            if (closed) {
                camera.close()
                return
            }
            device = camera
            createSession(camera)
        }

        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            device = null
        }

        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            device = null
            reportError("카메라 오류 (코드 $error)")
        }
    }

    @Suppress("DEPRECATION")
    private fun createSession(camera: CameraDevice) {
        val currentConfig = config ?: return
        val preview = previewSurface ?: return
        val surfaces = ArrayList<Surface>()
        surfaces.add(preview)
        val encoder = encoderSurface
        if (encoder != null) {
            surfaces.add(encoder)
        }
        try {
            if (currentConfig.isHighSpeed) {
                // 고속 촬영 세션: 미리보기 + 인코더 Surface만 쓸 수 있다
                camera.createConstrainedHighSpeedCaptureSession(surfaces, sessionCallback, cameraHandler)
            } else {
                camera.createCaptureSession(surfaces, sessionCallback, cameraHandler)
            }
        } catch (e: Exception) {
            reportError("카메라 세션을 만들 수 없습니다: " + e.message)
        }
    }

    private val sessionCallback = object : CameraCaptureSession.StateCallback() {
        override fun onConfigured(newSession: CameraCaptureSession) {
            if (closed) {
                newSession.close()
                return
            }
            session = newSession
            enterPhase(PHASE_METERING)
            startRepeating(EXPOSURE_AUTO)
        }

        override fun onConfigureFailed(failedSession: CameraCaptureSession) {
            reportError("카메라 세션 구성에 실패했습니다")
        }
    }

    // ------------------------------------------------------------------
    // 촬영 요청
    // ------------------------------------------------------------------

    private fun startRepeating(exposureMode: Int) {
        val camera = device ?: return
        val currentSession = session ?: return
        val currentConfig = config ?: return
        val preview = previewSurface ?: return
        val encoder = encoderSurface

        try {
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            builder.addTarget(preview)
            if (encoder != null) {
                builder.addTarget(encoder)
            }

            builder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)

            // fps 범위: 녹화할 때는 고정, 미리보기만 할 때는 아래쪽이 낮은 범위
            val fpsLower = if (encoder != null) currentConfig.fps else currentConfig.previewOnlyFpsLower
            builder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(fpsLower, currentConfig.fps))

            // 전자식 손떨림 보정은 화면을 변형시키므로 끈다 (삼각대 고정이 전제)
            builder.set(
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            )
            builder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)

            if (Build.VERSION.SDK_INT >= 28 && distortionCorrectionMode >= 0) {
                builder.set(CaptureRequest.DISTORTION_CORRECTION_MODE, distortionCorrectionMode)
            }

            if (exposureMode == EXPOSURE_AUTO) {
                builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            } else if (exposureMode == EXPOSURE_MANUAL) {
                // 셔터·ISO 수동 고정
                builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
                builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, targetExposureNs)
                builder.set(CaptureRequest.SENSOR_SENSITIVITY, targetIso)
                builder.set(CaptureRequest.SENSOR_FRAME_DURATION, 1_000_000_000L / currentConfig.fps)
            } else if (exposureMode == EXPOSURE_AUTO_DARKER) {
                builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
                builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, compensationForMinusOneEv)
            } else if (exposureMode == EXPOSURE_AUTO_LOCKED) {
                builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
                builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, compensationForMinusOneEv)
                builder.set(CaptureRequest.CONTROL_AE_LOCK, true)
            }

            if (currentConfig.isHighSpeed) {
                val highSpeedSession = currentSession as CameraConstrainedHighSpeedCaptureSession
                val requests = highSpeedSession.createHighSpeedRequestList(builder.build())
                highSpeedSession.setRepeatingBurst(requests, captureCallback, cameraHandler)
            } else {
                currentSession.setRepeatingRequest(builder.build(), captureCallback, cameraHandler)
            }
        } catch (e: CameraAccessException) {
            reportError("촬영을 시작할 수 없습니다: " + e.message)
        } catch (e: IllegalStateException) {
            // 닫히는 중이면 무시
        } catch (e: IllegalArgumentException) {
            reportError("이 기기가 받아들이지 않는 촬영 설정입니다: " + e.message)
        }
    }

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            if (closed) return
            handleResult(result)
        }
    }

    /** 프레임 하나의 촬영 결과 처리 (카메라 스레드) */
    private fun handleResult(result: TotalCaptureResult) {
        // 1) 센서 타임스탬프 저장 — 속도 계산의 시간 기준
        val timestamp = result.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
        synchronized(timestampLock) {
            timestampRing[(timestampCount % TIMESTAMP_RING_SIZE).toInt()] = timestamp
            timestampCount++
        }

        // 2) 실제 적용된 노출 값
        val exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
        if (exposure != null) lastExposureNs = exposure
        val iso = result.get(CaptureResult.SENSOR_SENSITIVITY)
        if (iso != null) lastIso = iso
        val skew = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW)
        if (skew != null) rollingShutterSkewNs = skew

        // 3) 실제 fps: 0.25초마다 타임스탬프 차이로 계산
        if (fpsWindowStartNs == 0L) {
            fpsWindowStartNs = timestamp
            fpsFrameCount = 0
        } else {
            fpsFrameCount++
            val elapsed = timestamp - fpsWindowStartNs
            if (elapsed >= 250_000_000L) {
                measuredFps = fpsFrameCount * 1e9 / elapsed
                fpsWindowStartNs = timestamp
                fpsFrameCount = 0
                advanceExposurePhase()
                postStatus()
            }
        }
    }

    // ------------------------------------------------------------------
    // 노출 고정 단계 진행
    // ------------------------------------------------------------------

    private fun enterPhase(newPhase: Int) {
        phase = newPhase
        phaseStartMs = SystemClock.elapsedRealtime()
    }

    private fun advanceExposurePhase() {
        val elapsedMs = SystemClock.elapsedRealtime() - phaseStartMs

        if (phase == PHASE_METERING) {
            if (elapsedMs < 1500) return
            val meteredExposure = lastExposureNs
            val meteredIso = lastIso

            if (manualSensorSupported && meteredExposure > 0 && meteredIso > 0) {
                // 셔터는 1/2000초 이하. 이미 더 짧으면 그대로 둔다.
                var shutter = if (meteredExposure < TARGET_SHUTTER_NS) meteredExposure else TARGET_SHUTTER_NS
                if (shutter < exposureRangeLowerNs) shutter = exposureRangeLowerNs

                // 셔터를 줄인 만큼 ISO를 올려서 밝기를 맞춘다
                var isoNeeded = (meteredIso.toDouble() * meteredExposure / shutter).roundToInt()
                warning = ""
                if (isoNeeded > isoRangeUpper) {
                    isoNeeded = isoRangeUpper
                    warning = "빛이 부족해서 화면이 어둡습니다. 더 밝은 곳에서 찍으세요."
                }
                if (isoNeeded < isoRangeLower) isoNeeded = isoRangeLower

                targetExposureNs = shutter
                targetIso = isoNeeded
                exposureModeText = "수동 노출 확인 중"
                enterPhase(PHASE_MANUAL_CHECK)
                startRepeating(EXPOSURE_MANUAL)
            } else {
                startAutoFallback()
            }
        } else if (phase == PHASE_MANUAL_CHECK) {
            if (elapsedMs < 800) return
            // 요청한 셔터 속도가 실제로 적용됐는지 확인
            if (lastExposureNs > 0 && lastExposureNs <= targetExposureNs * 3 / 2) {
                exposureModeText = "수동 고정"
                exposureLocked = true
                enterPhase(PHASE_LOCKED_MANUAL)
            } else {
                startAutoFallback()
            }
        } else if (phase == PHASE_AUTO_SETTLE) {
            if (elapsedMs < 1200) return
            startRepeating(EXPOSURE_AUTO_LOCKED)
            exposureModeText = "자동 노출 잠금 (기기가 수동 셔터 미지원)"
            if (lastExposureNs > TARGET_SHUTTER_NS * 2) {
                warning = "셔터가 느려서 공이 번져 찍힐 수 있습니다. 더 밝은 곳에서 찍으세요."
            }
            exposureLocked = true
            enterPhase(PHASE_LOCKED_AUTO)
        }
    }

    private fun startAutoFallback() {
        exposureModeText = "자동 노출 조정 중"
        enterPhase(PHASE_AUTO_SETTLE)
        startRepeating(EXPOSURE_AUTO_DARKER)
    }

    // ------------------------------------------------------------------
    // 메인 스레드로 알리기
    // ------------------------------------------------------------------

    private fun postStatus() {
        val status = CameraStatus(
            measuredFps = measuredFps,
            exposureNs = lastExposureNs,
            iso = lastIso,
            exposureLocked = exposureLocked,
            exposureModeText = exposureModeText,
            warning = warning
        )
        mainHandler.post {
            if (!closed) {
                onStatus?.invoke(status)
            }
        }
    }

    private fun reportError(message: String) {
        mainHandler.post {
            onError?.invoke(message)
        }
    }
}

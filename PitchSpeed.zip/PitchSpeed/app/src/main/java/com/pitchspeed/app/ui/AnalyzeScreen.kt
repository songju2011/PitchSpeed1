package com.pitchspeed.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.analysis.PitchAnalyzer
import com.pitchspeed.app.data.AppSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 분석 중 화면: 백그라운드 스레드에서 공 추적과 속도 계산을 돌리고 진행률을 보여준다 */
@Composable
fun AnalyzeScreen(navController: NavController) {
    val context = LocalContext.current
    var progress by remember { mutableFloatStateOf(0f) }
    var progressText by remember { mutableStateOf("분석 준비 중") }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val clip = AppSession.pendingClip
        val calibration = AppSession.pendingCalibration
        if (clip == null || calibration == null) {
            failed = true
            return@LaunchedEffect
        }

        val result = withContext(Dispatchers.Default) {
            PitchAnalyzer.analyze(context.applicationContext, clip, calibration) { fraction, text ->
                progress = fraction
                progressText = text
            }
        }

        if (result == null) {
            failed = true
        } else {
            AppSession.currentResult = result
            AppSession.currentRecordId = -1L
            AppSession.currentMemo = ""
            AppSession.currentDateMillis = System.currentTimeMillis()
            AppSession.pendingClip = null
            navController.navigate("result") {
                popUpTo("analyze") { inclusive = true }
            }
        }
    }

    if (failed) {
        MessageScreen(text = "영상을 분석할 수 없습니다.", onBack = { navController.popBackStack() })
        return
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = "분석 중", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.width(360.dp)
            )
            Text(text = progressText, fontSize = 16.sp, color = ColorDim)
        }
    }
}

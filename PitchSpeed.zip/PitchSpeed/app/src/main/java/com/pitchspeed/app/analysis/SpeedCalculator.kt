package com.pitchspeed.app.analysis

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.sqrt

/** 속도 계산 입력 */
class SpeedInput(
    val timeNs: LongArray,          // 각 점의 시간 (나노초, 시간 순서대로)
    val x: DoubleArray,             // 각 점의 x (렌즈 왜곡 보정된 픽셀)
    val y: DoubleArray,             // 각 점의 y
    val metersPerPixel: Double,     // 기준선 깊이에서의 픽셀당 미터
    val refAx: Double,              // 기준선 점 A (왜곡 보정된 픽셀)
    val refAy: Double,
    val refBx: Double,              // 기준선 점 B
    val refBy: Double,
    val timestampsExact: Boolean,   // 센서 타임스탬프를 썼으면 true, 영상 파일 시간이면 false
    val diameterPx: DoubleArray? = null,    // 각 점에서 잰 공 지름 (픽셀). 0이면 모르는 점
    val focalPx: Double = 0.0,              // 렌즈 초점거리 (영상 픽셀). 0이면 깊이 보정을 안 함
    val focalRelativeError: Double = 0.2,   // 초점거리의 상대 오차 (기기 값 0.05, 추정값 0.2)
    val centerX: Double = 0.0,              // 영상 중심 (렌즈 광축이 지나는 점)
    val centerY: Double = 0.0
)

/** 속도 계산 결과 */
class SpeedResult(
    val ok: Boolean,
    val message: String,
    val releaseKmh: Double,             // 릴리스 직후 속도 (추적 시작 시점의 순간 속도)
    val averageKmh: Double,             // 추적 구간 평균 속도
    val gateKmh: Double,                // 기준선 통과 시각(프레임 사이 보간)으로 잰 구간 속도. 없으면 NaN
    val gateUsesReferenceLine: Boolean, // true면 보정 때 찍은 두 점을 게이트로 쓴 것
    val errorKmh: Double,               // 예상 오차 ± (약 95% 수준)
    val errorCalibrationKmh: Double,    // 그중 거리 보정에서 오는 몫
    val errorTimingKmh: Double,         // 그중 시간(fps)에서 오는 몫
    val errorFitKmh: Double,            // 그중 궤적 피팅 잔차에서 오는 몫
    val errorDepthKmh: Double,          // 그중 깊이(비스듬히 던짐) 보정에서 오는 몫
    val residualRmsPx: Double,          // 피팅 잔차 (픽셀)
    val usedPointCount: Int,
    val measuredFps: Double,            // 타임스탬프로 잰 실제 fps
    val releaseModel: String,           // 릴리스 속도를 구한 방법 설명
    val outliers: BooleanArray,         // 입력 점마다 이상치 여부
    val sizeChangePercent: Double,      // 추적 구간에서 공 크기가 변한 비율 (%). 커지면 +, 작아지면 -
    val depthCorrected: Boolean,        // 깊이(비스듬히 던짐) 보정을 적용했는지
    val throwAngleDeg: Double,          // 화면과 공 진행 방향 사이 각도 (+ = 카메라 쪽으로 옴)
    val depthWarning: Boolean           // 비스듬히 던졌는데 보정을 못 했으면 true
)

object SpeedCalculator {

    const val KMH_PER_MPH = 1.609344

    // 공기 저항으로 속도가 줄어드는 비율 (1/m). 야구공은 18.44m 가는 동안 약 9~10% 느려진다.
    private const val DRAG_PER_METER = 0.0055

    // 깊이 보정을 못 했을 때, 공 크기가 이 비율(%) 이상 변하면 경고한다
    private const val DEPTH_WARNING_PERCENT = 8.0

    // 보정 점을 찍을 때 손가락 오차 (픽셀, 점 하나당)
    private const val TAP_ERROR_PX = 1.5

    fun kmhToMph(kmh: Double): Double {
        return kmh / KMH_PER_MPH
    }

    private fun fail(message: String, n: Int): SpeedResult {
        return SpeedResult(
            ok = false,
            message = message,
            releaseKmh = Double.NaN,
            averageKmh = Double.NaN,
            gateKmh = Double.NaN,
            gateUsesReferenceLine = false,
            errorKmh = Double.NaN,
            errorCalibrationKmh = Double.NaN,
            errorTimingKmh = Double.NaN,
            errorFitKmh = Double.NaN,
            errorDepthKmh = Double.NaN,
            residualRmsPx = Double.NaN,
            usedPointCount = 0,
            measuredFps = Double.NaN,
            releaseModel = "",
            outliers = BooleanArray(n),
            sizeChangePercent = Double.NaN,
            depthCorrected = false,
            throwAngleDeg = Double.NaN,
            depthWarning = false
        )
    }

    fun calculate(input: SpeedInput): SpeedResult {
        val n = input.timeNs.size
        val mpp = input.metersPerPixel
        if (mpp <= 0.0) return fail("거리 보정이 올바르지 않습니다", n)
        if (n < 3) return fail("공 위치가 3개 이상 필요합니다 (현재 ${n}개)", n)

        // 초 단위 시간
        val t = DoubleArray(n)
        for (i in 0 until n) {
            t[i] = (input.timeNs[i] - input.timeNs[0]) / 1e9
        }
        val tMid = (t[0] + t[n - 1]) / 2.0

        // ---------- 1. 깊이 모델: 공 크기로 카메라까지 거리 변화를 구한다 ----------
        // 카메라까지 거리 Z 는 화면 속 공 지름에 반비례한다. 그래서 u = 1/지름 은 Z에 정비례한다.
        // u(t)를 시간에 대해 2차식으로 피팅해서(잡음 제거 + 공기 저항으로 느려지는 것 반영) 쓰고,
        // 아래 2단계에서 실제 미터로 바꾸는 배율(depthScaleM)을 정한다.
        var depthCorrected = false
        var sizeChangePercent = Double.NaN
        var uFit: PolyFitResult? = null     // u(t) = 1/지름 을 시간에 대해 피팅한 식
        var uSlopeStdError = 0.0

        val diameters = input.diameterPx
        if (diameters != null && diameters.size == n) {
            val keep = BooleanArray(n)
            var keepCount = 0
            for (i in 0 until n) {
                if (diameters[i] > 0.5) {
                    keep[i] = true
                    keepCount++
                }
            }
            var fit: PolyFitResult? = null
            // 크기 잡음이 큰 점을 빼면서 두 번 피팅한다
            for (round in 0 until 3) {
                if (keepCount < 8) {
                    fit = null
                    break
                }
                val ft = DoubleArray(keepCount)
                val fu = DoubleArray(keepCount)
                var k = 0
                for (i in 0 until n) {
                    if (keep[i]) {
                        ft[k] = t[i]
                        fu[k] = 1.0 / diameters[i]
                        k++
                    }
                }
                // 점이 충분하면 2차식: 공기 저항으로 공이 느려지는 것까지 따라간다
                val degree = if (keepCount >= 20) 2 else 1
                fit = PolyFit.fit(ft, fu, degree) ?: break
                if (round == 2) break
                val sigma = sqrt(fit.residualVariance())
                if (sigma.isNaN() || sigma <= 0.0) break
                var removed = 0
                for (i in 0 until n) {
                    if (!keep[i]) continue
                    val residual = 1.0 / diameters[i] - fit.valueAt(t[i])
                    if (abs(residual) > 3.0 * sigma) {
                        keep[i] = false
                        removed++
                    }
                }
                keepCount -= removed
                if (removed == 0) break
            }

            if (fit != null) {
                val uStart = fit.valueAt(t[0])
                val uEnd = fit.valueAt(t[n - 1])
                if (uStart > 0.0 && uEnd > 0.0) {
                    // 지름은 1/u 이므로 크기 변화 = uStart / uEnd - 1
                    sizeChangePercent = (uStart / uEnd - 1.0) * 100.0
                    if (input.focalPx > 0.0) {
                        uFit = fit
                        val sigma2 = fit.residualVariance()
                        // 첫 점 시각에서 u 기울기의 표준오차 (깊이 속도 오차 계산용)
                        uSlopeStdError = if (sigma2.isNaN()) 0.0 else sqrt(fit.derivativeVarianceAt(t[0], sigma2))
                        depthCorrected = true
                    }
                }
            }
        }

        // ---------- 2. 3D 위치 (미터) ----------
        // 카메라 좌표: X 오른쪽, Y 아래, Z 카메라에서 멀어지는 쪽.
        // 깊이 보정을 하면: Z = depthScaleM × u(t),  X = (x - 중심x) / 초점거리 × Z,  Y도 같은 식.
        // depthScaleM(= u 한 단위가 몇 m인지)은 기준선 길이로 정한다.
        //   방법 1 (기준선이 공 경로 위에 있을 때):
        //     공이 기준점 A, B의 가로 위치를 지나는 순간의 깊이를 A, B의 깊이로 보고,
        //     A~B 사이 3D 거리가 실제 거리와 같아지게 배율을 정한다. 비스듬한 기준선도 그대로 맞는다.
        //   방법 2 (공이 기준점을 안 지나갈 때):
        //     공 경로 가운데 시각의 깊이를 기준선 깊이(= 초점거리 × 픽셀당 미터)로 본다.
        val focal = input.focalPx
        val uMid = if (uFit != null) uFit.valueAt(tMid) else 0.0
        var depthScaleM = 0.0
        var depthAnchor = ""
        var refA3 = doubleArrayOf((input.refAx - input.centerX) * mpp, (input.refAy - input.centerY) * mpp, 0.0)
        var refB3 = doubleArrayOf((input.refBx - input.centerX) * mpp, (input.refBy - input.centerY) * mpp, 0.0)
        val referenceMeters = mpp * sqrt(
            (input.refBx - input.refAx) * (input.refBx - input.refAx) +
                    (input.refBy - input.refAy) * (input.refBy - input.refAy)
        )

        if (depthCorrected && uMid > 0.0) {
            // 방법 1: 공이 A, B의 가로 위치를 지나간 시각 (앞뒤 프레임 보간)
            val timeAtA = crossingTime(input.x, t, input.refAx)
            val timeAtB = crossingTime(input.x, t, input.refBx)
            var anchored = false
            if (!timeAtA.isNaN() && !timeAtB.isNaN() && timeAtA != timeAtB) {
                val uA = uFit!!.valueAt(timeAtA)
                val uB = uFit!!.valueAt(timeAtB)
                if (uA > 0.0 && uB > 0.0) {
                    // 배율 1일 때의 A, B 3D 위치
                    val axU = (input.refAx - input.centerX) / focal * uA
                    val ayU = (input.refAy - input.centerY) / focal * uA
                    val bxU = (input.refBx - input.centerX) / focal * uB
                    val byU = (input.refBy - input.centerY) / focal * uB
                    val dx = bxU - axU
                    val dy = byU - ayU
                    val dz = uB - uA
                    val lengthU = sqrt(dx * dx + dy * dy + dz * dz)
                    if (lengthU > 0.0) {
                        depthScaleM = referenceMeters / lengthU
                        refA3 = doubleArrayOf(axU * depthScaleM, ayU * depthScaleM, (uA - uMid) * depthScaleM)
                        refB3 = doubleArrayOf(bxU * depthScaleM, byU * depthScaleM, (uB - uMid) * depthScaleM)
                        depthAnchor = "기준선 위치"
                        anchored = true
                    }
                }
            }
            if (!anchored) {
                // 방법 2
                depthScaleM = focal * mpp / uMid
                depthAnchor = "경로 가운데"
            }
        }

        val xm = DoubleArray(n)
        val ym = DoubleArray(n)
        val zm = DoubleArray(n)
        for (i in 0 until n) {
            if (depthCorrected) {
                val u = uFit!!.valueAt(t[i])
                xm[i] = (input.x[i] - input.centerX) / focal * u * depthScaleM
                ym[i] = (input.y[i] - input.centerY) / focal * u * depthScaleM
                zm[i] = (u - uMid) * depthScaleM    // 경로 가운데 깊이를 0으로
            } else {
                xm[i] = (input.x[i] - input.centerX) * mpp
                ym[i] = (input.y[i] - input.centerY) * mpp
                zm[i] = 0.0
            }
        }

        // 이상치 판정에 쓸 "1픽셀이 몇 m인지" (깊이 보정을 하면 경로 가운데 기준)
        val pixelM = if (depthCorrected) uMid * depthScaleM / focal else mpp

        // ---------- 3. 이상치 제거 ----------
        // 피팅 → 잔차 → 중앙값 기준으로 크게 벗어난 점 제거 → 다시 피팅 (최대 3번)
        val inlier = BooleanArray(n) { true }
        for (round in 0 until 3) {
            val idx = inlierIndices(inlier)
            if (idx.size < 4) break
            val degree = if (idx.size >= 8) 2 else 1
            val tt = DoubleArray(idx.size) { t[idx[it]] }
            val fitX = PolyFit.fit(tt, DoubleArray(idx.size) { xm[idx[it]] }, degree) ?: break
            val fitY = PolyFit.fit(tt, DoubleArray(idx.size) { ym[idx[it]] }, degree) ?: break

            val residuals = DoubleArray(idx.size)
            for (k in idx.indices) {
                val rx = xm[idx[k]] - fitX.valueAt(tt[k])
                val ry = ym[idx[k]] - fitY.valueAt(tt[k])
                residuals[k] = sqrt(rx * rx + ry * ry)
            }
            val sorted = residuals.copyOf()
            sorted.sort()
            val median = sorted[sorted.size / 2]
            var limit = 3.0 * 1.4826 * median
            val minimumLimit = 0.75 * pixelM   // 0.75픽셀 이내는 이상치로 보지 않는다
            if (limit < minimumLimit) limit = minimumLimit

            var removeCount = 0
            for (k in idx.indices) {
                if (residuals[k] > limit) removeCount++
            }
            if (removeCount == 0) break
            // 너무 많이 버리게 되면 그만둔다
            val minimumKeep = if ((n + 1) / 2 > 3) (n + 1) / 2 else 3
            if (idx.size - removeCount < minimumKeep) break
            for (k in idx.indices) {
                if (residuals[k] > limit) inlier[idx[k]] = false
            }
        }

        val idx = inlierIndices(inlier)
        val count = idx.size
        if (count < 3) return fail("쓸 수 있는 공 위치가 부족합니다", n)

        // 첫 번째 점의 시간을 0으로 맞춘다 → t=0 에서의 기울기가 곧 "추적 시작 시점 속도"
        val tt = DoubleArray(count) { t[idx[it]] - t[idx[0]] }
        val xx = DoubleArray(count) { xm[idx[it]] }
        val yy = DoubleArray(count) { ym[idx[it]] }
        val zz = DoubleArray(count) { zm[idx[it]] }
        val span = tt[count - 1]
        if (span <= 0.0) return fail("시간 정보가 올바르지 않습니다", n)

        // 깊이 방향 속도 (m/s): Z = depthScaleM × u(t) 이므로 dZ/dt = depthScaleM × u'(t)
        var depthSpeed = 0.0
        var depthSpeedSigma = 0.0
        if (depthCorrected) {
            // 첫 점(릴리스 쪽) 시각의 깊이 방향 속도
            depthSpeed = depthScaleM * uFit!!.derivativeAt(t[idx[0]])
            // 크기 잡음에서 오는 몫 + 초점거리 오차에서 오는 몫
            val fromSize = depthScaleM * uSlopeStdError
            val fromFocal = abs(depthSpeed) * input.focalRelativeError
            depthSpeedSigma = sqrt(fromSize * fromSize + fromFocal * fromFocal)
        }

        // ---------- 4. 평균 속도: 궤적 전체를 직선으로 피팅 ----------
        val lineX = PolyFit.fit(tt, xx, 1) ?: return fail("직선 피팅 실패", n)
        val lineY = PolyFit.fit(tt, yy, 1) ?: return fail("직선 피팅 실패", n)
        val lineZ = PolyFit.fit(tt, zz, 1) ?: return fail("직선 피팅 실패", n)
        val averageSpeed = sqrt(
            lineX.coef[1] * lineX.coef[1] + lineY.coef[1] * lineY.coef[1] + lineZ.coef[1] * lineZ.coef[1]
        )

        // 잔차 분산의 바닥값: 0.1픽셀 (이보다 정밀하다고 믿지 않는다)
        val floorVariance = (0.1 * pixelM) * (0.1 * pixelM)

        var lineVariance = floorVariance
        if (count > 2) {
            val v = (lineX.sse + lineY.sse) / (2.0 * (count - 2))
            if (v > lineVariance) lineVariance = v
        }

        // ---------- 5. 릴리스 직후 속도 ----------
        // 점이 충분하면 포물선(시간에 대한 2차식)으로 피팅해서 시작 시점의 순간 속도를 구한다.
        // 공은 날아가면서 느려지므로, 시작 시점 속도가 스피드건 수치에 가깝다.
        var releaseSpeed = Double.NaN
        var releaseVariance = Double.NaN
        var releaseModel = ""
        var releaseLateral = 0.0    // 화면 방향(가로·세로) 속도 크기
        var residualSse = lineX.sse + lineY.sse

        if (count >= 8) {
            val parabolaX = PolyFit.fit(tt, xx, 2)
            val parabolaY = PolyFit.fit(tt, yy, 2)
            val parabolaZ = PolyFit.fit(tt, zz, 2)
            if (parabolaX != null && parabolaY != null && parabolaZ != null) {
                val vx0 = parabolaX.coef[1]
                val vy0 = parabolaY.coef[1]
                val vz0 = parabolaZ.coef[1]
                val v0 = sqrt(vx0 * vx0 + vy0 * vy0 + vz0 * vz0)

                var variance = (parabolaX.sse + parabolaY.sse) / (2.0 * (count - 3))
                if (variance < floorVariance) variance = floorVariance
                val v0Variance = parabolaX.derivativeVarianceAt(0.0, variance) +
                        parabolaY.derivativeVarianceAt(0.0, variance)

                // 진행 방향 가속도 (m/s²). 공기 저항이면 약 -5 ~ -12 정도가 정상.
                var alongAcceleration = 0.0
                if (v0 > 0.0) {
                    alongAcceleration = (2.0 * parabolaX.coef[2] * vx0 +
                            2.0 * parabolaY.coef[2] * vy0 +
                            2.0 * parabolaZ.coef[2] * vz0) / v0
                }

                // 물리적으로 말이 되고, 충분히 정밀할 때만 포물선 결과를 쓴다
                val physical = alongAcceleration > -40.0 && alongAcceleration < 5.0
                val precise = sqrt(v0Variance) * 3.6 <= 3.0
                val consistent = v0 > averageSpeed * 0.9 && v0 < averageSpeed * 1.25
                if (physical && precise && consistent) {
                    releaseSpeed = v0
                    releaseVariance = v0Variance
                    releaseModel = "포물선 피팅"
                    releaseLateral = sqrt(vx0 * vx0 + vy0 * vy0)
                    residualSse = parabolaX.sse + parabolaY.sse
                }
            }
        }

        if (releaseSpeed.isNaN()) {
            // 포물선을 못 쓰면: 평균 속도에 공기 저항 모델을 적용해서 시작 시점 속도로 환산한다
            val pathLength = averageSpeed * span
            releaseSpeed = averageSpeed * exp(DRAG_PER_METER * pathLength / 2.0)
            val lineSpeedVariance = lineX.derivativeVarianceAt(0.0, lineVariance) +
                    lineY.derivativeVarianceAt(0.0, lineVariance)
            // 환산값 자체의 불확실성(보정량의 30%)도 더한다
            val modelUncertainty = 0.3 * (releaseSpeed - averageSpeed)
            releaseVariance = lineSpeedVariance + modelUncertainty * modelUncertainty
            releaseModel = "직선 피팅 + 공기저항 환산"
            releaseLateral = sqrt(lineX.coef[1] * lineX.coef[1] + lineY.coef[1] * lineY.coef[1]) *
                    (releaseSpeed / averageSpeed)
        }
        if (depthCorrected) {
            releaseModel += " + 깊이 보정(" + depthAnchor + ")"
        }

        val residualRmsPx = sqrt(residualSse / count) / pixelM

        // 공 진행 방향과 화면 사이 각도 (+ = 카메라 쪽으로 다가옴 = Z가 줄어듦)
        var throwAngleDeg = 0.0
        if (depthCorrected && releaseLateral > 0.0) {
            throwAngleDeg = Math.toDegrees(atan2(-depthSpeed, releaseLateral))
        }

        // ---------- 6. 실제 fps (타임스탬프 간격의 중앙값) ----------
        val gaps = DoubleArray(n - 1) { t[it + 1] - t[it] }
        gaps.sort()
        val medianGap = gaps[gaps.size / 2]
        val measuredFps = if (medianGap > 0.0) 1.0 / medianGap else Double.NaN

        // ---------- 7. 기준선 통과 시각 보간 (게이트 속도) ----------
        // 3D 진행 방향 축 위에 선 두 개를 긋고, 공이 각 선을 지나는 시각을
        // 앞뒤 프레임 위치로 보간해서 프레임 간격보다 잘게 구한다.
        val firstX = xx[0]
        val firstY = yy[0]
        val firstZ = zz[0]
        val travelDx = xx[count - 1] - firstX
        val travelDy = yy[count - 1] - firstY
        val travelDz = zz[count - 1] - firstZ
        val travelLength = sqrt(travelDx * travelDx + travelDy * travelDy + travelDz * travelDz)

        var gateKmh = Double.NaN
        var gateUsesReference = false

        // 기준선 두 점의 3D 위치 (2단계에서 구함)
        val refDx = refB3[0] - refA3[0]
        val refDy = refB3[1] - refA3[1]
        val refDz = refB3[2] - refA3[2]
        val refLengthM = sqrt(refDx * refDx + refDy * refDy + refDz * refDz)
        val refLengthPx = sqrt(
            (input.refBx - input.refAx) * (input.refBx - input.refAx) +
                    (input.refBy - input.refAy) * (input.refBy - input.refAy)
        )

        if (travelLength > 1e-9) {
            val ux = travelDx / travelLength
            val uy = travelDy / travelLength
            val uz = travelDz / travelLength

            // 각 점을 진행 방향 축에 투영한 위치 (미터)
            val s = DoubleArray(count) {
                (xx[it] - firstX) * ux + (yy[it] - firstY) * uy + (zz[it] - firstZ) * uz
            }

            // 기준선 두 점의 축 위 위치
            val sA = (refA3[0] - firstX) * ux + (refA3[1] - firstY) * uy + (refA3[2] - firstZ) * uz
            val sB = (refB3[0] - firstX) * ux + (refB3[1] - firstY) * uy + (refB3[2] - firstZ) * uz

            // 기준선이 진행 방향과 거의 나란하고(20도 이내), 공이 두 점을 모두 지나갔으면 그 두 점을 게이트로 쓴다
            var referenceAligned = false
            if (refLengthM > 1e-9) {
                var cosAngle = abs((refDx * ux + refDy * uy + refDz * uz) / refLengthM)
                if (cosAngle > 1.0) cosAngle = 1.0
                referenceAligned = acos(cosAngle) < Math.toRadians(20.0)
            }

            var gate1 = travelLength * 0.1
            var gate2 = travelLength * 0.9
            if (referenceAligned) {
                val timeA = crossingTime(s, tt, sA)
                val timeB = crossingTime(s, tt, sB)
                if (!timeA.isNaN() && !timeB.isNaN() && timeA != timeB) {
                    gate1 = sA
                    gate2 = sB
                    gateUsesReference = true
                }
            }

            val time1 = crossingTime(s, tt, gate1)
            val time2 = crossingTime(s, tt, gate2)
            if (!time1.isNaN() && !time2.isNaN() && time1 != time2) {
                gateKmh = abs(gate2 - gate1) / abs(time2 - time1) * 3.6
            }
        }

        // ---------- 8. 예상 오차 ----------
        // (a) 거리 보정: 기준선 양 끝을 찍을 때의 오차 / 기준선 길이
        var relativeCalibration = 1.0
        if (refLengthPx > 1e-6) {
            relativeCalibration = sqrt(2.0) * TAP_ERROR_PX / refLengthPx
        }
        // (b) 시간: 타임스탬프 한 개의 불확실성 / 추적 구간 길이
        //     센서 타임스탬프면 프레임 간격의 1%, 영상 파일 시간이면 10%로 본다
        val timestampSigma = if (input.timestampsExact) medianGap * 0.01 else medianGap * 0.10
        val relativeTiming = sqrt(2.0) * timestampSigma / span
        // (c) 피팅: 잔차에서 나온 속도의 표준오차
        val fitSigma = sqrt(releaseVariance)
        // (d) 깊이: 깊이 방향 속도의 불확실성이 전체 속도에 미치는 몫
        var depthSigma = 0.0
        if (depthCorrected && releaseSpeed > 0.0) {
            depthSigma = abs(depthSpeed) / releaseSpeed * depthSpeedSigma
        }

        val errorCalibration = releaseSpeed * relativeCalibration
        val errorTiming = releaseSpeed * relativeTiming
        val totalSigma = sqrt(
            errorCalibration * errorCalibration + errorTiming * errorTiming +
                    fitSigma * fitSigma + depthSigma * depthSigma
        )

        // 깊이 보정을 못 했는데 공 크기가 뚜렷하게 변했으면 경고
        val depthWarning = !depthCorrected && !sizeChangePercent.isNaN() &&
                abs(sizeChangePercent) >= DEPTH_WARNING_PERCENT

        // 화면에는 2시그마(약 95%)를 km/h로 보여준다
        val outliers = BooleanArray(n) { !inlier[it] }
        return SpeedResult(
            ok = true,
            message = "",
            releaseKmh = releaseSpeed * 3.6,
            averageKmh = averageSpeed * 3.6,
            gateKmh = gateKmh,
            gateUsesReferenceLine = gateUsesReference,
            errorKmh = 2.0 * totalSigma * 3.6,
            errorCalibrationKmh = 2.0 * errorCalibration * 3.6,
            errorTimingKmh = 2.0 * errorTiming * 3.6,
            errorFitKmh = 2.0 * fitSigma * 3.6,
            errorDepthKmh = 2.0 * depthSigma * 3.6,
            residualRmsPx = residualRmsPx,
            usedPointCount = count,
            measuredFps = measuredFps,
            releaseModel = releaseModel,
            outliers = outliers,
            sizeChangePercent = sizeChangePercent,
            depthCorrected = depthCorrected,
            throwAngleDeg = throwAngleDeg,
            depthWarning = depthWarning
        )
    }

    private fun inlierIndices(inlier: BooleanArray): IntArray {
        var count = 0
        for (flag in inlier) {
            if (flag) count++
        }
        val result = IntArray(count)
        var k = 0
        for (i in inlier.indices) {
            if (inlier[i]) {
                result[k] = i
                k++
            }
        }
        return result
    }

    /**
     * 공이 축 위의 gate 위치를 지나간 시각을 구한다.
     * gate를 사이에 둔 앞뒤 두 점을 찾아서 위치 비율만큼 시간을 보간한다.
     * 지나간 적이 없으면 NaN.
     */
    private fun crossingTime(s: DoubleArray, times: DoubleArray, gate: Double): Double {
        for (i in 0 until s.size - 1) {
            val before = s[i] - gate
            val after = s[i + 1] - gate
            if (before == after) continue
            if (before * after <= 0.0) {
                val ratio = (gate - s[i]) / (s[i + 1] - s[i])
                return times[i] + ratio * (times[i + 1] - times[i])
            }
        }
        return Double.NaN
    }
}

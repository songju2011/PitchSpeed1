package com.pitchspeed.app.analysis

import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat

/**
 * 영상 파일을 한 프레임씩 디코딩해서 YUV 데이터로 꺼내 준다.
 *
 * 사용법:
 *   val reader = VideoFrameReader(path)
 *   if (reader.open(wantColor = false, seekToUs = 0)) {
 *       while (reader.advance()) {
 *           // reader.yPlane (밝기, 똑바로 세운 상태), reader.currentPtsUs 사용
 *       }
 *       reader.close()
 *   }
 */
class VideoFrameReader(private val path: String) {

    /** 똑바로 세운 뒤의 영상 크기 */
    var width: Int = 0
    var height: Int = 0

    /** 영상을 똑바로 세우려면 시계 방향으로 돌려야 하는 각도 (0, 90, 180, 270) */
    var rotation: Int = 0

    /** 영상 길이 (마이크로초) */
    var durationUs: Long = 0L

    /** 방금 읽은 프레임의 영상 속 시간 (마이크로초) */
    var currentPtsUs: Long = 0L

    /** 방금 읽은 프레임의 밝기(Y). 회전이 적용된 상태. 크기 = width * height */
    var yPlane: ByteArray = ByteArray(0)

    /** 방금 읽은 프레임의 컬러 데이터(NV21). 회전 적용 전. wantColor일 때만 채워진다 */
    var nv21: ByteArray = ByteArray(0)

    /** 디코더가 내놓는 원본 크기 (회전 적용 전) */
    var codedWidth: Int = 0
    var codedHeight: Int = 0

    private var extractor: MediaExtractor? = null
    private var codec: MediaCodec? = null
    private var wantColor = false
    private var inputDone = false
    private var outputDone = false
    private val bufferInfo = MediaCodec.BufferInfo()

    // 회전이 있을 때 쓰는 임시 버퍼 (회전 전 밝기)
    private var rawY: ByteArray = ByteArray(0)
    // 색 평면 한 줄 읽기용 임시 버퍼
    private var rowU: ByteArray = ByteArray(0)
    private var rowV: ByteArray = ByteArray(0)

    /**
     * 영상을 연다.
     * seekToUs > 0 이면 그 시간 바로 앞의 키프레임부터 디코딩을 시작한다.
     */
    fun open(wantColor: Boolean, seekToUs: Long): Boolean {
        this.wantColor = wantColor
        try {
            val newExtractor = MediaExtractor()
            newExtractor.setDataSource(path)
            extractor = newExtractor

            // 비디오 트랙 찾기
            var trackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until newExtractor.trackCount) {
                val format = newExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("video/")) {
                    trackIndex = i
                    trackFormat = format
                    break
                }
            }
            if (trackIndex < 0 || trackFormat == null) return false
            newExtractor.selectTrack(trackIndex)

            codedWidth = trackFormat.getInteger(MediaFormat.KEY_WIDTH)
            codedHeight = trackFormat.getInteger(MediaFormat.KEY_HEIGHT)
            rotation = 0
            if (trackFormat.containsKey(MediaFormat.KEY_ROTATION)) {
                rotation = trackFormat.getInteger(MediaFormat.KEY_ROTATION)
            }
            durationUs = 0L
            if (trackFormat.containsKey(MediaFormat.KEY_DURATION)) {
                durationUs = trackFormat.getLong(MediaFormat.KEY_DURATION)
            }

            if (rotation == 90 || rotation == 270) {
                width = codedHeight
                height = codedWidth
            } else {
                width = codedWidth
                height = codedHeight
            }

            yPlane = ByteArray(codedWidth * codedHeight)
            if (rotation != 0) {
                rawY = ByteArray(codedWidth * codedHeight)
            }
            if (wantColor) {
                nv21 = ByteArray(codedWidth * codedHeight * 3 / 2)
            }

            if (seekToUs > 0L) {
                newExtractor.seekTo(seekToUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            }

            // 디코더 출력을 YUV 버퍼로 받는다
            trackFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            )
            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: return false
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(trackFormat, null, null, 0)
            decoder.start()
            codec = decoder

            inputDone = false
            outputDone = false
            return true
        } catch (e: Exception) {
            close()
            return false
        }
    }

    /** 다음 프레임을 읽는다. 더 없으면 false */
    fun advance(): Boolean {
        val decoder = codec ?: return false
        val source = extractor ?: return false

        var idleLoops = 0
        try {
            while (!outputDone) {
                // 압축된 데이터를 디코더에 넣는다
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(5000)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex)
                        var sampleSize = -1
                        if (inputBuffer != null) {
                            sampleSize = source.readSampleData(inputBuffer, 0)
                        }
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, sampleSize, source.sampleTime, 0)
                            source.advance()
                        }
                    }
                }

                // 디코딩된 프레임을 꺼낸다
                val outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 5000)
                if (outputIndex >= 0) {
                    idleLoops = 0
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                    var gotFrame = false
                    if (bufferInfo.size > 0) {
                        val image = decoder.getOutputImage(outputIndex)
                        if (image != null) {
                            copyImage(image)
                            image.close()
                            currentPtsUs = bufferInfo.presentationTimeUs
                            gotFrame = true
                        }
                    }
                    decoder.releaseOutputBuffer(outputIndex, false)
                    if (gotFrame) return true
                } else {
                    // 아직 출력이 없음. 너무 오래 아무것도 안 나오면 포기한다 (약 20초)
                    idleLoops++
                    if (idleLoops > 2000) return false
                }
            }
        } catch (e: Exception) {
            return false
        }
        return false
    }

    fun close() {
        try {
            codec?.stop()
        } catch (e: Exception) {
        }
        try {
            codec?.release()
        } catch (e: Exception) {
        }
        codec = null
        try {
            extractor?.release()
        } catch (e: Exception) {
        }
        extractor = null
    }

    /** 디코더가 준 Image에서 밝기(와 필요하면 색) 데이터를 우리 배열로 복사한다 */
    private fun copyImage(image: Image) {
        val crop = image.cropRect
        var copyWidth = crop.width()
        var copyHeight = crop.height()
        if (copyWidth > codedWidth) copyWidth = codedWidth
        if (copyHeight > codedHeight) copyHeight = codedHeight

        // ---------- 밝기(Y) ----------
        val target = if (rotation == 0) yPlane else rawY
        val planeY = image.planes[0]
        val bufferY = planeY.buffer
        val strideY = planeY.rowStride
        for (row in 0 until copyHeight) {
            bufferY.position((crop.top + row) * strideY + crop.left)
            bufferY.get(target, row * codedWidth, copyWidth)
        }

        // ---------- 색(NV21: Y 다음에 V,U가 번갈아 나옴) ----------
        if (wantColor) {
            System.arraycopy(target, 0, nv21, 0, codedWidth * codedHeight)

            val planeU = image.planes[1]
            val planeV = image.planes[2]
            val bufferU = planeU.buffer
            val bufferV = planeV.buffer
            val strideU = planeU.rowStride
            val strideV = planeV.rowStride
            val pixelStrideU = planeU.pixelStride
            val pixelStrideV = planeV.pixelStride
            val chromaWidth = copyWidth / 2
            val chromaHeight = copyHeight / 2

            val neededU = (chromaWidth - 1) * pixelStrideU + 1
            val neededV = (chromaWidth - 1) * pixelStrideV + 1
            if (rowU.size < neededU) rowU = ByteArray(neededU)
            if (rowV.size < neededV) rowV = ByteArray(neededV)

            var out = codedWidth * codedHeight
            for (row in 0 until chromaHeight) {
                bufferU.position((crop.top / 2 + row) * strideU + (crop.left / 2) * pixelStrideU)
                bufferU.get(rowU, 0, neededU)
                bufferV.position((crop.top / 2 + row) * strideV + (crop.left / 2) * pixelStrideV)
                bufferV.get(rowV, 0, neededV)

                var writeIndex = out
                for (col in 0 until chromaWidth) {
                    nv21[writeIndex] = rowV[col * pixelStrideV]
                    nv21[writeIndex + 1] = rowU[col * pixelStrideU]
                    writeIndex += 2
                }
                out += codedWidth
            }
        }

        // ---------- 회전 ----------
        // rotation = 화면에 보여줄 때 시계 방향으로 돌려야 하는 각도
        if (rotation == 90) {
            // 결과 크기: 가로 = codedHeight, 세로 = codedWidth
            for (dy in 0 until codedWidth) {
                for (dx in 0 until codedHeight) {
                    val sx = dy
                    val sy = codedHeight - 1 - dx
                    yPlane[dy * codedHeight + dx] = rawY[sy * codedWidth + sx]
                }
            }
        } else if (rotation == 180) {
            val total = codedWidth * codedHeight
            for (i in 0 until total) {
                yPlane[i] = rawY[total - 1 - i]
            }
        } else if (rotation == 270) {
            for (dy in 0 until codedWidth) {
                for (dx in 0 until codedHeight) {
                    val sx = codedWidth - 1 - dy
                    val sy = dx
                    yPlane[dy * codedHeight + dx] = rawY[sy * codedWidth + sx]
                }
            }
        }
    }
}

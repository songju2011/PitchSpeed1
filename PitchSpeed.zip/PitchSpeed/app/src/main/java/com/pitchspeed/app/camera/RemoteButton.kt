package com.pitchspeed.app.camera

import android.view.KeyEvent

/**
 * 셀카봉 블루투스 리모컨 버튼.
 *
 * 블루투스 셀카 리모컨은 휴대폰에 "키보드"로 연결돼서, 버튼을 누르면 키 입력을 보낸다.
 * 대부분 볼륨 업 키를 보내고, 제품에 따라 볼륨 다운·엔터·카메라·재생 키를 보내기도 한다.
 * MainActivity가 키 입력을 받아서 여기로 넘기고, 측정 화면이 onPress를 등록해서 쓴다.
 */
object RemoteButton {

    /** 측정 화면이 열려 있을 때만 값이 있다. 메인 스레드에서 불린다 */
    var onPress: (() -> Unit)? = null

    /** 리모컨 버튼으로 볼 키들 */
    fun isRemoteKey(keyCode: Int): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) return true
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) return true
        if (keyCode == KeyEvent.KEYCODE_CAMERA) return true
        if (keyCode == KeyEvent.KEYCODE_ENTER) return true
        if (keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) return true
        if (keyCode == KeyEvent.KEYCODE_SPACE) return true
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) return true
        if (keyCode == KeyEvent.KEYCODE_HEADSETHOOK) return true
        return false
    }

    /**
     * MainActivity의 dispatchKeyEvent에서 부른다.
     * 측정 화면이 열려 있고 리모컨 키면 true(= 처리했음, 볼륨이 바뀌지 않음)를 돌려준다.
     */
    fun handleKeyEvent(event: KeyEvent): Boolean {
        val handler = onPress ?: return false
        if (!isRemoteKey(event.keyCode)) return false

        // 누를 때 한 번만 반응한다 (꾹 누르고 있을 때 반복 입력, 뗄 때 입력은 무시)
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            handler()
        }
        return true
    }
}

package com.pitchspeed.app.analysis

/**
 * 녹화된 프레임(인코더 시간, 마이크로초)과 카메라가 알려준 SENSOR_TIMESTAMP(나노초)를 짝짓는다.
 *
 * 인코더로 들어가는 프레임의 시간은 센서 타임스탬프에서 온 값이지만,
 * 기기에 따라 "일정한 값만큼 밀려" 있을 수 있다 (시계 기준이 달라서).
 * 그래서 그 밀린 값(offset)을 먼저 찾아낸 다음, 프레임마다 나노초 타임스탬프를 붙인다.
 */
object TimestampMatcher {

    class MatchResult(
        val clipPtsUs: LongArray,   // 저장된 각 프레임의 클립 안 시간 (µs, 첫 프레임 = 0)
        val timesNs: LongArray,     // 같은 순서로, 각 프레임의 실제 시간 (ns)
        val exact: Boolean,         // 센서 타임스탬프와 짝짓기에 성공했는지
        val matchedCount: Int
    )

    // 마이크로초로 잘리면서 생기는 차이를 허용하는 범위 (나노초)
    private const val TOLERANCE_NS = 1500L

    fun match(encoderPtsUs: LongArray, sensorNs: LongArray): MatchResult {
        val n = encoderPtsUs.size
        val clipPtsUs = LongArray(n)
        val timesNs = LongArray(n)
        if (n == 0) return MatchResult(clipPtsUs, timesNs, false, 0)
        val firstPts = encoderPtsUs[0]

        var bestOffset = 0L
        var bestCount = -1
        var bestError = Long.MAX_VALUE

        if (sensorNs.isNotEmpty()) {
            // 클립 마지막 프레임이 최근 센서 타임스탬프 중 어느 것과 같은 프레임인지 하나씩 가정해 본다
            val lastPtsNs = encoderPtsUs[n - 1] * 1000L
            val firstCandidate = if (sensorNs.size > 512) sensorNs.size - 512 else 0
            for (c in firstCandidate until sensorNs.size) {
                val offset = sensorNs[c] - lastPtsNs
                var count = 0
                var error = 0L
                for (k in 0 until n) {
                    val target = encoderPtsUs[k] * 1000L + offset
                    val nearest = nearestIndex(sensorNs, target)
                    var diff = sensorNs[nearest] - target
                    if (diff < 0) diff = -diff
                    if (diff <= TOLERANCE_NS) {
                        count++
                        error += diff
                    }
                }
                if (count > bestCount || (count == bestCount && error < bestError)) {
                    bestCount = count
                    bestError = error
                    bestOffset = offset
                }
            }
        }

        // 95% 이상 짝이 맞아야 믿는다
        val exact = bestCount >= 3 && bestCount >= (n * 0.95).toInt()

        for (k in 0 until n) {
            clipPtsUs[k] = encoderPtsUs[k] - firstPts
            if (exact) {
                val target = encoderPtsUs[k] * 1000L + bestOffset
                val nearest = nearestIndex(sensorNs, target)
                var diff = sensorNs[nearest] - target
                if (diff < 0) diff = -diff
                if (diff <= TOLERANCE_NS) {
                    timesNs[k] = sensorNs[nearest]     // 나노초 센서 타임스탬프
                } else {
                    timesNs[k] = target                // 짝이 없는 프레임은 같은 기준으로 환산
                }
            } else {
                // 짝짓기 실패: 인코더 시간(센서 타임스탬프에서 온 마이크로초 값)을 그대로 쓴다
                timesNs[k] = encoderPtsUs[k] * 1000L
            }
        }
        return MatchResult(clipPtsUs, timesNs, exact, if (bestCount < 0) 0 else bestCount)
    }

    /** 오름차순 배열에서 target에 가장 가까운 값의 위치 (이진 탐색) */
    fun nearestIndex(sorted: LongArray, target: Long): Int {
        var low = 0
        var high = sorted.size - 1
        while (low < high) {
            val mid = (low + high) / 2
            if (sorted[mid] < target) {
                low = mid + 1
            } else {
                high = mid
            }
        }
        // low = target 이상인 첫 위치. 바로 앞의 것과 비교해서 더 가까운 쪽을 고른다
        if (low > 0) {
            val diffLow = sorted[low] - target
            val diffPrev = target - sorted[low - 1]
            val absLow = if (diffLow < 0) -diffLow else diffLow
            if (diffPrev < absLow) return low - 1
        }
        return low
    }
}

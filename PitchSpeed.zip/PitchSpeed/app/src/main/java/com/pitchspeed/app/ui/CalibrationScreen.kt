package com.pitchspeed.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.analysis.Calibration
import com.pitchspeed.app.analysis.PitchAnalyzer
import com.pitchspeed.app.data.AppSession
import com.pitchspeed.app.data.CalibrationStore
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

private val ColorPointA = Color(0xFFFF5A36)
private val ColorPointB = Color(0xFF4FC3F7)

/**
 * 2-2. 거리 보정.
 * 정지 화면 위에 기준 길이의 양 끝 두 점을 찍고 실제 거리(m)를 넣으면 "픽셀당 미터"가 정해진다.
 *
 * 조작: 화면을 탭하면 점이 찍힌다(첫 탭 = A, 둘째 탭 = B, 그 뒤로는 가까운 점이 옮겨짐).
 *       끌면 선택된 점이 손가락 움직임만큼 움직인다. 화살표 버튼은 0.5픽셀씩 옮긴다.
 */
@Composable
fun CalibrationScreen(navController: NavController) {
    val context = LocalContext.current
    val bitmap = AppSession.calibrationBitmap
    if (bitmap == null) {
        MessageScreen(text = "보정할 화면이 없습니다.", onBack = { navController.popBackStack() })
        return
    }
    val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }
    val imageWidth = bitmap.width
    val imageHeight = bitmap.height
    val forImport = AppSession.calibrationIsForImport
    val lens = if (forImport) null else AppSession.liveLens

    // 두 점의 위치 (이미지 픽셀 좌표)
    var pointA by remember { mutableStateOf<Offset?>(null) }
    var pointB by remember { mutableStateOf<Offset?>(null) }
    var selected by remember { mutableIntStateOf(0) }   // 0 = A, 1 = B
    var distanceText by remember { mutableStateOf("18.44") }
    var useLens by remember { mutableStateOf(true) }

    /** 선택된 점을 이미지 픽셀 단위로 옮긴다 */
    fun moveSelected(dx: Float, dy: Float) {
        if (selected == 0) {
            val a = pointA
            if (a != null) {
                pointA = Offset(
                    (a.x + dx).coerceIn(0f, imageWidth - 1f),
                    (a.y + dy).coerceIn(0f, imageHeight - 1f)
                )
            }
        } else {
            val b = pointB
            if (b != null) {
                pointB = Offset(
                    (b.x + dx).coerceIn(0f, imageWidth - 1f),
                    (b.y + dy).coerceIn(0f, imageHeight - 1f)
                )
            }
        }
    }

    // 지금 입력으로 만든 보정 값 (아직 다 안 채워졌으면 null)
    val a = pointA
    val b = pointB
    val meters = distanceText.replace(',', '.').toDoubleOrNull()
    val calibration: Calibration? =
        if (a != null && b != null && meters != null && meters > 0.0) {
            Calibration(
                ax = a.x.toDouble(),
                ay = a.y.toDouble(),
                bx = b.x.toDouble(),
                by = b.y.toDouble(),
                realMeters = meters,
                imageWidth = imageWidth,
                imageHeight = imageHeight,
                lens = lens,
                useLensCorrection = useLens && lens != null
            )
        } else {
            null
        }
    val lengthPx = if (calibration != null) calibration.referenceLengthPx(imageWidth, imageHeight) else 0.0
    val metersPerPixel = if (calibration != null) calibration.metersPerPixel(imageWidth, imageHeight) else 0.0
    val valid = calibration != null && lengthPx >= 20.0

    Row(modifier = Modifier.fillMaxSize()) {

        // ---------------- 왼쪽: 정지 화면 + 두 점 ----------------
        Canvas(
            modifier = Modifier
                .weight(1.7f)
                .fillMaxHeight()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTapGestures { tap ->
                        val scale = min(size.width.toFloat() / imageWidth, size.height.toFloat() / imageHeight)
                        val left = (size.width - imageWidth * scale) / 2f
                        val top = (size.height - imageHeight * scale) / 2f
                        val p = Offset(
                            ((tap.x - left) / scale).coerceIn(0f, imageWidth - 1f),
                            ((tap.y - top) / scale).coerceIn(0f, imageHeight - 1f)
                        )
                        val currentA = pointA
                        val currentB = pointB
                        if (currentA == null) {
                            pointA = p
                            selected = 0
                        } else if (currentB == null) {
                            pointB = p
                            selected = 1
                        } else {
                            // 두 점이 다 있으면 가까운 쪽을 옮긴다
                            val distanceA = (p - currentA).getDistance()
                            val distanceB = (p - currentB).getDistance()
                            if (distanceA <= distanceB) {
                                pointA = p
                                selected = 0
                            } else {
                                pointB = p
                                selected = 1
                            }
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { start ->
                            // 끌기 시작한 곳에서 가까운 점을 선택한다
                            val scale = min(size.width.toFloat() / imageWidth, size.height.toFloat() / imageHeight)
                            val left = (size.width - imageWidth * scale) / 2f
                            val top = (size.height - imageHeight * scale) / 2f
                            val p = Offset((start.x - left) / scale, (start.y - top) / scale)
                            val currentA = pointA
                            val currentB = pointB
                            if (currentA != null && currentB != null) {
                                val distanceA = (p - currentA).getDistance()
                                val distanceB = (p - currentB).getDistance()
                                selected = if (distanceA <= distanceB) 0 else 1
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val scale = min(size.width.toFloat() / imageWidth, size.height.toFloat() / imageHeight)
                            moveSelected(dragAmount.x / scale, dragAmount.y / scale)
                        }
                    )
                }
        ) {
            val scale = min(size.width / imageWidth, size.height / imageHeight)
            val left = (size.width - imageWidth * scale) / 2f
            val top = (size.height - imageHeight * scale) / 2f

            drawImage(
                image = imageBitmap,
                dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
                dstSize = IntSize((imageWidth * scale).roundToInt(), (imageHeight * scale).roundToInt())
            )

            val drawA = pointA
            val drawB = pointB
            if (drawA != null && drawB != null) {
                drawLine(
                    color = Color.White,
                    start = Offset(left + drawA.x * scale, top + drawA.y * scale),
                    end = Offset(left + drawB.x * scale, top + drawB.y * scale),
                    strokeWidth = 2f
                )
            }
            if (drawA != null) {
                val center = Offset(left + drawA.x * scale, top + drawA.y * scale)
                drawCircle(color = ColorPointA, radius = if (selected == 0) 22f else 14f, center = center, style = Stroke(width = 3f))
                drawLine(ColorPointA, Offset(center.x - 30f, center.y), Offset(center.x + 30f, center.y), strokeWidth = 1.5f)
                drawLine(ColorPointA, Offset(center.x, center.y - 30f), Offset(center.x, center.y + 30f), strokeWidth = 1.5f)
            }
            if (drawB != null) {
                val center = Offset(left + drawB.x * scale, top + drawB.y * scale)
                drawCircle(color = ColorPointB, radius = if (selected == 1) 22f else 14f, center = center, style = Stroke(width = 3f))
                drawLine(ColorPointB, Offset(center.x - 30f, center.y), Offset(center.x + 30f, center.y), strokeWidth = 1.5f)
                drawLine(ColorPointB, Offset(center.x, center.y - 30f), Offset(center.x, center.y + 30f), strokeWidth = 1.5f)
            }
        }

        // ---------------- 오른쪽: 입력 ----------------
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "거리 보정", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "기준 길이의 양 끝을 화면에서 탭하세요. 끌거나 화살표로 미세하게 옮길 수 있습니다.",
                fontSize = 13.sp,
                color = ColorDim
            )

            // 확대 화면 + 미세 이동 버튼
            Row(verticalAlignment = Alignment.CenterVertically) {
                val selectedPoint = if (selected == 0) pointA else pointB
                val selectedColor = if (selected == 0) ColorPointA else ColorPointB
                Canvas(
                    modifier = Modifier
                        .size(120.dp)
                        .background(Color.Black)
                ) {
                    if (selectedPoint != null) {
                        // 선택된 점 주변 48x48 픽셀을 크게 보여준다
                        val region = 48
                        val srcLeft = (selectedPoint.x.roundToInt() - region / 2).coerceIn(0, imageWidth - region)
                        val srcTop = (selectedPoint.y.roundToInt() - region / 2).coerceIn(0, imageHeight - region)
                        drawImage(
                            image = imageBitmap,
                            srcOffset = IntOffset(srcLeft, srcTop),
                            srcSize = IntSize(region, region),
                            dstOffset = IntOffset.Zero,
                            dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                            filterQuality = FilterQuality.None
                        )
                        val zoom = size.width / region
                        val cx = (selectedPoint.x - srcLeft + 0.5f) * zoom
                        val cy = (selectedPoint.y - srcTop + 0.5f) * zoom
                        drawLine(selectedColor, Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 1.5f)
                        drawLine(selectedColor, Offset(0f, cy), Offset(size.width, cy), strokeWidth = 1.5f)
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    SmallButton(text = "▲", onClick = { moveSelected(0f, -0.5f) })
                    Row {
                        SmallButton(text = "◀", onClick = { moveSelected(-0.5f, 0f) })
                        Spacer(modifier = Modifier.width(4.dp))
                        SmallButton(text = "▶", onClick = { moveSelected(0.5f, 0f) })
                    }
                    SmallButton(text = "▼", onClick = { moveSelected(0f, 0.5f) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton(
                    text = "점 A",
                    color = if (selected == 0) ColorPointA else ColorSecondary,
                    onClick = { selected = 0 }
                )
                SmallButton(
                    text = "점 B",
                    color = if (selected == 1) Color(0xFF1E88C8) else ColorSecondary,
                    onClick = { selected = 1 }
                )
            }

            // 실제 거리
            Text(text = "실제 거리", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            SmallButton(
                text = "투수판~홈플레이트 18.44 m",
                modifier = Modifier.fillMaxWidth(),
                onClick = { distanceText = "18.44" }
            )
            SmallButton(
                text = "홈플레이트 폭 43.2 cm",
                modifier = Modifier.fillMaxWidth(),
                onClick = { distanceText = "0.432" }
            )
            OutlinedTextField(
                value = distanceText,
                onValueChange = { text -> distanceText = text },
                label = { Text("직접 입력 (m)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )

            // 렌즈 왜곡 보정 (기기가 렌즈 값을 줄 때만 보인다)
            if (lens != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = useLens, onCheckedChange = { checked -> useLens = checked })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "렌즈 왜곡 보정", fontSize = 15.sp)
                }
            }

            // 보정 결과 미리 보기
            if (calibration != null && lengthPx > 0.0) {
                val ballPx = PitchAnalyzer.BALL_DIAMETER_M / metersPerPixel
                val tapErrorPercent = sqrt(2.0) * 1.5 / lengthPx * 100.0
                Text(
                    text = "기준선 ${formatOne(lengthPx)} px · 1 px = ${formatTwo(metersPerPixel * 100.0)} cm\n" +
                            "공 지름 ≈ ${formatOne(ballPx)} px · 보정 오차 ≈ ±${formatTwo(tapErrorPercent)} %",
                    fontSize = 14.sp
                )
                if (ballPx < 3.0) {
                    Text(
                        text = "공이 너무 작게 찍힙니다(3 px 미만). 더 가까이에서 찍거나 구도를 좁히세요.",
                        fontSize = 14.sp,
                        color = ColorWarning
                    )
                }
                if (lengthPx < 200.0) {
                    Text(
                        text = "기준선이 짧으면 보정 오차가 커집니다. 가능하면 더 긴 기준 길이를 쓰세요.",
                        fontSize = 14.sp,
                        color = ColorWarning
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            BigButton(
                text = "보정 완료",
                modifier = Modifier.fillMaxWidth(),
                enabled = valid,
                onClick = {
                    val finalCalibration = calibration
                    if (finalCalibration != null) {
                        if (forImport) {
                            // 불러온 영상: 바로 분석으로
                            AppSession.pendingCalibration = finalCalibration
                            navController.navigate("analyze") {
                                popUpTo("home")
                            }
                        } else {
                            // 실시간 촬영: 저장해 두고 측정 대기로
                            CalibrationStore.save(context, finalCalibration)
                            navController.navigate("measure") {
                                popUpTo("guide")
                            }
                        }
                    }
                }
            )
            SmallButton(
                text = "뒤로",
                modifier = Modifier.fillMaxWidth(),
                onClick = { navController.popBackStack() }
            )
        }
    }
}

package com.pitchspeed.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.pitchspeed.app.data.AppSession
import com.pitchspeed.app.data.VideoImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 시작 화면: 측정 시작 / 갤러리 영상 불러오기 / 기록 */
@Composable
fun HomeScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var message by remember { mutableStateOf("") }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var importing by remember { mutableStateOf(false) }

    // 카메라 권한 요청
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            navController.navigate("guide")
        } else {
            message = "카메라 권한이 필요합니다. 휴대폰 설정 > 앱 > 구속 측정기 > 권한에서 허용해 주세요."
        }
    }

    // 갤러리 영상 선택 (시스템 선택기를 쓰므로 저장소 권한이 필요 없다)
    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            pickedUri = uri
        }
    }

    fun startImport(realFps: Int) {
        val uri = pickedUri ?: return
        pickedUri = null
        importing = true
        message = ""
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                VideoImporter.prepare(context.applicationContext, uri, realFps)
            }
            importing = false
            if (result == null) {
                message = "영상을 읽을 수 없습니다."
            } else {
                AppSession.pendingClip = result.clip
                AppSession.calibrationBitmap = result.firstFrame
                AppSession.calibrationIsForImport = true
                navController.navigate("calibrate")
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 왼쪽: 제목
        Column(modifier = Modifier.weight(1f)) {
            Text(text = "구속 측정기", fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "고속 촬영으로 공을 자동 추적해서\n구속을 km/h와 mph로 보여줍니다.",
                fontSize = 17.sp,
                color = ColorDim
            )
            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = message, fontSize = 16.sp, color = ColorWarning)
            }
        }

        Spacer(modifier = Modifier.width(32.dp))

        // 오른쪽: 큰 버튼 세 개
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
        ) {
            BigButton(
                text = "측정 시작",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val granted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        navController.navigate("guide")
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }
            )
            BigButton(
                text = "갤러리 영상 불러오기",
                modifier = Modifier.fillMaxWidth(),
                color = ColorSecondary,
                enabled = !importing,
                onClick = { videoPicker.launch("video/*") }
            )
            BigButton(
                text = "기록",
                modifier = Modifier.fillMaxWidth(),
                color = ColorSecondary,
                onClick = { navController.navigate("history") }
            )
        }
    }

    // 영상을 고른 뒤: 실제 촬영 fps 확인
    if (pickedUri != null) {
        AlertDialog(
            onDismissRequest = { pickedUri = null },
            title = { Text("이 영상의 실제 촬영 fps") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "슬로모션 영상은 파일에 기록된 시간이 실제와 다를 수 있습니다. " +
                                "찍을 때의 fps를 알면 골라 주세요. 모르면 자동 감지를 누르세요.",
                        fontSize = 14.sp,
                        color = ColorDim
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = { startImport(0) }) { Text("자동 감지", fontSize = 18.sp) }
                    Row {
                        TextButton(onClick = { startImport(30) }) { Text("30", fontSize = 18.sp) }
                        TextButton(onClick = { startImport(60) }) { Text("60", fontSize = 18.sp) }
                        TextButton(onClick = { startImport(120) }) { Text("120", fontSize = 18.sp) }
                    }
                    Row {
                        TextButton(onClick = { startImport(240) }) { Text("240", fontSize = 18.sp) }
                        TextButton(onClick = { startImport(480) }) { Text("480", fontSize = 18.sp) }
                        TextButton(onClick = { startImport(960) }) { Text("960", fontSize = 18.sp) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pickedUri = null }) { Text("취소") }
            }
        )
    }

    // 영상 복사 중
    if (importing) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(12.dp))
                Text("영상 준비 중…", fontSize = 16.sp)
            }
        }
    }
}

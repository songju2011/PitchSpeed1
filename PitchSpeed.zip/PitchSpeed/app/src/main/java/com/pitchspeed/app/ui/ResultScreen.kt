package com.pitchspeed.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.pitchspeed.app.analysis.PitchAnalyzer
import com.pitchspeed.app.analysis.ReplayFrameCache
import com.pitchspeed.app.analysis.SpeedCalculator
import com.pitchspeed.app.analysis.TrackPoint
import com.pitchspeed.app.data.AppSession
import com.pitchspeed.app.data.JsonCodec
import com.pitchspeed.app.data.PitchDatabase
import com.pitchspeed.app.data.PitchRecord
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val ColorTrackAuto = Color(0xFFFFEB3B)     // 자동 추적 점
private val ColorTrackManual = Color(0xFF4FC3F7)   // 직접 찍은 점
private val ColorTrackOutlier = Color(0xFF9E9E9E)  // 이상치로 빠진 점

/**
 * 4. 결과 화면.
 * 왼쪽: 슬로모션 리플레이 + 궤적 오버레이 (수정 모드에서는 공을 직접 탭해서 고칠 수 있다)
 * 오른쪽: 속도(km/h, mph), 예상 오차, 메모, 저장
 */
@Composable
fun ResultScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val data = AppSession.currentResult
    if (data == null) {
        MessageScreen(text = "표시할 결과가 없습니다.", onBack = { navController.popBackStack() })
        return
    }
    val frameCount = data.windowTimesNs.size

    // 점을 고칠 때마다 1씩 올려서 화면을 다시 그리게 한다
    var version by remember { mutableIntStateOf(0) }

    // 리플레이 상태
    var frameOffset by remember {
        // 처음에는 공이 처음 잡힌 프레임에서 시작
        var initial = 0
        if (data.points.isNotEmpty()) {
            initial = data.points[0].frameIndex - data.windowStartFrame
            if (initial < 0 || initial >= frameCount) initial = 0
        }
        mutableIntStateOf(initial)
    }
    var playing by remember { mutableStateOf(true) }
    var frameDelayMs by remember { mutableIntStateOf(66) }
    var editMode by remember { mutableStateOf(false) }
    var frameBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cacheReady by remember { mutableStateOf(false) }
    var cacheFailed by remember { mutableStateOf(false) }
    var cacheProgress by remember { mutableFloatStateOf(0f) }

    // 기록 상태
    var memo by remember { mutableStateOf(AppSession.currentMemo) }
    var savedId by remember { mutableLongStateOf(AppSession.currentRecordId) }
    var infoText by remember { mutableStateOf("") }

    // ---------------- 리플레이 프레임 준비 ----------------
    // (방금 분석한 결과면 이미 만들어져 있고, 기록에서 열었으면 여기서 영상으로부터 다시 만든다)
    LaunchedEffect(Unit) {
        val ok = withContext(Dispatchers.IO) {
            ReplayFrameCache.build(
                context.applicationContext,
                data.videoPath,
                data.windowStartFrame,
                data.windowStartPtsUs,
                frameCount,
                data.replayHalfRes
            ) { fraction -> cacheProgress = fraction }
        }
        cacheReady = ok
        cacheFailed = !ok
    }

    // 재생 중: 다음 프레임을 읽어서 넘긴다
    LaunchedEffect(playing, cacheReady, frameDelayMs) {
        if (!cacheReady || !playing || frameCount <= 1) return@LaunchedEffect
        while (isActive) {
            val started = SystemClock.elapsedRealtime()
            val nextOffset = (frameOffset + 1) % frameCount
            val bitmap = withContext(Dispatchers.IO) {
                ReplayFrameCache.loadFrame(
                    context.applicationContext, data.videoPath, data.windowStartFrame + nextOffset, data.rotation
                )
            }
            if (bitmap != null) frameBitmap = bitmap
            frameOffset = nextOffset
            var wait = frameDelayMs - (SystemClock.elapsedRealtime() - started)
            if (wait < 1L) wait = 1L
            delay(wait)
        }
    }

    // 멈춰 있을 때: 지금 프레임을 읽는다 (한 프레임씩 넘길 때)
    LaunchedEffect(frameOffset, playing, cacheReady) {
        if (!cacheReady || playing) return@LaunchedEffect
        val bitmap = withContext(Dispatchers.IO) {
            ReplayFrameCache.loadFrame(
                context.applicationContext, data.videoPath, data.windowStartFrame + frameOffset, data.rotation
            )
        }
        if (bitmap != null) frameBitmap = bitmap
    }

    /** 수정 모드에서 화면을 탭했을 때: 지금 프레임의 공 위치를 그 자리로 정한다 */
    fun handleTap(tap: Offset, viewWidth: Int, viewHeight: Int) {
        val bitmap = frameBitmap ?: return
        val scale = min(viewWidth.toFloat() / data.frameWidth, viewHeight.toFloat() / data.frameHeight)
        val left = (viewWidth - data.frameWidth * scale) / 2f
        val top = (viewHeight - data.frameHeight * scale) / 2f
        val videoX = ((tap.x - left) / scale).toDouble()
        val videoY = ((tap.y - top) / scale).toDouble()
        if (videoX < 0.0 || videoY < 0.0 || videoX >= data.frameWidth || videoY >= data.frameHeight) return

        // 리플레이 이미지는 절반 크기일 수 있다
        val bitmapScale = data.frameWidth.toDouble() / bitmap.width

        // 탭한 곳 근처에서 공 중심을 밝기 가중 평균으로 다시 잡는다
        val metersPerPixel = data.calibration.metersPerPixel(data.frameWidth, data.frameHeight)
        val ballPx = if (metersPerPixel > 0.0) PitchAnalyzer.BALL_DIAMETER_M / metersPerPixel else 8.0
        var radius = (1.5 * ballPx / bitmapScale).roundToInt()
        if (radius < 6) radius = 6
        val refined = PitchAnalyzer.refineTap(bitmap, videoX / bitmapScale, videoY / bitmapScale, radius)

        // 이 프레임에 이미 있던 점은 지우고 새 점을 넣는다
        val frameIndex = data.windowStartFrame + frameOffset
        val iterator = data.points.iterator()
        while (iterator.hasNext()) {
            if (iterator.next().frameIndex == frameIndex) iterator.remove()
        }
        data.points.add(
            TrackPoint(
                frameIndex = frameIndex,
                timeNs = data.windowTimesNs[frameOffset],
                x = refined[0] * bitmapScale,
                y = refined[1] * bitmapScale,
                isManual = true
            )
        )
        PitchAnalyzer.computeSpeed(data)
        version++

        // 이어서 찍기 편하게 다음 프레임으로 넘어간다
        if (frameOffset < frameCount - 1) frameOffset++
    }

    fun saveRecord() {
        val speed = data.speed
        if (speed == null || !speed.ok) {
            infoText = "속도가 계산되지 않아 저장할 수 없습니다."
            return
        }
        val memoToSave = memo
        val existingId = savedId
        scope.launch {
            val newId = withContext(Dispatchers.IO) {
                val dao = PitchDatabase.get(context.applicationContext).pitchDao()
                val record = PitchRecord(
                    id = if (existingId > 0L) existingId else 0L,
                    dateMillis = AppSession.currentDateMillis,
                    kmh = speed.releaseKmh,
                    mph = SpeedCalculator.kmhToMph(speed.releaseKmh),
                    averageKmh = speed.averageKmh,
                    errorKmh = speed.errorKmh,
                    memo = memoToSave,
                    videoPath = data.videoPath,
                    dataJson = JsonCodec.resultToJson(data)
                )
                if (existingId > 0L) {
                    dao.update(record)
                    existingId
                } else {
                    dao.insert(record)
                }
            }
            savedId = newId
            AppSession.currentRecordId = newId
            AppSession.currentMemo = memoToSave
            infoText = "기록에 저장했습니다."
        }
    }

    fun exportToGallery() {
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                exportVideoToGallery(context.applicationContext, data.videoPath)
            }
            infoText = if (ok) "갤러리의 Movies/PitchSpeed 폴더에 저장했습니다." else "내보내기에 실패했습니다."
        }
    }

    // 안드로이드 9 이하에서만 필요한 저장소 권한
    val storagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            exportToGallery()
        } else {
            infoText = "저장소 권한이 없어서 내보낼 수 없습니다."
        }
    }

    val currentImage = remember(frameBitmap) { frameBitmap?.asImageBitmap() }

    Row(modifier = Modifier.fillMaxSize()) {

        // ======================= 왼쪽: 리플레이 =======================
        Column(
            modifier = Modifier
                .weight(1.6f)
                .fillMaxHeight()
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { tap ->
                                if (editMode) {
                                    handleTap(tap, size.width, size.height)
                                }
                            }
                        }
                ) {
                    // version을 읽어 두면 점이 바뀔 때 다시 그려진다
                    val redrawKey = version
                    if (redrawKey < 0) return@Canvas

                    val scale = min(size.width / data.frameWidth, size.height / data.frameHeight)
                    val left = (size.width - data.frameWidth * scale) / 2f
                    val top = (size.height - data.frameHeight * scale) / 2f

                    // 프레임 이미지
                    val image = currentImage
                    if (image != null) {
                        drawImage(
                            image = image,
                            dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
                            dstSize = IntSize(
                                (data.frameWidth * scale).roundToInt(),
                                (data.frameHeight * scale).roundToInt()
                            )
                        )
                    }

                    // 보정 기준선
                    val calibration = data.calibration
                    val calibrationScaleX = data.frameWidth.toFloat() / calibration.imageWidth
                    val calibrationScaleY = data.frameHeight.toFloat() / calibration.imageHeight
                    drawLine(
                        color = Color(0x99FFFFFF),
                        start = Offset(
                            left + calibration.ax.toFloat() * calibrationScaleX * scale,
                            top + calibration.ay.toFloat() * calibrationScaleY * scale
                        ),
                        end = Offset(
                            left + calibration.bx.toFloat() * calibrationScaleX * scale,
                            top + calibration.by.toFloat() * calibrationScaleY * scale
                        ),
                        strokeWidth = 2f
                    )

                    // 궤적 선: 지금 프레임까지 지나온 길
                    val currentFrame = data.windowStartFrame + frameOffset
                    var previous: Offset? = null
                    for (p in data.points) {
                        if (p.isOutlier) continue
                        if (p.frameIndex > currentFrame) continue
                        val position = Offset(left + p.x.toFloat() * scale, top + p.y.toFloat() * scale)
                        val last = previous
                        if (last != null) {
                            drawLine(color = ColorTrackAuto, start = last, end = position, strokeWidth = 3f)
                        }
                        previous = position
                    }

                    // 궤적 점
                    for (p in data.points) {
                        val position = Offset(left + p.x.toFloat() * scale, top + p.y.toFloat() * scale)
                        var color = ColorTrackAuto
                        if (p.isManual) color = ColorTrackManual
                        if (p.isOutlier) color = ColorTrackOutlier
                        // 아직 안 지나간 점은 흐리게
                        val alpha = if (p.frameIndex <= currentFrame) 1f else 0.35f
                        drawCircle(color = color, radius = 4.5f, center = position, alpha = alpha)
                        if (p.frameIndex == currentFrame) {
                            drawCircle(color = Color.White, radius = 18f, center = position, style = Stroke(width = 3f))
                        }
                    }
                }

                // 프레임 정보
                val elapsedMs = (data.windowTimesNs[frameOffset] - data.windowTimesNs[0]) / 1_000_000.0
                Text(
                    text = "프레임 ${frameOffset + 1}/$frameCount · ${formatOne(elapsedMs)} ms",
                    fontSize = 13.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )

                if (editMode) {
                    Text(
                        text = "수정 모드: 공을 탭하면 이 프레임의 위치로 저장됩니다",
                        fontSize = 13.sp,
                        color = ColorTrackManual,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color(0xAA000000), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                if (!cacheReady) {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (cacheFailed) {
                            Text(text = "리플레이 영상을 읽을 수 없습니다.", fontSize = 15.sp, color = ColorWarning)
                        } else {
                            Text(text = "리플레이 준비 중…", fontSize = 15.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(progress = { cacheProgress })
                        }
                    }
                }
            }

            // 프레임 위치 슬라이더
            if (frameCount > 1) {
                Slider(
                    value = frameOffset.toFloat(),
                    onValueChange = { value ->
                        playing = false
                        frameOffset = value.roundToInt().coerceIn(0, frameCount - 1)
                    },
                    valueRange = 0f..(frameCount - 1).toFloat(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .height(32.dp)
                )
            }

            // 재생 조작
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SmallButton(text = "◀", onClick = {
                    playing = false
                    if (frameOffset > 0) frameOffset--
                })
                SmallButton(
                    text = if (playing) "정지" else "재생",
                    color = ColorAccent,
                    onClick = {
                        playing = !playing
                        if (playing) editMode = false
                    }
                )
                SmallButton(text = "▶", onClick = {
                    playing = false
                    if (frameOffset < frameCount - 1) frameOffset++
                })
                SmallButton(
                    text = if (frameDelayMs >= 150) "아주 느리게" else if (frameDelayMs >= 66) "느리게" else "빠르게",
                    onClick = {
                        // 누를 때마다 재생 속도를 바꾼다
                        frameDelayMs = if (frameDelayMs >= 150) 33 else if (frameDelayMs >= 66) 150 else 66
                    }
                )
                SmallButton(
                    text = if (editMode) "수정 끝" else "공 위치 수정",
                    color = if (editMode) Color(0xFF1E88C8) else ColorSecondary,
                    onClick = {
                        editMode = !editMode
                        if (editMode) playing = false
                    }
                )
            }

            if (editMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SmallButton(text = "이 프레임 점 삭제", onClick = {
                        val frameIndex = data.windowStartFrame + frameOffset
                        val iterator = data.points.iterator()
                        while (iterator.hasNext()) {
                            if (iterator.next().frameIndex == frameIndex) iterator.remove()
                        }
                        PitchAnalyzer.computeSpeed(data)
                        version++
                    })
                    SmallButton(text = "점 전부 삭제", onClick = {
                        data.points.clear()
                        PitchAnalyzer.computeSpeed(data)
                        version++
                    })
                }
            }
        }

        // ======================= 오른쪽: 속도와 기록 =======================
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // version을 읽어서 점이 바뀌면 이 부분도 다시 그린다
            val shownVersion = version
            val speed = if (shownVersion >= 0) data.speed else null

            if (speed != null && speed.ok) {
                Text(text = "릴리스 직후 속도", fontSize = 14.sp, color = ColorDim)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = formatOne(speed.releaseKmh),
                        fontSize = 64.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorAccent
                    )
                    Text(text = " km/h", fontSize = 24.sp, modifier = Modifier.padding(bottom = 12.dp))
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = formatOne(SpeedCalculator.kmhToMph(speed.releaseKmh)),
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = " mph", fontSize = 20.sp, modifier = Modifier.padding(bottom = 8.dp))
                }
                Text(
                    text = "예상 오차 ± ${formatOne(speed.errorKmh)} km/h",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (speed.errorKmh <= 2.0) ColorGood else ColorWarning
                )

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "평균 속도  ${formatOne(speed.averageKmh)} km/h · " +
                            "${formatOne(SpeedCalculator.kmhToMph(speed.averageKmh))} mph",
                    fontSize = 17.sp
                )
                if (!speed.gateKmh.isNaN()) {
                    val gateLabel = if (speed.gateUsesReferenceLine) "기준선 구간 속도" else "구간 통과 속도"
                    Text(
                        text = "$gateLabel  ${formatOne(speed.gateKmh)} km/h · " +
                                "${formatOne(SpeedCalculator.kmhToMph(speed.gateKmh))} mph",
                        fontSize = 17.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "실측 ${formatOne(speed.measuredFps)} fps" +
                            (if (data.exposureNs > 0L) " · 셔터 ${formatShutter(data.exposureNs)}" else "") +
                            "\n추적 ${speed.usedPointCount}점 · 잔차 ${formatTwo(speed.residualRmsPx)} px · ${speed.releaseModel}" +
                            "\n시간 기준: " + (if (data.timestampsExact) "센서 타임스탬프(ns)" else if (data.isImported) "영상 파일 시간" else "인코더 시간(µs)") +
                            "\n오차 내역: 보정 ±${formatTwo(speed.errorCalibrationKmh)} · 시간 ±${formatTwo(speed.errorTimingKmh)} · 피팅 ±${formatTwo(speed.errorFitKmh)}",
                    fontSize = 12.sp,
                    color = ColorDim,
                    lineHeight = 17.sp
                )
            } else {
                Text(text = "속도를 계산하지 못했습니다", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ColorWarning)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = (if (speed != null && speed.message.isNotEmpty()) speed.message + "\n" else "") +
                            "'공 위치 수정'을 눌러 프레임을 넘기면서 공을 3번 이상 직접 탭하면 계산됩니다.",
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = memo,
                onValueChange = { text -> memo = text },
                label = { Text("메모") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            BigButton(
                text = if (savedId > 0L) "기록 다시 저장" else "기록에 저장",
                modifier = Modifier.fillMaxWidth(),
                onClick = { saveRecord() }
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallButton(
                    text = if (savedId > 0L || data.isImported) "돌아가기" else "다시 측정",
                    modifier = Modifier.weight(1f),
                    onClick = { navController.popBackStack() }
                )
                SmallButton(
                    text = "영상 내보내기",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val needsPermission = Build.VERSION.SDK_INT < 29 &&
                                ContextCompat.checkSelfPermission(
                                    context, Manifest.permission.WRITE_EXTERNAL_STORAGE
                                ) != PackageManager.PERMISSION_GRANTED
                        if (needsPermission) {
                            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        } else {
                            exportToGallery()
                        }
                    }
                )
            }
            if (infoText.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = infoText, fontSize = 14.sp, color = ColorGood)
            }
        }
    }
}

package com.pitchspeed.app.camera

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer

/** 인코딩된 프레임 하나 */
class EncodedFrame(
    val data: ByteArray,
    val ptsUs: Long,        // 인코더 시간 (마이크로초). 카메라 센서 타임스탬프에서 온 값이다.
    val isKeyFrame: Boolean
)

/**
 * 카메라 프레임을 H.264로 계속 인코딩하면서, 최근 몇 초 분량을 메모리에 들고 있는 링 버퍼.
 *
 * 항상 녹화 중인 상태라서, 움직임을 감지한 "뒤에" 저장을 시작해도
 * 감지 이전 1초를 포함해서 잘라낼 수 있다.
 */
class EncoderRingBuffer(
    private val width: Int,
    private val height: Int,
    private val fps: Int
) {
    /** 카메라가 프레임을 써 넣을 Surface (start() 이후에 생긴다) */
    var inputSurface: Surface? = null

    private var codec: MediaCodec? = null
    private var callbackThread: HandlerThread? = null
    private var outputFormat: MediaFormat? = null

    private val lock = Any()
    private val frames = ArrayDeque<EncodedFrame>()

    companion object {
        // 메모리에 들고 있을 길이: 8초
        private const val RING_DURATION_US = 8_000_000L
    }

    fun start() {
        // 비트레이트: 픽셀 수와 fps에 비례, 최대 60Mbps
        var bitrate = (width.toLong() * height * fps * 0.08).toLong()
        if (bitrate > 60_000_000L) bitrate = 60_000_000L
        if (bitrate < 4_000_000L) bitrate = 4_000_000L

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate.toInt())
        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        // 키프레임을 0.5초마다 넣는다 (클립은 키프레임부터 시작해야 해서 촘촘할수록 좋다)
        format.setFloat(MediaFormat.KEY_I_FRAME_INTERVAL, 0.5f)
        format.setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
        format.setInteger(MediaFormat.KEY_PRIORITY, 0)

        val thread = HandlerThread("encoder")
        thread.start()
        callbackThread = thread

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.setCallback(codecCallback, Handler(thread.looper))
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = encoder.createInputSurface()
        encoder.start()
        codec = encoder
    }

    fun stop() {
        val encoder = codec
        codec = null
        if (encoder != null) {
            try {
                encoder.stop()
            } catch (e: Exception) {
            }
            try {
                encoder.release()
            } catch (e: Exception) {
            }
        }
        inputSurface?.release()
        inputSurface = null
        callbackThread?.quitSafely()
        callbackThread = null
        synchronized(lock) {
            frames.clear()
        }
    }

    /** 가장 최근에 인코딩된 프레임의 시간. 아직 없으면 -1 */
    fun latestPtsUs(): Long {
        synchronized(lock) {
            if (frames.isEmpty()) return -1L
            return frames.last().ptsUs
        }
    }

    private val codecCallback = object : MediaCodec.Callback() {
        override fun onInputBufferAvailable(codec: MediaCodec, index: Int) {
            // 입력은 Surface로 들어오므로 할 일이 없다
        }

        override fun onOutputBufferAvailable(codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
            try {
                val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                val buffer = codec.getOutputBuffer(index)
                if (buffer != null && info.size > 0 && !isConfig) {
                    val data = ByteArray(info.size)
                    buffer.position(info.offset)
                    buffer.limit(info.offset + info.size)
                    buffer.get(data)
                    val isKey = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0

                    synchronized(lock) {
                        frames.addLast(EncodedFrame(data, info.presentationTimeUs, isKey))
                        // 오래된 프레임 버리기
                        val oldestAllowed = info.presentationTimeUs - RING_DURATION_US
                        while (frames.isNotEmpty() && frames.first().ptsUs < oldestAllowed) {
                            frames.removeFirst()
                        }
                    }
                }
                codec.releaseOutputBuffer(index, false)
            } catch (e: IllegalStateException) {
                // 멈추는 중이면 무시
            }
        }

        override fun onError(codec: MediaCodec, e: MediaCodec.CodecException) {
        }

        override fun onOutputFormatChanged(codec: MediaCodec, format: MediaFormat) {
            outputFormat = format
        }
    }

    /**
     * 링 버퍼에서 [startPtsUs, endPtsUs] 구간을 MP4 파일로 저장한다.
     * 영상은 키프레임부터 시작해야 하므로, 실제 시작은 startPtsUs 이전의 마지막 키프레임이다.
     *
     * 돌려주는 값: 저장된 각 프레임의 원래 인코더 시간(µs). 실패하면 null.
     */
    fun saveClip(startPtsUs: Long, endPtsUs: Long, file: File, rotation: Int): LongArray? {
        val format = outputFormat ?: return null

        val selected = ArrayList<EncodedFrame>()
        synchronized(lock) {
            var firstKeyIndex = -1
            var lastKeyBeforeStart = -1
            for (i in 0 until frames.size) {
                val frame = frames[i]
                if (frame.isKeyFrame) {
                    if (firstKeyIndex < 0) firstKeyIndex = i
                    if (frame.ptsUs <= startPtsUs) lastKeyBeforeStart = i
                }
            }
            val startIndex = if (lastKeyBeforeStart >= 0) lastKeyBeforeStart else firstKeyIndex
            if (startIndex < 0) return null

            for (i in startIndex until frames.size) {
                val frame = frames[i]
                if (frame.ptsUs > endPtsUs) break
                selected.add(frame)
            }
        }
        if (selected.size < 3) return null

        try {
            val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer.setOrientationHint(rotation)
            val track = muxer.addTrack(format)
            muxer.start()

            val info = MediaCodec.BufferInfo()
            val firstPts = selected[0].ptsUs
            for (frame in selected) {
                val flags = if (frame.isKeyFrame) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, frame.data.size, frame.ptsUs - firstPts, flags)
                muxer.writeSampleData(track, ByteBuffer.wrap(frame.data), info)
            }
            muxer.stop()
            muxer.release()
        } catch (e: Exception) {
            file.delete()
            return null
        }

        val result = LongArray(selected.size)
        for (i in selected.indices) {
            result[i] = selected[i].ptsUs
        }
        return result
    }
}

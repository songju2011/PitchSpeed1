package com.pitchspeed.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.view.SurfaceView
import com.pitchspeed.app.analysis.VideoFrameReader
import com.pitchspeed.app.camera.EncoderRingBuffer
import java.io.ByteArrayOutputStream
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.camera.CaptureConfig
import com.pitchspeed.app.camera.CaptureConfigFinder
import com.pitchspeed.app.camera.HighSpeedCameraController
import com.pitchspeed.app.camera.MotionDetector
import com.pitchspeed.app.data.AppSession
import kotlinx.coroutines.launch

/** 카메라 설정을 찾는다. 카메라에 접근할 수 없으면 null */
fun findCaptureConfigOrNull(context: android.content.Context): CaptureConfig? {
    return try {
        CaptureConfigFinder.findBest(context)
    } catch (e: Exception) {
        null
    }
}

/**
 * 2-1. 거리 보정용 화면 캡처.
 * 삼각대에 고정하고 구도를 잡은 뒤, 지금 화면을 한 장 찍어서 그 위에 기준 길이를 표시한다.
 * 측정할 때와 똑같은 해상도·화각을 써야 하므로 같은 촬영 설정으로 미리보기를 연다.
 */
@Composable
fun CalibCaptureScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val config = remember { findCaptureConfigOrNull(context) }
    if (config == null) {
        MessageScreen(text = "카메라를 사용할 수 없습니다.", onBack = { navController.popBackStack() })
        return
    }

    val controller = remember { HighSpeedCameraController(context) }
    // 측정 때와 똑같이 인코더로 녹화하면서, 거기서 보정용 사진을 한 장 뽑는다
    val encoder = remember { EncoderRingBuffer(config.width, config.height, config.fps) }
    var errorText by remember { mutableStateOf("") }
    var surfaceView by remember { mutableStateOf<SurfaceView?>(null) }
    var capturing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        controller.onError = { text -> errorText = text }
        onDispose {
            controller.close()
            encoder.stop()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        CameraPreview(
            config = config,
            modifier = Modifier.align(Alignment.Center),
            onSurfaceReady = { view, surface ->
                try {
                    encoder.start()
                    controller.open(config, surface, encoder.inputSurface)
                    surfaceView = view
                } catch (e: Exception) {
                    errorText = "인코더를 시작할 수 없습니다: " + e.message
                }
            },
            onSurfaceDestroyed = {
                surfaceView = null
                controller.close()
                encoder.stop()
            }
        )

        // 안내 문구
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(text = "구도 잡기", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "삼각대에 고정하고, 기준 길이(예: 투수판~홈플레이트)와\n공이 지나갈 길이 화면에 들어오게 맞추세요.",
                fontSize = 14.sp
            )
            if (errorText.isNotEmpty()) {
                Text(text = errorText, fontSize = 14.sp, color = ColorWarning)
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SmallButton(text = "뒤로", onClick = { navController.popBackStack() })
            BigButton(
                text = "이 화면으로 보정하기",
                enabled = surfaceView != null && !capturing,
                onClick = {
                    if (surfaceView != null) {
                        capturing = true
                        scope.launch {
                            val rotation = controller.recordingRotation
                            val bitmap = withContext(Dispatchers.IO) {
                                grabCalibrationFrame(context, encoder, rotation)
                            }
                            capturing = false
                            if (bitmap == null) {
                                errorText = "화면을 캡처하지 못했습니다. 다시 눌러 주세요."
                            } else {
                                AppSession.calibrationBitmap = bitmap
                                AppSession.calibrationIsForImport = false
                                AppSession.liveLens = controller.lensModel
                                // 보정 사진은 녹화 해상도를 회전만 한 것이라 픽셀 크기가 같다
                                AppSession.liveFocalPx = controller.focalPxForImage(config.width, config.height)
                                navController.navigate("calibrate")
                            }
                        }
                    }
                }
            )
        }
    }
}

/**
 * 인코더 링 버퍼에서 최근 0.4초를 잘라 임시 영상으로 저장하고, 그 첫 프레임을 사진으로 꺼낸다.
 * 측정 후 분석할 때 쓰는 것과 똑같은 경로(인코더 → 영상 → 디코더 → 회전 적용)라서
 * 사진의 방향과 크기가 분석 영상과 항상 같다. 실패하면 null.
 * 백그라운드 스레드에서 불러야 한다.
 */
fun grabCalibrationFrame(context: Context, encoder: EncoderRingBuffer, rotation: Int): Bitmap? {
    val latest = encoder.latestPtsUs()
    if (latest < 0L) return null

    val file = File(context.cacheDir, "calib_clip.mp4")
    val saved = encoder.saveClip(latest - 400_000L, latest, file, rotation)
    if (saved == null) return null

    val reader = VideoFrameReader(file.absolutePath)
    var result: Bitmap? = null
    try {
        if (reader.open(wantColor = true, seekToUs = 0L) && reader.advance()) {
            // NV21 → JPEG → 비트맵
            val jpegStream = ByteArrayOutputStream()
            val yuv = YuvImage(reader.nv21, ImageFormat.NV21, reader.codedWidth, reader.codedHeight, null)
            yuv.compressToJpeg(Rect(0, 0, reader.codedWidth, reader.codedHeight), 95, jpegStream)
            val jpegBytes = jpegStream.toByteArray()
            val decoded = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
            if (decoded != null) {
                if (reader.rotation == 0) {
                    result = decoded
                } else {
                    // 분석 때와 똑같이 영상의 회전 값을 적용해서 똑바로 세운다
                    val matrix = Matrix()
                    matrix.postRotate(reader.rotation.toFloat())
                    result = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                }
            }
        }
    } finally {
        reader.close()
        file.delete()
    }
    return result
}

/** 안내 문구 하나와 뒤로 버튼만 있는 화면 (오류 상황용) */
@Composable
fun MessageScreen(text: String, onBack: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = text, fontSize = 18.sp)
            BigButton(text = "뒤로", onClick = onBack)
        }
    }
}

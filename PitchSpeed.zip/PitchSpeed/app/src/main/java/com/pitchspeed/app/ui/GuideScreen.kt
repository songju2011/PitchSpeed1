package com.pitchspeed.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.data.CalibrationStore

/** 1. 촬영 가이드 */
@Composable
fun GuideScreen(navController: NavController) {
    val context = LocalContext.current
    val savedCalibration = remember { CalibrationStore.load(context) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) {
        // 왼쪽: 가이드 내용
        Column(
            modifier = Modifier
                .weight(1.6f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
        ) {
            Text(text = "촬영 가이드", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            GuideLine("1", "옆에서 직각으로", "공이 날아가는 방향과 직각이 되게 옆에서 찍습니다. 비스듬하면 속도가 낮게 나옵니다.")
            GuideLine("2", "삼각대로 고정", "측정 중에는 휴대폰이 조금도 움직이면 안 됩니다. 보정한 뒤에 움직였으면 다시 보정하세요.")
            GuideLine("3", "밝은 곳에서", "셔터를 1/2000초로 짧게 쓰기 때문에 빛이 많이 필요합니다. 낮의 야외가 가장 좋습니다.")
            GuideLine("4", "공이 지나가는 길을 화면에", "릴리스 지점부터 최소 3~4m 이상이 화면에 들어오게 잡습니다. 길게 잡을수록 정확합니다.")
            GuideLine("5", "기준 길이는 공과 같은 거리에", "보정에 쓰는 기준 길이(투수판~홈플레이트 등)는 공이 날아가는 선 위에 있어야 합니다. 카메라에서 더 가깝거나 멀면 그만큼 오차가 생깁니다.")
            GuideLine("6", "배경은 단순하게", "공 뒤로 사람이나 차가 움직이면 추적이 흔들립니다. 흰 공이 잘 보이는 어두운 배경이 좋습니다.")
        }

        Spacer(modifier = Modifier.width(24.dp))

        // 오른쪽: 다음 단계 버튼
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
        ) {
            BigButton(
                text = "거리 보정 하러 가기",
                modifier = Modifier.fillMaxWidth(),
                onClick = { navController.navigate("calib_capture") }
            )
            if (savedCalibration != null) {
                BigButton(
                    text = "지난번 보정 그대로 측정",
                    modifier = Modifier.fillMaxWidth(),
                    color = ColorSecondary,
                    onClick = { navController.navigate("measure") }
                )
                Text(
                    text = "카메라 위치와 구도가 지난번과 똑같을 때만 쓰세요.",
                    fontSize = 13.sp,
                    color = ColorDim
                )
            }
            SmallButton(
                text = "뒤로",
                modifier = Modifier.fillMaxWidth(),
                onClick = { navController.popBackStack() }
            )
        }
    }
}

@Composable
private fun GuideLine(number: String, title: String, body: String) {
    Row(modifier = Modifier.padding(vertical = 7.dp)) {
        Text(
            text = number,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = ColorAccent,
            modifier = Modifier.width(30.dp)
        )
        Column {
            Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(text = body, fontSize = 15.sp, color = ColorDim)
        }
    }
}

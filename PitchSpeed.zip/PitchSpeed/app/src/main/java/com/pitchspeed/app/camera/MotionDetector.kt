package com.pitchspeed.app.camera

import android.graphics.Bitmap
import android.os.Handler
import android.os.HandlerThread
import android.view.PixelCopy
import android.view.SurfaceView
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * 미리보기 화면에서 움직임을 감지한다 (자동 녹화 시작용).
 *
 * 고속 촬영 세션에서는 YUV 프레임을 따로 받을 수 없어서,
 * 미리보기 화면을 작게(160x90) 복사해 직전 화면과 비교한다.
 * 복사와 비교는 모두 백그라운드 스레드에서 한다.
 */
class MotionDetector(private val surfaceView: SurfaceView) {

    private val smallWidth = 160
    private val smallHeight = 90
    private val bitmap = Bitmap.createBitmap(smallWidth, smallHeight, Bitmap.Config.ARGB_8888)
    private val pixels = IntArray(smallWidth * smallHeight)
    private val previousGray = IntArray(smallWidth * smallHeight)
    private var hasPrevious = false

    private val thread = HandlerThread("motion")
    private val handler: Handler

    init {
        thread.start()
        handler = Handler(thread.looper)
    }

    fun release() {
        thread.quitSafely()
    }

    /** 직전 화면 기억을 지운다 (노출이 바뀐 직후 등) */
    fun reset() {
        hasPrevious = false
    }

    /**
     * 직전에 잰 화면과 비교해서 "움직인 픽셀의 비율"(0~1)을 돌려준다.
     * 화면 복사에 실패했거나 비교할 직전 화면이 없으면 -1.
     */
    suspend fun measure(): Float {
        return suspendCancellableCoroutine { continuation ->
            try {
                PixelCopy.request(surfaceView, bitmap, { copyResult ->
                    var fraction = -1f
                    if (copyResult == PixelCopy.SUCCESS) {
                        fraction = compare()
                    }
                    if (continuation.isActive) {
                        continuation.resume(fraction)
                    }
                }, handler)
            } catch (e: Exception) {
                // Surface가 아직 없거나 이미 사라진 경우
                if (continuation.isActive) {
                    continuation.resume(-1f)
                }
            }
        }
    }

    private fun compare(): Float {
        bitmap.getPixels(pixels, 0, smallWidth, 0, 0, smallWidth, smallHeight)
        var changed = 0
        for (i in pixels.indices) {
            // 초록 채널을 밝기 대신 쓴다
            val gray = (pixels[i] shr 8) and 0xFF
            if (hasPrevious) {
                var diff = gray - previousGray[i]
                if (diff < 0) diff = -diff
                if (diff > 24) changed++
            }
            previousGray[i] = gray
        }
        if (!hasPrevious) {
            hasPrevious = true
            return -1f
        }
        return changed.toFloat() / pixels.size
    }

    companion object {
        /** 미리보기 화면을 원하는 크기의 비트맵으로 복사한다 (거리 보정용 정지 화면). 실패하면 null */
        suspend fun captureBitmap(surfaceView: SurfaceView, width: Int, height: Int): Bitmap? {
            val target = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val captureThread = HandlerThread("capture")
            captureThread.start()
            val result = suspendCancellableCoroutine<Bitmap?> { continuation ->
                try {
                    PixelCopy.request(surfaceView, target, { copyResult ->
                        if (continuation.isActive) {
                            if (copyResult == PixelCopy.SUCCESS) {
                                continuation.resume(target)
                            } else {
                                continuation.resume(null)
                            }
                        }
                    }, Handler(captureThread.looper))
                } catch (e: Exception) {
                    if (continuation.isActive) {
                        continuation.resume(null)
                    }
                }
            }
            captureThread.quitSafely()
            return result
        }
    }
}

package com.pitchspeed.app.camera

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.media.MediaCodec

/** 촬영 설정 한 벌: 어느 카메라로, 어떤 해상도와 fps로 찍을지 */
class CaptureConfig(
    val cameraId: String,
    val width: Int,
    val height: Int,
    val fps: Int,                   // 녹화 fps (고정)
    val previewOnlyFpsLower: Int,   // 녹화 없이 미리보기만 할 때 쓸 fps 범위의 아래쪽 값
    val isHighSpeed: Boolean        // 고속 촬영 세션(CameraConstrainedHighSpeedCaptureSession)을 쓰는지
)

object CaptureConfigFinder {

    /**
     * 기기가 지원하는 고속 촬영 해상도/fps 목록을 조회해서 가장 높은 fps를 고른다.
     * fps가 같으면 해상도가 큰 쪽을 고른다 (가로 1920 이하).
     * 고속 촬영을 지원하지 않는 기기는 일반 촬영 중 가장 높은 fps로 대신한다.
     */
    fun findBest(context: Context): CaptureConfig? {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        var best: CaptureConfig? = null

        // ---------- 1. 고속 촬영 설정 찾기 ----------
        for (cameraId in manager.cameraIdList) {
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
            if (facing != CameraCharacteristics.LENS_FACING_BACK) continue

            val capabilities = characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            if (capabilities == null) continue
            var supportsHighSpeed = false
            for (capability in capabilities) {
                if (capability == CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO) {
                    supportsHighSpeed = true
                }
            }
            if (!supportsHighSpeed) continue

            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (map == null) continue

            for (size in map.highSpeedVideoSizes) {
                if (size.width > 1920) continue
                val ranges = map.getHighSpeedVideoFpsRangesFor(size)

                for (range in ranges) {
                    // 녹화에는 [240, 240]처럼 위아래가 같은 고정 범위만 쓴다
                    if (range.lower != range.upper) continue
                    val fps = range.upper

                    // 미리보기만 할 때는 [30, 240]처럼 아래가 낮은 범위가 있으면 그걸 쓴다
                    var previewLower = fps
                    for (other in ranges) {
                        if (other.upper == fps && other.lower < previewLower) {
                            previewLower = other.lower
                        }
                    }

                    val current = best
                    var better = false
                    if (current == null) {
                        better = true
                    } else if (fps > current.fps) {
                        better = true
                    } else if (fps == current.fps && size.width * size.height > current.width * current.height) {
                        better = true
                    }
                    if (better) {
                        best = CaptureConfig(cameraId, size.width, size.height, fps, previewLower, true)
                    }
                }
            }
        }
        if (best != null) return best

        // ---------- 2. 고속 촬영이 없으면 일반 촬영 중 최대 fps ----------
        for (cameraId in manager.cameraIdList) {
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
            if (facing != CameraCharacteristics.LENS_FACING_BACK) continue

            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (map == null) continue
            val sizes = map.getOutputSizes(MediaCodec::class.java)
            if (sizes == null || sizes.isEmpty()) continue

            // 1920x1080이 있으면 그걸, 없으면 1280x720, 그것도 없으면 1920 이하에서 가장 큰 것
            var width = 0
            var height = 0
            for (size in sizes) {
                if (size.width == 1920 && size.height == 1080) {
                    width = 1920
                    height = 1080
                }
            }
            if (width == 0) {
                for (size in sizes) {
                    if (size.width == 1280 && size.height == 720) {
                        width = 1280
                        height = 720
                    }
                }
            }
            if (width == 0) {
                for (size in sizes) {
                    if (size.width <= 1920 && size.width * size.height > width * height) {
                        width = size.width
                        height = size.height
                    }
                }
            }
            if (width == 0) continue

            var fps = 30
            val fpsRanges = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            if (fpsRanges != null) {
                for (range in fpsRanges) {
                    if (range.lower == range.upper && range.upper > fps) {
                        fps = range.upper
                    }
                }
            }
            return CaptureConfig(cameraId, width, height, fps, fps, false)
        }
        return null
    }
}

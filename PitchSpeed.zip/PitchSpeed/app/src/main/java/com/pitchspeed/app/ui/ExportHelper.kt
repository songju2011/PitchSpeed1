package com.pitchspeed.app.ui

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * 리플레이 영상을 갤러리(Movies/PitchSpeed)로 복사한다.
 * 백그라운드 스레드에서 불러야 한다.
 *
 * 안드로이드 10 이상: MediaStore로 저장 (권한 필요 없음)
 * 안드로이드 9 이하: 공용 Movies 폴더에 직접 복사 (WRITE_EXTERNAL_STORAGE 권한 필요)
 */
fun exportVideoToGallery(context: Context, videoPath: String): Boolean {
    val source = File(videoPath)
    if (!source.exists()) return false
    val displayName = "PitchSpeed_" + System.currentTimeMillis() + ".mp4"

    try {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues()
            values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PitchSpeed")
            values.put(MediaStore.Video.Media.IS_PENDING, 1)

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            val output = resolver.openOutputStream(uri) ?: return false
            val input = FileInputStream(source)
            input.copyTo(output)
            input.close()
            output.close()

            val done = ContentValues()
            done.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, done, null, null)
            return true
        } else {
            @Suppress("DEPRECATION")
            val movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val directory = File(movies, "PitchSpeed")
            directory.mkdirs()
            val target = File(directory, displayName)
            val input = FileInputStream(source)
            val output = FileOutputStream(target)
            input.copyTo(output)
            input.close()
            output.close()
            MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf("video/mp4"), null)
            return true
        }
    } catch (e: Exception) {
        return false
    }
}

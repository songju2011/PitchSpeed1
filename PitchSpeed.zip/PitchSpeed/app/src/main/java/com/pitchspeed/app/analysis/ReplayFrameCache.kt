package com.pitchspeed.app.analysis

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import java.io.File
import java.io.FileOutputStream

/**
 * 슬로모션 리플레이용 프레임 이미지 캐시.
 *
 * 리플레이는 한 프레임씩 앞뒤로 넘기고, 프레임 위에 직접 탭해서 공 위치를 고쳐야 한다.
 * 그래서 영상의 필요한 구간을 프레임별 JPEG로 풀어 두고 이미지처럼 넘겨 본다.
 * (캐시 폴더라서 지워져도 영상에서 다시 만들면 된다)
 */
object ReplayFrameCache {

    fun directoryFor(context: Context, videoPath: String): File {
        val name = File(videoPath).nameWithoutExtension
        return File(context.cacheDir, "replay_$name")
    }

    private fun frameFile(directory: File, frameIndex: Int): File {
        return File(directory, "f_$frameIndex.jpg")
    }

    /**
     * 영상의 windowStartPtsUs 시점부터 frameCount 장을 JPEG로 저장한다.
     * 이미 만들어져 있으면 바로 true.
     */
    fun build(
        context: Context,
        videoPath: String,
        windowStartFrame: Int,
        windowStartPtsUs: Long,
        frameCount: Int,
        halfRes: Boolean,
        onProgress: (Float) -> Unit
    ): Boolean {
        val directory = directoryFor(context, videoPath)
        val doneMarker = File(directory, "done")
        if (doneMarker.exists()) return true

        // 다른 영상의 캐시는 지워서 저장 공간을 아낀다
        val siblings = context.cacheDir.listFiles()
        if (siblings != null) {
            for (file in siblings) {
                if (file.isDirectory && file.name.startsWith("replay_") && file.name != directory.name) {
                    file.deleteRecursively()
                }
            }
        }
        directory.deleteRecursively()
        directory.mkdirs()

        val reader = VideoFrameReader(videoPath)
        if (!reader.open(wantColor = true, seekToUs = windowStartPtsUs)) return false

        val fullWidth = reader.codedWidth
        val fullHeight = reader.codedHeight
        // 절반 크기 (짝수로 맞춘다)
        val halfWidth = (fullWidth / 2) and 1.inv()
        val halfHeight = (fullHeight / 2) and 1.inv()
        val halfBuffer = if (halfRes) ByteArray(halfWidth * halfHeight * 3 / 2) else ByteArray(0)

        var written = 0
        try {
            while (written < frameCount && reader.advance()) {
                // 키프레임부터 디코딩되므로, 원하는 시작 시점 전의 프레임은 건너뛴다
                if (reader.currentPtsUs < windowStartPtsUs) continue

                val file = frameFile(directory, windowStartFrame + written)
                val stream = FileOutputStream(file)
                if (halfRes) {
                    shrinkNv21ByHalf(reader.nv21, fullWidth, fullHeight, halfBuffer, halfWidth, halfHeight)
                    val image = YuvImage(halfBuffer, ImageFormat.NV21, halfWidth, halfHeight, null)
                    image.compressToJpeg(Rect(0, 0, halfWidth, halfHeight), 80, stream)
                } else {
                    val image = YuvImage(reader.nv21, ImageFormat.NV21, fullWidth, fullHeight, null)
                    image.compressToJpeg(Rect(0, 0, fullWidth, fullHeight), 88, stream)
                }
                stream.close()

                written++
                if (written % 5 == 0) {
                    onProgress(written.toFloat() / frameCount)
                }
            }
        } catch (e: Exception) {
            reader.close()
            return false
        }
        reader.close()

        if (written == 0) return false
        doneMarker.writeText("ok")
        return true
    }

    /** NV21 이미지를 가로세로 절반으로 줄인다 (2픽셀마다 하나씩 고름) */
    private fun shrinkNv21ByHalf(
        source: ByteArray, sourceWidth: Int, sourceHeight: Int,
        target: ByteArray, targetWidth: Int, targetHeight: Int
    ) {
        // 밝기
        for (y in 0 until targetHeight) {
            val sourceRow = (y * 2) * sourceWidth
            val targetRow = y * targetWidth
            for (x in 0 until targetWidth) {
                target[targetRow + x] = source[sourceRow + x * 2]
            }
        }
        // 색 (V,U 쌍 단위)
        val sourceChromaStart = sourceWidth * sourceHeight
        val targetChromaStart = targetWidth * targetHeight
        for (y in 0 until targetHeight / 2) {
            val sourceRow = sourceChromaStart + (y * 2) * sourceWidth
            val targetRow = targetChromaStart + y * targetWidth
            for (x in 0 until targetWidth / 2) {
                target[targetRow + x * 2] = source[sourceRow + x * 4]
                target[targetRow + x * 2 + 1] = source[sourceRow + x * 4 + 1]
            }
        }
    }

    /** 캐시에서 프레임 한 장을 읽는다. 회전이 필요하면 똑바로 세워서 돌려준다. 없으면 null */
    fun loadFrame(context: Context, videoPath: String, frameIndex: Int, rotation: Int): Bitmap? {
        val file = frameFile(directoryFor(context, videoPath), frameIndex)
        if (!file.exists()) return null
        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return null
        if (rotation == 0) return bitmap
        val matrix = Matrix()
        matrix.postRotate(rotation.toFloat())
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}

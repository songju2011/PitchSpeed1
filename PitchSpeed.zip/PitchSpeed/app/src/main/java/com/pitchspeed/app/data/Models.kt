package com.pitchspeed.app.data

import android.graphics.Bitmap
import com.pitchspeed.app.analysis.Calibration
import com.pitchspeed.app.analysis.LensModel
import com.pitchspeed.app.analysis.SpeedResult
import com.pitchspeed.app.analysis.TrackPoint

/** 분석할 영상 클립 하나에 대한 정보 */
class ClipInfo(
    val videoPath: String,
    val isImported: Boolean,                    // 갤러리에서 불러온 영상이면 true
    val clipPtsUs: LongArray?,                  // 직접 찍은 클립: 각 프레임의 영상 속 시간(µs). 불러온 영상이면 null
    val clipTimesNs: LongArray?,                // 같은 순서로, 각 프레임의 센서 타임스탬프(ns)
    val timestampsExact: Boolean,               // 센서 타임스탬프와 짝짓기에 성공했는지
    val timeScale: Double,                      // 영상 속 시간 × timeScale = 실제 시간 (슬로모션 영상용)
    val rollingShutterSkewNs: Long,             // 센서가 위에서 아래까지 읽는 데 걸리는 시간
    val exposureNs: Long,                       // 셔터 속도
    val iso: Int,
    val nominalFps: Int
)

/** 분석 결과 전체. 결과 화면이 이걸 보여주고, 사용자가 점을 고치면 다시 계산한다 */
class ResultData(
    val videoPath: String,
    val isImported: Boolean,
    val frameWidth: Int,
    val frameHeight: Int,
    val rotation: Int,                  // 영상을 똑바로 세우려면 돌려야 하는 각도
    val calibration: Calibration,
    val timestampsExact: Boolean,
    val rollingShutterSkewNs: Long,
    val exposureNs: Long,
    val iso: Int,
    val nominalFps: Int,
    val windowStartFrame: Int,          // 리플레이 구간의 첫 프레임 번호
    val windowStartPtsUs: Long,         // 그 프레임의 영상 속 시간
    val windowTimesNs: LongArray,       // 리플레이 구간 각 프레임의 실제 시간
    val replayHalfRes: Boolean,         // 리플레이 이미지를 절반 크기로 저장했는지
    val points: ArrayList<TrackPoint>,  // 공 궤적 (영상 픽셀 좌표)
    var speed: SpeedResult?
)

/**
 * 화면 사이에 주고받는 값들.
 * 화면이 몇 개 안 되므로 ViewModel 대신 전역 객체 하나에 그대로 둔다.
 */
object AppSession {
    /** 거리 보정 화면에 띄울 정지 화면 */
    var calibrationBitmap: Bitmap? = null

    /** true면 불러온 영상의 보정, false면 실시간 촬영의 보정 */
    var calibrationIsForImport: Boolean = false

    /** 지금 카메라의 초점거리 (보정 사진 픽셀 단위, 모르면 0) */
    var liveFocalPx: Double = 0.0

    /** 지금 카메라의 렌즈 왜곡 모델 (없으면 null) */
    var liveLens: LensModel? = null

    /** 분석을 기다리는 클립과 그때 쓸 보정 */
    var pendingClip: ClipInfo? = null
    var pendingCalibration: Calibration? = null

    /** 결과 화면에 보여줄 분석 결과 */
    var currentResult: ResultData? = null

    /** 지금 결과가 기록에 저장돼 있으면 그 id, 아니면 -1 */
    var currentRecordId: Long = -1L

    /** 지금 결과의 메모와 측정 날짜 (기록에서 열었을 때 채워진다) */
    var currentMemo: String = ""
    var currentDateMillis: Long = 0L
}

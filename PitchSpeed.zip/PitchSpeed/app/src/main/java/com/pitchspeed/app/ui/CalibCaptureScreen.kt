package com.pitchspeed.app.ui

import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.camera.CaptureConfig
import com.pitchspeed.app.camera.CaptureConfigFinder
import com.pitchspeed.app.camera.HighSpeedCameraController
import com.pitchspeed.app.camera.MotionDetector
import com.pitchspeed.app.data.AppSession
import kotlinx.coroutines.launch

/** 카메라 설정을 찾는다. 카메라에 접근할 수 없으면 null */
fun findCaptureConfigOrNull(context: android.content.Context): CaptureConfig? {
    return try {
        CaptureConfigFinder.findBest(context)
    } catch (e: Exception) {
        null
    }
}

/**
 * 2-1. 거리 보정용 화면 캡처.
 * 삼각대에 고정하고 구도를 잡은 뒤, 지금 화면을 한 장 찍어서 그 위에 기준 길이를 표시한다.
 * 측정할 때와 똑같은 해상도·화각을 써야 하므로 같은 촬영 설정으로 미리보기를 연다.
 */
@Composable
fun CalibCaptureScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val config = remember { findCaptureConfigOrNull(context) }
    if (config == null) {
        MessageScreen(text = "카메라를 사용할 수 없습니다.", onBack = { navController.popBackStack() })
        return
    }

    val controller = remember { HighSpeedCameraController(context) }
    var errorText by remember { mutableStateOf("") }
    var surfaceView by remember { mutableStateOf<SurfaceView?>(null) }
    var capturing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        controller.onError = { text -> errorText = text }
        onDispose {
            controller.close()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        CameraPreview(
            config = config,
            modifier = Modifier.align(Alignment.Center),
            onSurfaceReady = { view, surface ->
                // 녹화 없이 미리보기만
                controller.open(config, surface, null)
                surfaceView = view
            },
            onSurfaceDestroyed = {
                controller.close()
                surfaceView = null
            }
        )

        // 안내 문구
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(text = "구도 잡기", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "삼각대에 고정하고, 기준 길이(예: 투수판~홈플레이트)와\n공이 지나갈 길이 화면에 들어오게 맞추세요.",
                fontSize = 14.sp
            )
            if (errorText.isNotEmpty()) {
                Text(text = errorText, fontSize = 14.sp, color = ColorWarning)
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SmallButton(text = "뒤로", onClick = { navController.popBackStack() })
            BigButton(
                text = "이 화면으로 보정하기",
                enabled = surfaceView != null && !capturing,
                onClick = {
                    val view = surfaceView
                    if (view != null) {
                        capturing = true
                        scope.launch {
                            val bitmap = MotionDetector.captureBitmap(view, config.width, config.height)
                            capturing = false
                            if (bitmap == null) {
                                errorText = "화면을 캡처하지 못했습니다. 다시 눌러 주세요."
                            } else {
                                AppSession.calibrationBitmap = bitmap
                                AppSession.calibrationIsForImport = false
                                AppSession.liveLens = controller.lensModel
                                navController.navigate("calibrate")
                            }
                        }
                    }
                }
            )
        }
    }
}

/** 안내 문구 하나와 뒤로 버튼만 있는 화면 (오류 상황용) */
@Composable
fun MessageScreen(text: String, onBack: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = text, fontSize = 18.sp)
            BigButton(text = "뒤로", onClick = onBack)
        }
    }
}

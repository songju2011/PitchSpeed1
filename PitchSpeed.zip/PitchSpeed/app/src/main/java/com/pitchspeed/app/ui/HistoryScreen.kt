package com.pitchspeed.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.analysis.PitchAnalyzer
import com.pitchspeed.app.analysis.ReplayFrameCache
import com.pitchspeed.app.data.AppSession
import com.pitchspeed.app.data.JsonCodec
import com.pitchspeed.app.data.PitchDatabase
import com.pitchspeed.app.data.PitchRecord
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 5. 기록: 저장한 측정 결과 목록. 누르면 리플레이를 다시 보고, 삭제할 수 있다 */
@Composable
fun HistoryScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { PitchDatabase.get(context.applicationContext).pitchDao() }
    val recordsFlow = remember { dao.observeAll() }
    val records by recordsFlow.collectAsState(initial = emptyList())

    var recordToDelete by remember { mutableStateOf<PitchRecord?>(null) }
    var message by remember { mutableStateOf("") }
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    /** 기록을 열어 결과 화면으로 간다 */
    fun openRecord(record: PitchRecord) {
        try {
            val data = JsonCodec.resultFromJson(record.dataJson)
            if (!File(data.videoPath).exists()) {
                message = "이 기록의 영상 파일이 없어서 속도만 볼 수 있습니다."
            }
            PitchAnalyzer.computeSpeed(data)
            AppSession.currentResult = data
            AppSession.currentRecordId = record.id
            AppSession.currentMemo = record.memo
            AppSession.currentDateMillis = record.dateMillis
            navController.navigate("result")
        } catch (e: Exception) {
            message = "기록을 열 수 없습니다."
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SmallButton(text = "뒤로", onClick = { navController.popBackStack() })
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = "기록", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = "${records.size}개", fontSize = 16.sp, color = ColorDim)
            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = message, fontSize = 14.sp, color = ColorWarning)
            }
        }

        if (records.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "아직 저장한 기록이 없습니다.", fontSize = 17.sp, color = ColorDim)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(records, key = { record -> record.id }) { record ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .clickable { openRecord(record) }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 속도
                        Column(modifier = Modifier.width(230.dp)) {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = formatOne(record.kmh),
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ColorAccent
                                )
                                Text(text = " km/h", fontSize = 15.sp, modifier = Modifier.padding(bottom = 5.dp))
                            }
                            Text(
                                text = "${formatOne(record.mph)} mph · ± ${formatOne(record.errorKmh)} km/h",
                                fontSize = 14.sp,
                                color = ColorDim
                            )
                        }
                        // 날짜와 메모
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = dateFormat.format(Date(record.dateMillis)), fontSize = 15.sp)
                            Text(
                                text = "평균 ${formatOne(record.averageKmh)} km/h" +
                                        (if (record.memo.isNotEmpty()) " · " + record.memo else ""),
                                fontSize = 14.sp,
                                color = ColorDim,
                                maxLines = 2
                            )
                        }
                        SmallButton(
                            text = "삭제",
                            color = Color(0xFF8B2E2E),
                            onClick = { recordToDelete = record }
                        )
                    }
                }
            }
        }
    }

    // 삭제 확인
    val deleting = recordToDelete
    if (deleting != null) {
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = { Text("기록 삭제") },
            text = { Text("${formatOne(deleting.kmh)} km/h 기록과 리플레이 영상을 삭제할까요?") },
            confirmButton = {
                TextButton(onClick = {
                    recordToDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            dao.delete(deleting)
                            // 영상 파일과 리플레이 캐시도 같이 지운다
                            File(deleting.videoPath).delete()
                            ReplayFrameCache.directoryFor(context.applicationContext, deleting.videoPath)
                                .deleteRecursively()
                        }
                    }
                }) { Text("삭제") }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) { Text("취소") }
            }
        )
    }
}

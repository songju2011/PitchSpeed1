package com.pitchspeed.app.analysis

import kotlin.math.abs

/**
 * 다항식 최소제곱 피팅 결과.
 * value(t) = coef[0] + coef[1]*t + coef[2]*t²
 */
class PolyFitResult(
    val coef: DoubleArray,              // 계수 (차수+1 개)
    val covUnit: Array<DoubleArray>,    // (A'A)의 역행렬 — 잔차 분산을 곱하면 계수의 공분산이 된다
    val sse: Double,                    // 잔차 제곱합
    val n: Int,                         // 점 개수
    val degree: Int                     // 차수 (1 = 직선, 2 = 포물선)
) {
    fun valueAt(t: Double): Double {
        var result = 0.0
        var power = 1.0
        for (i in coef.indices) {
            result += coef[i] * power
            power *= t
        }
        return result
    }

    /** t에서의 기울기 (= 속도) */
    fun derivativeAt(t: Double): Double {
        var result = coef[1]
        if (degree >= 2) {
            result += 2.0 * coef[2] * t
        }
        return result
    }

    /** 잔차 분산. 자유도가 없으면 NaN */
    fun residualVariance(): Double {
        val dof = n - (degree + 1)
        if (dof <= 0) return Double.NaN
        return sse / dof
    }

    /** t에서의 기울기(속도)의 분산 — 잔차 분산 sigma2를 넣어서 계산 */
    fun derivativeVarianceAt(t: Double, sigma2: Double): Double {
        // 기울기 = g · coef, g = [0, 1, 2t]
        val g = DoubleArray(degree + 1)
        g[1] = 1.0
        if (degree >= 2) g[2] = 2.0 * t
        var sum = 0.0
        for (i in 0..degree) {
            for (j in 0..degree) {
                sum += g[i] * covUnit[i][j] * g[j]
            }
        }
        return sigma2 * sum
    }
}

object PolyFit {

    /**
     * (t, v) 점들을 degree차 다항식으로 최소제곱 피팅한다.
     * 점이 모자라거나 풀 수 없으면 null.
     */
    fun fit(t: DoubleArray, v: DoubleArray, degree: Int): PolyFitResult? {
        val n = t.size
        val m = degree + 1
        if (n < m) return null

        // 정규방정식 (A'A) c = A'v 를 만든다
        val ata = Array(m) { DoubleArray(m) }
        val atv = DoubleArray(m)
        for (k in 0 until n) {
            val powers = DoubleArray(m)
            var p = 1.0
            for (i in 0 until m) {
                powers[i] = p
                p *= t[k]
            }
            for (i in 0 until m) {
                atv[i] += powers[i] * v[k]
                for (j in 0 until m) {
                    ata[i][j] += powers[i] * powers[j]
                }
            }
        }

        val inverse = invert(ata) ?: return null

        val coef = DoubleArray(m)
        for (i in 0 until m) {
            var sum = 0.0
            for (j in 0 until m) {
                sum += inverse[i][j] * atv[j]
            }
            coef[i] = sum
        }

        // 잔차 제곱합
        var sse = 0.0
        for (k in 0 until n) {
            var predicted = 0.0
            var p = 1.0
            for (i in 0 until m) {
                predicted += coef[i] * p
                p *= t[k]
            }
            val residual = v[k] - predicted
            sse += residual * residual
        }

        return PolyFitResult(coef, inverse, sse, n, degree)
    }

    /** 작은 정사각 행렬의 역행렬 (가우스-조던 소거). 특이 행렬이면 null */
    private fun invert(matrix: Array<DoubleArray>): Array<DoubleArray>? {
        val m = matrix.size
        val a = Array(m) { i -> matrix[i].copyOf() }
        val inv = Array(m) { i -> DoubleArray(m).also { it[i] = 1.0 } }

        for (col in 0 until m) {
            // 피벗 찾기
            var pivotRow = col
            for (row in col + 1 until m) {
                if (abs(a[row][col]) > abs(a[pivotRow][col])) pivotRow = row
            }
            if (abs(a[pivotRow][col]) < 1e-18) return null

            val tmpA = a[col]; a[col] = a[pivotRow]; a[pivotRow] = tmpA
            val tmpI = inv[col]; inv[col] = inv[pivotRow]; inv[pivotRow] = tmpI

            val pivot = a[col][col]
            for (j in 0 until m) {
                a[col][j] /= pivot
                inv[col][j] /= pivot
            }
            for (row in 0 until m) {
                if (row == col) continue
                val factor = a[row][col]
                if (factor == 0.0) continue
                for (j in 0 until m) {
                    a[row][j] -= factor * a[col][j]
                    inv[row][j] -= factor * inv[col][j]
                }
            }
        }
        return inv
    }
}

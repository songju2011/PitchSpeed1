package com.pitchspeed.app.analysis

import kotlin.math.sqrt

/**
 * 공 후보 하나.
 * 한 프레임 안에서 "움직였고, 작고, 둥근" 덩어리를 뜻한다.
 */
class BallCandidate(
    val x: Double,              // 서브픽셀 중심 x (영상 픽셀)
    val y: Double,              // 서브픽셀 중심 y (영상 픽셀)
    val diameterMajor: Double,  // 긴 쪽 지름 (픽셀)
    val diameterMinor: Double,  // 짧은 쪽 지름 (픽셀)
    val circularity: Double,    // 원형도 0~1 (1이면 완전한 원)
    val brightness: Double,     // 덩어리 평균 밝기 0~255
    val contrast: Double        // 배경과의 밝기 차이 평균
)

/** 한 프레임의 시간과 그 프레임에서 찾은 공 후보들 */
class FrameCandidates(
    val frameIndex: Int,
    val timeNs: Long,
    val candidates: List<BallCandidate>
)

/** 궤적 위의 점 하나 (자동 추적 결과이거나, 사용자가 직접 탭해서 찍은 점) */
class TrackPoint(
    var frameIndex: Int,
    var timeNs: Long,
    var x: Double,
    var y: Double,
    var isManual: Boolean,
    var isOutlier: Boolean = false
)

/**
 * 렌즈 왜곡 모델.
 * Camera2의 LENS_INTRINSIC_CALIBRATION(fx, fy, cx, cy)과
 * LENS_DISTORTION(k1, k2, k3, p1, p2) 값을 그대로 담는다.
 */
class LensModel(
    val fx: Double,
    val fy: Double,
    val cx: Double,
    val cy: Double,
    val k1: Double,
    val k2: Double,
    val k3: Double,
    val p1: Double,
    val p2: Double,
    val activeWidth: Int,   // 센서 활성 영역 가로 (픽셀)
    val activeHeight: Int   // 센서 활성 영역 세로 (픽셀)
) {
    /**
     * 왜곡된 영상 좌표 → 왜곡을 편 좌표 (둘 다 영상 픽셀 단위).
     * 영상은 센서 활성 영역의 "가운데를 잘라서 축소한 것"이라고 가정한다.
     */
    fun undistort(x: Double, y: Double, imageWidth: Int, imageHeight: Int): DoubleArray {
        // 1) 영상 픽셀 → 센서 픽셀
        val scaleX = activeWidth.toDouble() / imageWidth
        val scaleY = activeHeight.toDouble() / imageHeight
        val scale = if (scaleX < scaleY) scaleX else scaleY
        val sensorX = (x - imageWidth / 2.0) * scale + activeWidth / 2.0
        val sensorY = (y - imageHeight / 2.0) * scale + activeHeight / 2.0

        // 2) 센서 픽셀 → 정규화 좌표 (왜곡된 상태)
        val distortedX = (sensorX - cx) / fx
        val distortedY = (sensorY - cy) / fy

        // 3) 왜곡 식을 반복해서 거꾸로 푼다
        //    왜곡 식: xd = xu * radial + 접선항  →  xu = (xd - 접선항) / radial
        var ux = distortedX
        var uy = distortedY
        for (iteration in 0 until 8) {
            val r2 = ux * ux + uy * uy
            val radial = 1.0 + k1 * r2 + k2 * r2 * r2 + k3 * r2 * r2 * r2
            val tangentialX = p1 * (2.0 * ux * uy) + p2 * (r2 + 2.0 * ux * ux)
            val tangentialY = p2 * (2.0 * ux * uy) + p1 * (r2 + 2.0 * uy * uy)
            ux = (distortedX - tangentialX) / radial
            uy = (distortedY - tangentialY) / radial
        }

        // 4) 정규화 좌표 → 센서 픽셀 → 영상 픽셀
        val correctedSensorX = ux * fx + cx
        val correctedSensorY = uy * fy + cy
        val outX = (correctedSensorX - activeWidth / 2.0) / scale + imageWidth / 2.0
        val outY = (correctedSensorY - activeHeight / 2.0) / scale + imageHeight / 2.0
        return doubleArrayOf(outX, outY)
    }
}

/**
 * 거리 보정 정보.
 * 화면에 찍은 두 점(A, B)과 그 사이 실제 거리(m)로 "픽셀당 미터"를 구한다.
 */
class Calibration(
    val ax: Double,             // 점 A (보정에 쓴 이미지의 픽셀 좌표)
    val ay: Double,
    val bx: Double,             // 점 B
    val by: Double,
    val realMeters: Double,     // A~B 실제 거리 (m)
    val imageWidth: Int,        // 보정에 쓴 이미지 크기
    val imageHeight: Int,
    val lens: LensModel?,       // 렌즈 왜곡 모델 (없으면 null)
    val useLensCorrection: Boolean
) {
    /** 영상 좌표 한 점에 렌즈 왜곡 보정을 적용한다 (보정을 안 쓰면 그대로 돌려줌) */
    fun correctPoint(x: Double, y: Double, frameWidth: Int, frameHeight: Int): DoubleArray {
        if (lens != null && useLensCorrection) {
            return lens.undistort(x, y, frameWidth, frameHeight)
        }
        return doubleArrayOf(x, y)
    }

    /** 점 A를 분석 영상 크기에 맞춘 뒤 왜곡 보정한 좌표 */
    fun correctedA(frameWidth: Int, frameHeight: Int): DoubleArray {
        val sx = frameWidth.toDouble() / imageWidth
        val sy = frameHeight.toDouble() / imageHeight
        return correctPoint(ax * sx, ay * sy, frameWidth, frameHeight)
    }

    /** 점 B를 분석 영상 크기에 맞춘 뒤 왜곡 보정한 좌표 */
    fun correctedB(frameWidth: Int, frameHeight: Int): DoubleArray {
        val sx = frameWidth.toDouble() / imageWidth
        val sy = frameHeight.toDouble() / imageHeight
        return correctPoint(bx * sx, by * sy, frameWidth, frameHeight)
    }

    /** 기준선 길이 (분석 영상 픽셀) */
    fun referenceLengthPx(frameWidth: Int, frameHeight: Int): Double {
        val a = correctedA(frameWidth, frameHeight)
        val b = correctedB(frameWidth, frameHeight)
        val dx = b[0] - a[0]
        val dy = b[1] - a[1]
        return sqrt(dx * dx + dy * dy)
    }

    /** 픽셀당 미터 */
    fun metersPerPixel(frameWidth: Int, frameHeight: Int): Double {
        val lengthPx = referenceLengthPx(frameWidth, frameHeight)
        if (lengthPx < 1e-6) return 0.0
        return realMeters / lengthPx
    }
}

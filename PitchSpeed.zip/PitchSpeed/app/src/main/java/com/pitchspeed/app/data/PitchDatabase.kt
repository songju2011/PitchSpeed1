package com.pitchspeed.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/** 기록 한 줄 */
@Entity(tableName = "pitch_records")
data class PitchRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateMillis: Long,       // 측정 날짜·시간
    val kmh: Double,            // 릴리스 직후 속도 (km/h)
    val mph: Double,            // 릴리스 직후 속도 (mph)
    val averageKmh: Double,     // 평균 속도 (km/h)
    val errorKmh: Double,       // 예상 오차 ±
    val memo: String,
    val videoPath: String,      // 리플레이 영상 파일
    val dataJson: String        // 궤적·보정 등 리플레이에 필요한 나머지 정보
)

@Dao
interface PitchDao {
    @Query("SELECT * FROM pitch_records ORDER BY dateMillis DESC")
    fun observeAll(): Flow<List<PitchRecord>>

    @Query("SELECT videoPath FROM pitch_records")
    suspend fun getAllVideoPaths(): List<String>

    @Query("SELECT * FROM pitch_records WHERE id = :id")
    suspend fun getById(id: Long): PitchRecord?

    @Insert
    suspend fun insert(record: PitchRecord): Long

    @Update
    suspend fun update(record: PitchRecord)

    @Delete
    suspend fun delete(record: PitchRecord)
}

@Database(entities = [PitchRecord::class], version = 1, exportSchema = false)
abstract class PitchDatabase : RoomDatabase() {
    abstract fun pitchDao(): PitchDao

    companion object {
        @Volatile
        private var instance: PitchDatabase? = null

        fun get(context: Context): PitchDatabase {
            val existing = instance
            if (existing != null) return existing
            synchronized(this) {
                val again = instance
                if (again != null) return again
                val created = Room.databaseBuilder(
                    context.applicationContext,
                    PitchDatabase::class.java,
                    "pitch_records.db"
                ).build()
                instance = created
                return created
            }
        }
    }
}

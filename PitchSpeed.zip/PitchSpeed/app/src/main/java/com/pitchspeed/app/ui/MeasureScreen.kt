package com.pitchspeed.app.ui

import android.os.SystemClock
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pitchspeed.app.analysis.TimestampMatcher
import com.pitchspeed.app.camera.CameraStatus
import com.pitchspeed.app.camera.EncoderRingBuffer
import com.pitchspeed.app.camera.HighSpeedCameraController
import com.pitchspeed.app.camera.MotionDetector
import com.pitchspeed.app.data.AppSession
import com.pitchspeed.app.data.CalibrationStore
import com.pitchspeed.app.data.ClipInfo
import java.io.File
import kotlin.math.pow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * 3. 측정 대기.
 *
 * 카메라는 고속으로 계속 인코딩해서 링 버퍼(최근 8초)에 담고 있다.
 * 미리보기에서 움직임이 감지되면 "녹화 중"이 되고, 움직임이 멈추면
 * 감지 1초 전부터 지금까지를 잘라 저장한 뒤 분석 화면으로 넘어간다.
 */
@Composable
fun MeasureScreen(navController: NavController) {
    val context = LocalContext.current

    val config = remember { findCaptureConfigOrNull(context) }
    val calibration = remember { CalibrationStore.load(context) }
    if (config == null) {
        MessageScreen(text = "카메라를 사용할 수 없습니다.", onBack = { navController.popBackStack() })
        return
    }
    if (calibration == null) {
        MessageScreen(text = "먼저 거리 보정을 해 주세요.", onBack = { navController.popBackStack() })
        return
    }

    val controller = remember { HighSpeedCameraController(context) }
    val encoder = remember { EncoderRingBuffer(config.width, config.height, config.fps) }

    var status by remember { mutableStateOf<CameraStatus?>(null) }
    var errorText by remember { mutableStateOf("") }
    var stateText by remember { mutableStateOf("카메라 준비 중") }
    var isRecording by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var surfaceView by remember { mutableStateOf<SurfaceView?>(null) }
    var sensitivity by remember { mutableFloatStateOf(0.5f) }
    var motionLevel by remember { mutableFloatStateOf(0f) }
    var manualSaveRequested by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        controller.onStatus = { newStatus -> status = newStatus }
        controller.onError = { text -> errorText = text }
        onDispose {
            controller.close()
            encoder.stop()
        }
    }

    /**
     * 링 버퍼의 [startPtsUs, endPtsUs] 구간을 파일로 저장하고 분석 준비를 한다.
     * 성공하면 true.
     */
    suspend fun saveClip(startPtsUs: Long, endPtsUs: Long): Boolean {
        isSaving = true
        stateText = "저장 중"
        val clip = withContext(Dispatchers.IO) {
            val directory = File(context.filesDir, "clips")
            directory.mkdirs()
            val file = File(directory, "clip_" + System.currentTimeMillis() + ".mp4")

            val encoderPts = encoder.saveClip(startPtsUs, endPtsUs, file, controller.recordingRotation)
            if (encoderPts == null) {
                null
            } else {
                // 저장된 프레임마다 SENSOR_TIMESTAMP(나노초)를 짝지어 붙인다
                val sensorTimestamps = controller.copyRecentSensorTimestamps()
                val match = TimestampMatcher.match(encoderPts, sensorTimestamps)
                ClipInfo(
                    videoPath = file.absolutePath,
                    isImported = false,
                    clipPtsUs = match.clipPtsUs,
                    clipTimesNs = match.timesNs,
                    timestampsExact = match.exact,
                    timeScale = 1.0,
                    rollingShutterSkewNs = controller.rollingShutterSkewNs,
                    exposureNs = controller.lastExposureNs,
                    iso = controller.lastIso,
                    nominalFps = config.fps
                )
            }
        }
        isSaving = false
        if (clip == null) {
            errorText = "영상 저장에 실패했습니다. 다시 시도합니다."
            return false
        }
        AppSession.pendingClip = clip
        AppSession.pendingCalibration = calibration
        navController.navigate("analyze")
        return true
    }

    // ---------------- 자동 녹화 루프 ----------------
    LaunchedEffect(surfaceView) {
        val view = surfaceView ?: return@LaunchedEffect
        val detector = MotionDetector(view)
        try {
            var lockedSinceMs = 0L      // 노출이 고정된 시각
            var motionStreak = 0        // 연속으로 움직임이 잡힌 횟수
            var recording = false
            var triggerPtsUs = 0L       // 움직임이 처음 잡혔을 때의 인코더 시간
            var recordStartMs = 0L
            var lastMotionMs = 0L

            while (isActive) {
                delay(50)
                val now = SystemClock.elapsedRealtime()

                // 노출이 고정되기 전에는 화면 밝기가 변하므로 감지하지 않는다
                if (!controller.exposureLocked) {
                    lockedSinceMs = 0L
                    recording = false
                    isRecording = false
                    motionStreak = 0
                    detector.reset()
                    stateText = "노출 맞추는 중"
                    continue
                }
                if (lockedSinceMs == 0L) lockedSinceMs = now

                val fraction = detector.measure()
                if (fraction >= 0f) motionLevel = fraction

                // 민감도 0~1 → 움직인 픽셀 비율 임계값 3% ~ 0.1%
                val threshold = 0.03f * (0.001f / 0.03f).pow(sensitivity)
                val moving = fraction >= threshold

                // "방금 3초 저장" 버튼
                if (manualSaveRequested) {
                    manualSaveRequested = false
                    val endPts = encoder.latestPtsUs()
                    if (endPts > 0L) {
                        if (saveClip(endPts - 3_000_000L, endPts)) return@LaunchedEffect
                    }
                    continue
                }

                if (!recording) {
                    if (now - lockedSinceMs < 1500L) {
                        stateText = "준비 중"
                        continue
                    }
                    stateText = "대기 중 — 움직이면 자동으로 녹화합니다"
                    if (moving) motionStreak++ else motionStreak = 0
                    if (motionStreak >= 2) {
                        val latest = encoder.latestPtsUs()
                        if (latest > 0L) {
                            recording = true
                            isRecording = true
                            triggerPtsUs = latest
                            recordStartMs = now
                            lastMotionMs = now
                            motionStreak = 0
                        }
                    }
                } else {
                    stateText = "녹화 중"
                    if (moving) lastMotionMs = now
                    val quiet = now - lastMotionMs > 700L          // 0.7초 동안 움직임 없음
                    val tooLong = now - recordStartMs > 4000L      // 최대 4초
                    if (quiet || tooLong) {
                        // 인코더가 마지막 프레임까지 내놓을 시간을 준다
                        delay(200)
                        val endPts = encoder.latestPtsUs()
                        // 버퍼 링 덕분에 감지 이전 1초(+감지 지연 0.3초)를 포함해서 저장한다
                        val saved = saveClip(triggerPtsUs - 1_300_000L, endPts)
                        if (saved) return@LaunchedEffect
                        recording = false
                        isRecording = false
                    }
                }
            }
        } finally {
            detector.release()
        }
    }

    // ---------------- 화면 ----------------
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        CameraPreview(
            config = config,
            modifier = Modifier.align(Alignment.Center),
            onSurfaceReady = { view, surface ->
                try {
                    encoder.start()
                    controller.open(config, surface, encoder.inputSurface)
                    surfaceView = view
                } catch (e: Exception) {
                    errorText = "인코더를 시작할 수 없습니다: " + e.message
                }
            },
            onSurfaceDestroyed = {
                surfaceView = null
                controller.close()
                encoder.stop()
            }
        )

        // 왼쪽 위: fps와 셔터 속도 실시간 표시
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            val current = status
            val fpsText = if (current != null) formatOne(current.measuredFps) else "-"
            val shutterText = if (current != null) formatShutter(current.exposureNs) else "-"
            val isoText = if (current != null) current.iso.toString() else "-"
            Text(
                text = "$fpsText fps  ·  셔터 $shutterText",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "설정 ${config.fps} fps · ${config.width}x${config.height} · ISO $isoText" +
                        (if (config.isHighSpeed) " · 고속 세션" else " · 일반 세션"),
                fontSize = 13.sp,
                color = ColorDim
            )
            if (current != null) {
                Text(
                    text = "노출: " + current.exposureModeText,
                    fontSize = 13.sp,
                    color = if (current.exposureLocked) ColorGood else ColorWarning
                )
                if (current.warning.isNotEmpty()) {
                    Text(text = current.warning, fontSize = 13.sp, color = ColorWarning)
                }
            }
            if (!config.isHighSpeed) {
                Text(
                    text = "이 기기는 고속 촬영을 지원하지 않아 정확도가 떨어집니다.",
                    fontSize = 13.sp,
                    color = ColorWarning
                )
            }
            if (errorText.isNotEmpty()) {
                Text(text = errorText, fontSize = 13.sp, color = ColorWarning)
            }
        }

        // 오른쪽 위: 상태
        Text(
            text = (if (isRecording) "● " else "") + stateText,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = if (isRecording) Color(0xFFFF5252) else Color.White,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
                .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )

        // 아래: 민감도와 버튼
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(10.dp)
                .background(Color(0xAA000000), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SmallButton(text = "뒤로", onClick = { navController.popBackStack() })
            Column {
                Text(
                    text = "감지 민감도 (지금 움직임 ${formatTwo(motionLevel * 100.0)} %)",
                    fontSize = 12.sp,
                    color = ColorDim
                )
                Slider(
                    value = sensitivity,
                    onValueChange = { value -> sensitivity = value },
                    modifier = Modifier.width(180.dp)
                )
            }
            SmallButton(text = "노출 다시", onClick = { controller.restartExposureMetering() })
            BigButton(
                text = "방금 3초 저장",
                enabled = !isSaving && surfaceView != null,
                onClick = { manualSaveRequested = true }
            )
        }
    }
}

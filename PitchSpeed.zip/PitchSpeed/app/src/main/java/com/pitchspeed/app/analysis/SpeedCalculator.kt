package com.pitchspeed.app.analysis

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.exp
import kotlin.math.sqrt

/** 속도 계산 입력 */
class SpeedInput(
    val timeNs: LongArray,          // 각 점의 시간 (나노초, 시간 순서대로)
    val x: DoubleArray,             // 각 점의 x (렌즈 왜곡 보정된 픽셀)
    val y: DoubleArray,             // 각 점의 y
    val metersPerPixel: Double,
    val refAx: Double,              // 기준선 점 A (왜곡 보정된 픽셀)
    val refAy: Double,
    val refBx: Double,              // 기준선 점 B
    val refBy: Double,
    val timestampsExact: Boolean    // 센서 타임스탬프를 썼으면 true, 영상 파일 시간이면 false
)

/** 속도 계산 결과 */
class SpeedResult(
    val ok: Boolean,
    val message: String,
    val releaseKmh: Double,             // 릴리스 직후 속도 (추적 시작 시점의 순간 속도)
    val averageKmh: Double,             // 추적 구간 평균 속도
    val gateKmh: Double,                // 기준선 통과 시각(프레임 사이 보간)으로 잰 구간 속도. 없으면 NaN
    val gateUsesReferenceLine: Boolean, // true면 보정 때 찍은 두 점을 게이트로 쓴 것
    val errorKmh: Double,               // 예상 오차 ± (약 95% 수준)
    val errorCalibrationKmh: Double,    // 그중 거리 보정에서 오는 몫
    val errorTimingKmh: Double,         // 그중 시간(fps)에서 오는 몫
    val errorFitKmh: Double,            // 그중 궤적 피팅 잔차에서 오는 몫
    val residualRmsPx: Double,          // 피팅 잔차 (픽셀)
    val usedPointCount: Int,
    val measuredFps: Double,            // 타임스탬프로 잰 실제 fps
    val releaseModel: String,           // 릴리스 속도를 구한 방법 설명
    val outliers: BooleanArray          // 입력 점마다 이상치 여부
)

object SpeedCalculator {

    const val KMH_PER_MPH = 1.609344

    // 공기 저항으로 속도가 줄어드는 비율 (1/m). 야구공은 18.44m 가는 동안 약 9~10% 느려진다.
    private const val DRAG_PER_METER = 0.0055

    // 보정 점을 찍을 때 손가락 오차 (픽셀, 점 하나당)
    private const val TAP_ERROR_PX = 1.5

    fun kmhToMph(kmh: Double): Double {
        return kmh / KMH_PER_MPH
    }

    private fun fail(message: String, n: Int): SpeedResult {
        return SpeedResult(
            false, message,
            Double.NaN, Double.NaN, Double.NaN, false,
            Double.NaN, Double.NaN, Double.NaN, Double.NaN,
            Double.NaN, 0, Double.NaN, "", BooleanArray(n)
        )
    }

    fun calculate(input: SpeedInput): SpeedResult {
        val n = input.timeNs.size
        val mpp = input.metersPerPixel
        if (mpp <= 0.0) return fail("거리 보정이 올바르지 않습니다", n)
        if (n < 3) return fail("공 위치가 3개 이상 필요합니다 (현재 ${n}개)", n)

        // 초, 미터 단위로 바꾼다
        val t = DoubleArray(n)
        val xm = DoubleArray(n)
        val ym = DoubleArray(n)
        for (i in 0 until n) {
            t[i] = (input.timeNs[i] - input.timeNs[0]) / 1e9
            xm[i] = input.x[i] * mpp
            ym[i] = input.y[i] * mpp
        }

        // ---------- 1. 이상치 제거 ----------
        // 피팅 → 잔차 → 중앙값 기준으로 크게 벗어난 점 제거 → 다시 피팅 (최대 3번)
        val inlier = BooleanArray(n) { true }
        for (round in 0 until 3) {
            val idx = inlierIndices(inlier)
            if (idx.size < 4) break
            val degree = if (idx.size >= 8) 2 else 1
            val tt = DoubleArray(idx.size) { t[idx[it]] }
            val fitX = PolyFit.fit(tt, DoubleArray(idx.size) { xm[idx[it]] }, degree) ?: break
            val fitY = PolyFit.fit(tt, DoubleArray(idx.size) { ym[idx[it]] }, degree) ?: break

            val residuals = DoubleArray(idx.size)
            for (k in idx.indices) {
                val rx = xm[idx[k]] - fitX.valueAt(tt[k])
                val ry = ym[idx[k]] - fitY.valueAt(tt[k])
                residuals[k] = sqrt(rx * rx + ry * ry)
            }
            val sorted = residuals.copyOf()
            sorted.sort()
            val median = sorted[sorted.size / 2]
            var limit = 3.0 * 1.4826 * median
            val minimumLimit = 0.75 * mpp   // 0.75픽셀 이내는 이상치로 보지 않는다
            if (limit < minimumLimit) limit = minimumLimit

            var removeCount = 0
            for (k in idx.indices) {
                if (residuals[k] > limit) removeCount++
            }
            if (removeCount == 0) break
            // 너무 많이 버리게 되면 그만둔다
            val minimumKeep = if ((n + 1) / 2 > 3) (n + 1) / 2 else 3
            if (idx.size - removeCount < minimumKeep) break
            for (k in idx.indices) {
                if (residuals[k] > limit) inlier[idx[k]] = false
            }
        }

        val idx = inlierIndices(inlier)
        val count = idx.size
        if (count < 3) return fail("쓸 수 있는 공 위치가 부족합니다", n)

        // 첫 번째 점의 시간을 0으로 맞춘다 → t=0 에서의 기울기가 곧 "추적 시작 시점 속도"
        val tt = DoubleArray(count) { t[idx[it]] - t[idx[0]] }
        val xx = DoubleArray(count) { xm[idx[it]] }
        val yy = DoubleArray(count) { ym[idx[it]] }
        val span = tt[count - 1]
        if (span <= 0.0) return fail("시간 정보가 올바르지 않습니다", n)

        // ---------- 2. 평균 속도: 궤적 전체를 직선으로 피팅 ----------
        val lineX = PolyFit.fit(tt, xx, 1) ?: return fail("직선 피팅 실패", n)
        val lineY = PolyFit.fit(tt, yy, 1) ?: return fail("직선 피팅 실패", n)
        val averageSpeed = sqrt(lineX.coef[1] * lineX.coef[1] + lineY.coef[1] * lineY.coef[1])

        // 잔차 분산의 바닥값: 0.1픽셀 (이보다 정밀하다고 믿지 않는다)
        val floorVariance = (0.1 * mpp) * (0.1 * mpp)

        var lineVariance = floorVariance
        if (count > 2) {
            val v = (lineX.sse + lineY.sse) / (2.0 * (count - 2))
            if (v > lineVariance) lineVariance = v
        }

        // ---------- 3. 릴리스 직후 속도 ----------
        // 점이 충분하면 포물선(시간에 대한 2차식)으로 피팅해서 시작 시점의 순간 속도를 구한다.
        // 공은 날아가면서 느려지므로, 시작 시점 속도가 스피드건 수치에 가깝다.
        var releaseSpeed = Double.NaN
        var releaseVariance = Double.NaN
        var releaseModel = ""
        var residualSse = lineX.sse + lineY.sse

        if (count >= 8) {
            val parabolaX = PolyFit.fit(tt, xx, 2)
            val parabolaY = PolyFit.fit(tt, yy, 2)
            if (parabolaX != null && parabolaY != null) {
                val vx0 = parabolaX.coef[1]
                val vy0 = parabolaY.coef[1]
                val v0 = sqrt(vx0 * vx0 + vy0 * vy0)

                var variance = (parabolaX.sse + parabolaY.sse) / (2.0 * (count - 3))
                if (variance < floorVariance) variance = floorVariance
                val v0Variance = parabolaX.derivativeVarianceAt(0.0, variance) +
                        parabolaY.derivativeVarianceAt(0.0, variance)

                // 진행 방향 가속도 (m/s²). 공기 저항이면 약 -5 ~ -12 정도가 정상.
                var alongAcceleration = 0.0
                if (v0 > 0.0) {
                    alongAcceleration = (2.0 * parabolaX.coef[2] * vx0 + 2.0 * parabolaY.coef[2] * vy0) / v0
                }

                // 물리적으로 말이 되고, 충분히 정밀할 때만 포물선 결과를 쓴다
                val physical = alongAcceleration > -40.0 && alongAcceleration < 5.0
                val precise = sqrt(v0Variance) * 3.6 <= 3.0
                val consistent = v0 > averageSpeed * 0.9 && v0 < averageSpeed * 1.25
                if (physical && precise && consistent) {
                    releaseSpeed = v0
                    releaseVariance = v0Variance
                    releaseModel = "포물선 피팅"
                    residualSse = parabolaX.sse + parabolaY.sse
                }
            }
        }

        if (releaseSpeed.isNaN()) {
            // 포물선을 못 쓰면: 평균 속도에 공기 저항 모델을 적용해서 시작 시점 속도로 환산한다
            val pathLength = averageSpeed * span
            releaseSpeed = averageSpeed * exp(DRAG_PER_METER * pathLength / 2.0)
            val lineSpeedVariance = lineX.derivativeVarianceAt(0.0, lineVariance) +
                    lineY.derivativeVarianceAt(0.0, lineVariance)
            // 환산값 자체의 불확실성(보정량의 30%)도 더한다
            val modelUncertainty = 0.3 * (releaseSpeed - averageSpeed)
            releaseVariance = lineSpeedVariance + modelUncertainty * modelUncertainty
            releaseModel = "직선 피팅 + 공기저항 환산"
        }

        val residualRmsPx = sqrt(residualSse / count) / mpp

        // ---------- 4. 실제 fps (타임스탬프 간격의 중앙값) ----------
        val gaps = DoubleArray(n - 1) { t[it + 1] - t[it] }
        gaps.sort()
        val medianGap = gaps[gaps.size / 2]
        val measuredFps = if (medianGap > 0.0) 1.0 / medianGap else Double.NaN

        // ---------- 5. 기준선 통과 시각 보간 (게이트 속도) ----------
        // 진행 방향 축 위에 선 두 개를 긋고, 공이 각 선을 지나는 시각을
        // 앞뒤 프레임 위치로 보간해서 프레임 간격보다 잘게 구한다.
        val firstX = input.x[idx[0]]
        val firstY = input.y[idx[0]]
        val lastX = input.x[idx[count - 1]]
        val lastY = input.y[idx[count - 1]]
        val travelDx = lastX - firstX
        val travelDy = lastY - firstY
        val travelLength = sqrt(travelDx * travelDx + travelDy * travelDy)

        var gateKmh = Double.NaN
        var gateUsesReference = false

        val refDx = input.refBx - input.refAx
        val refDy = input.refBy - input.refAy
        val refLengthPx = sqrt(refDx * refDx + refDy * refDy)

        if (travelLength > 1e-6) {
            val ux = travelDx / travelLength
            val uy = travelDy / travelLength

            // 각 점을 진행 방향 축에 투영한 위치 (픽셀)
            val s = DoubleArray(count) { (input.x[idx[it]] - firstX) * ux + (input.y[idx[it]] - firstY) * uy }
            val times = DoubleArray(count) { tt[it] }

            // 기준선 두 점의 축 위 위치
            val sA = (input.refAx - firstX) * ux + (input.refAy - firstY) * uy
            val sB = (input.refBx - firstX) * ux + (input.refBy - firstY) * uy

            // 기준선이 진행 방향과 거의 나란하고(20도 이내), 공이 두 점을 모두 지나갔으면 그 두 점을 게이트로 쓴다
            var referenceAligned = false
            if (refLengthPx > 1e-6) {
                var cosAngle = abs((refDx * ux + refDy * uy) / refLengthPx)
                if (cosAngle > 1.0) cosAngle = 1.0
                referenceAligned = acos(cosAngle) < Math.toRadians(20.0)
            }

            var gate1 = travelLength * 0.1
            var gate2 = travelLength * 0.9
            if (referenceAligned) {
                val tA = crossingTime(s, times, sA)
                val tB = crossingTime(s, times, sB)
                if (!tA.isNaN() && !tB.isNaN() && tA != tB) {
                    gate1 = sA
                    gate2 = sB
                    gateUsesReference = true
                }
            }

            val time1 = crossingTime(s, times, gate1)
            val time2 = crossingTime(s, times, gate2)
            if (!time1.isNaN() && !time2.isNaN() && time1 != time2) {
                val gateDistance = abs(gate2 - gate1) * mpp
                gateKmh = gateDistance / abs(time2 - time1) * 3.6
            }
        }

        // ---------- 6. 예상 오차 ----------
        // (a) 거리 보정: 기준선 양 끝을 찍을 때의 오차 / 기준선 길이
        var relativeCalibration = 1.0
        if (refLengthPx > 1e-6) {
            relativeCalibration = sqrt(2.0) * TAP_ERROR_PX / refLengthPx
        }
        // (b) 시간: 타임스탬프 한 개의 불확실성 / 추적 구간 길이
        //     센서 타임스탬프면 프레임 간격의 1%, 영상 파일 시간이면 10%로 본다
        val timestampSigma = if (input.timestampsExact) medianGap * 0.01 else medianGap * 0.10
        val relativeTiming = sqrt(2.0) * timestampSigma / span
        // (c) 피팅: 잔차에서 나온 속도의 표준오차
        val fitSigma = sqrt(releaseVariance)

        val errorCalibration = releaseSpeed * relativeCalibration
        val errorTiming = releaseSpeed * relativeTiming
        val totalSigma = sqrt(
            errorCalibration * errorCalibration + errorTiming * errorTiming + fitSigma * fitSigma
        )

        // 화면에는 2시그마(약 95%)를 km/h로 보여준다
        val outliers = BooleanArray(n) { !inlier[it] }
        return SpeedResult(
            ok = true,
            message = "",
            releaseKmh = releaseSpeed * 3.6,
            averageKmh = averageSpeed * 3.6,
            gateKmh = gateKmh,
            gateUsesReferenceLine = gateUsesReference,
            errorKmh = 2.0 * totalSigma * 3.6,
            errorCalibrationKmh = 2.0 * errorCalibration * 3.6,
            errorTimingKmh = 2.0 * errorTiming * 3.6,
            errorFitKmh = 2.0 * fitSigma * 3.6,
            residualRmsPx = residualRmsPx,
            usedPointCount = count,
            measuredFps = measuredFps,
            releaseModel = releaseModel,
            outliers = outliers
        )
    }

    private fun inlierIndices(inlier: BooleanArray): IntArray {
        var count = 0
        for (flag in inlier) {
            if (flag) count++
        }
        val result = IntArray(count)
        var k = 0
        for (i in inlier.indices) {
            if (inlier[i]) {
                result[k] = i
                k++
            }
        }
        return result
    }

    /**
     * 공이 축 위의 gate 위치를 지나간 시각을 구한다.
     * gate를 사이에 둔 앞뒤 두 점을 찾아서 위치 비율만큼 시간을 보간한다.
     * 지나간 적이 없으면 NaN.
     */
    private fun crossingTime(s: DoubleArray, times: DoubleArray, gate: Double): Double {
        for (i in 0 until s.size - 1) {
            val before = s[i] - gate
            val after = s[i + 1] - gate
            if (before == after) continue
            if (before * after <= 0.0) {
                val ratio = (gate - s[i]) / (s[i + 1] - s[i])
                return times[i] + ratio * (times[i + 1] - times[i])
            }
        }
        return Double.NaN
    }
}

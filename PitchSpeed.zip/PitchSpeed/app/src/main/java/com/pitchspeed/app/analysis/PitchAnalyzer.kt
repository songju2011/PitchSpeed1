package com.pitchspeed.app.analysis

import android.content.Context
import android.graphics.Bitmap
import com.pitchspeed.app.data.ClipInfo
import com.pitchspeed.app.data.ResultData

/**
 * 분석 전체 순서를 담당한다.
 *
 *   영상 디코딩 → 프레임마다 공 후보 검출 → 칼만 필터로 궤적 추적
 *   → 궤적 피팅으로 속도 계산 → 리플레이용 프레임 이미지 만들기
 *
 * 전부 백그라운드 스레드에서 불러야 한다.
 */
object PitchAnalyzer {

    /** 야구공 지름 (m) */
    const val BALL_DIAMETER_M = 0.0732

    // 한 번에 분석할 최대 프레임 수
    private const val MAX_FRAMES = 3000

    // 리플레이로 풀어 둘 최대 프레임 수
    private const val MAX_REPLAY_FRAMES = 1500

    /**
     * 클립을 분석한다. 영상을 읽을 수 없으면 null.
     * 공을 못 찾아도 결과는 돌려준다 (점이 0개인 상태 → 결과 화면에서 직접 찍을 수 있다).
     */
    fun analyze(
        context: Context,
        clip: ClipInfo,
        calibration: Calibration,
        onProgress: (Float, String) -> Unit
    ): ResultData? {
        val reader = VideoFrameReader(clip.videoPath)
        if (!reader.open(wantColor = false, seekToUs = 0L)) return null

        val width = reader.width
        val height = reader.height
        val rotation = reader.rotation
        val durationUs = reader.durationUs

        val metersPerPixel = calibration.metersPerPixel(width, height)
        if (metersPerPixel <= 0.0) {
            reader.close()
            return null
        }
        val ballDiameterPx = BALL_DIAMETER_M / metersPerPixel

        // ---------- 1. 프레임마다 공 후보 검출 ----------
        val detector = BallDetector(width, height)
        var previous = ByteArray(width * height)
        var current = ByteArray(width * height)
        var next = ByteArray(width * height)

        val frameTimesNs = ArrayList<Long>()    // 프레임별 실제 시간
        val framePtsUs = ArrayList<Long>()      // 프레임별 영상 속 시간
        val frames = ArrayList<FrameCandidates>()

        var index = 0
        while (index < MAX_FRAMES && reader.advance()) {
            val ptsUs = reader.currentPtsUs

            // 프레임 시간: fps로 추정하지 않고 프레임마다 기록된 실제 시간을 쓴다
            var timeNs = (ptsUs * 1000.0 * clip.timeScale).toLong()
            val clipPts = clip.clipPtsUs
            val clipTimes = clip.clipTimesNs
            if (clipPts != null && clipTimes != null && clipPts.isNotEmpty()) {
                // 직접 찍은 클립: 저장할 때 붙여 둔 센서 타임스탬프를 쓴다.
                // (MP4에 저장되면서 시간이 몇 µs 반올림될 수 있어서, 가장 가까운 프레임으로 찾는다)
                val nearest = TimestampMatcher.nearestIndex(clipPts, ptsUs)
                timeNs = clipTimes[nearest]
            }
            frameTimesNs.add(timeNs)
            framePtsUs.add(ptsUs)

            // 버퍼 세 개를 돌려 쓴다: (이전, 현재, 다음)
            val recycled = previous
            previous = current
            current = next
            next = recycled
            System.arraycopy(reader.yPlane, 0, next, 0, width * height)

            // 프레임이 세 장 모이면 가운데 프레임(index - 1)에서 후보를 찾는다
            if (index >= 2) {
                val candidates = detector.detect(previous, current, next, ballDiameterPx, 40)
                frames.add(FrameCandidates(index - 1, frameTimesNs[index - 1], candidates))
            }

            index++
            if (index % 10 == 0) {
                var fraction = 0f
                if (durationUs > 0L) fraction = ptsUs.toFloat() / durationUs
                if (fraction > 1f) fraction = 1f
                onProgress(fraction * 0.6f, "공 찾는 중 (${index}프레임)")
            }
        }
        reader.close()
        val totalFrames = index
        if (totalFrames < 3) return null

        // ---------- 2. 칼만 필터로 궤적 추적 ----------
        onProgress(0.62f, "궤적 추적 중")
        val minSpeedPx = (30.0 / 3.6) / metersPerPixel     // 시속 30km 미만은 공으로 안 본다
        val maxSpeedPx = (200.0 / 3.6) / metersPerPixel    // 시속 200km 초과도 제외
        val accelNoisePx = 40.0 / metersPerPixel           // 가속도 잡음 40 m/s²

        // 먼저 "밝은 덩어리"만으로 추적하고, 실패하면 밝기 조건을 빼고 다시 해 본다
        var track = BallTracker.findBestTrack(
            frames,
            TrackerSettings(minSpeedPx, maxSpeedPx, ballDiameterPx, accelNoisePx, 100.0)
        )
        if (track.size < 5) {
            track = BallTracker.findBestTrack(
                frames,
                TrackerSettings(minSpeedPx, maxSpeedPx, ballDiameterPx, accelNoisePx, 0.0)
            )
        }

        // ---------- 3. 리플레이 구간 정하기 ----------
        var windowStart = 0
        var windowEnd = totalFrames - 1
        if (track.isNotEmpty()) {
            // 공이 보인 구간 앞뒤로 15프레임씩 여유를 둔다
            windowStart = track[0].frameIndex - 15
            windowEnd = track[track.size - 1].frameIndex + 15
            if (windowStart < 0) windowStart = 0
            if (windowEnd > totalFrames - 1) windowEnd = totalFrames - 1
        }
        if (windowEnd - windowStart + 1 > MAX_REPLAY_FRAMES) {
            windowEnd = windowStart + MAX_REPLAY_FRAMES - 1
        }
        val windowCount = windowEnd - windowStart + 1
        // 프레임이 많거나 영상이 크면 절반 크기로 저장한다
        val halfRes = windowCount > 300 || width > 1920 || height > 1920

        val windowTimes = LongArray(windowCount)
        for (i in 0 until windowCount) {
            windowTimes[i] = frameTimesNs[windowStart + i]
        }

        val data = ResultData(
            videoPath = clip.videoPath,
            isImported = clip.isImported,
            frameWidth = width,
            frameHeight = height,
            rotation = rotation,
            calibration = calibration,
            timestampsExact = clip.timestampsExact,
            rollingShutterSkewNs = clip.rollingShutterSkewNs,
            exposureNs = clip.exposureNs,
            iso = clip.iso,
            nominalFps = clip.nominalFps,
            windowStartFrame = windowStart,
            windowStartPtsUs = framePtsUs[windowStart],
            windowTimesNs = windowTimes,
            replayHalfRes = halfRes,
            points = ArrayList(track),
            speed = null
        )

        // ---------- 4. 속도 계산 ----------
        computeSpeed(data)

        // ---------- 5. 리플레이 프레임 이미지 만들기 ----------
        onProgress(0.65f, "리플레이 만드는 중")
        ReplayFrameCache.build(
            context, clip.videoPath, windowStart, framePtsUs[windowStart], windowCount, halfRes
        ) { fraction ->
            onProgress(0.65f + 0.35f * fraction, "리플레이 만드는 중")
        }

        return data
    }

    /**
     * 궤적 점들로 속도를 (다시) 계산해서 data.speed에 넣는다.
     * 사용자가 점을 고친 뒤에도 이 함수를 부른다.
     */
    fun computeSpeed(data: ResultData): SpeedResult {
        data.points.sortBy { it.frameIndex }
        val n = data.points.size
        val width = data.frameWidth
        val height = data.frameHeight

        val timeNs = LongArray(n)
        val x = DoubleArray(n)
        val y = DoubleArray(n)
        val diameters = DoubleArray(n)
        for (i in 0 until n) {
            val p = data.points[i]
            diameters[i] = p.diameterPx

            // 렌즈 왜곡 보정
            val corrected = data.calibration.correctPoint(p.x, p.y, width, height)
            x[i] = corrected[0]
            y[i] = corrected[1]

            // 롤링 셔터 보정: 센서는 위에서 아래로 한 줄씩 읽으므로,
            // 화면 아래쪽에 찍힌 공은 프레임 타임스탬프보다 조금 늦게 찍힌 것이다.
            var rowOffsetNs = 0L
            if (data.rollingShutterSkewNs > 0L && height > 0) {
                if (data.rotation == 0) {
                    rowOffsetNs = (data.rollingShutterSkewNs * (p.y / height)).toLong()
                } else if (data.rotation == 180) {
                    rowOffsetNs = (data.rollingShutterSkewNs * (1.0 - p.y / height)).toLong()
                }
            }
            timeNs[i] = p.timeNs + rowOffsetNs
        }

        val a = data.calibration.correctedA(width, height)
        val b = data.calibration.correctedB(width, height)

        val result = SpeedCalculator.calculate(
            SpeedInput(
                timeNs = timeNs,
                x = x,
                y = y,
                metersPerPixel = data.calibration.metersPerPixel(width, height),
                refAx = a[0],
                refAy = a[1],
                refBx = b[0],
                refBy = b[1],
                timestampsExact = data.timestampsExact,
                diameterPx = diameters,
                focalPx = data.calibration.focalPxAt(width, height),
                focalRelativeError = data.calibration.focalRelativeError(),
                centerX = width / 2.0,
                centerY = height / 2.0
            )
        )

        for (i in 0 until n) {
            data.points[i].isOutlier = result.outliers[i]
        }
        data.speed = result
        return result
    }

    /**
     * 사용자가 탭한 위치 근처에서 공의 중심을 밝기 가중 평균으로 다시 잡는다.
     * (손가락으로 정확히 공 한가운데를 찍기는 어렵기 때문)
     *
     * bitmap: 리플레이 프레임, (tapX, tapY): 비트맵 픽셀 좌표, radius: 살펴볼 반경(픽셀)
     */
    fun refineTap(bitmap: Bitmap, tapX: Double, tapY: Double, radius: Int): DoubleArray {
        var centerX = tapX
        var centerY = tapY

        // 두 번 반복해서 중심을 수렴시킨다
        for (iteration in 0 until 2) {
            val x0 = maxOf(0, (centerX - radius).toInt())
            val y0 = maxOf(0, (centerY - radius).toInt())
            val x1 = minOf(bitmap.width - 1, (centerX + radius).toInt())
            val y1 = minOf(bitmap.height - 1, (centerY + radius).toInt())
            if (x1 <= x0 || y1 <= y0) break

            val w = x1 - x0 + 1
            val h = y1 - y0 + 1
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, x0, y0, w, h)

            // 영역 안의 가장 어두운 값과 가장 밝은 값
            var darkest = 255
            var brightest = 0
            for (pixel in pixels) {
                val gray = (pixel shr 8) and 0xFF
                if (gray < darkest) darkest = gray
                if (gray > brightest) brightest = gray
            }
            // 공과 배경의 차이가 너무 작으면 탭한 위치를 그대로 쓴다
            if (brightest - darkest < 20) break
            val threshold = (darkest + brightest) / 2

            var sumW = 0.0
            var sumWX = 0.0
            var sumWY = 0.0
            for (py in 0 until h) {
                for (px in 0 until w) {
                    val gray = (pixels[py * w + px] shr 8) and 0xFF
                    val weight = gray - threshold
                    if (weight > 0) {
                        sumW += weight
                        sumWX += weight * (x0 + px)
                        sumWY += weight * (y0 + py)
                    }
                }
            }
            if (sumW <= 0.0) break
            centerX = sumWX / sumW
            centerY = sumWY / sumW
        }
        return doubleArrayOf(centerX, centerY)
    }
}

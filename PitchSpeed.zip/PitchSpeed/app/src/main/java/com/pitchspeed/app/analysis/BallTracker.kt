package com.pitchspeed.app.analysis

import kotlin.math.abs
import kotlin.math.sqrt

/** 추적 설정값 */
class TrackerSettings(
    val minSpeedPxPerSec: Double,       // 공으로 볼 최소 속도 (픽셀/초)
    val maxSpeedPxPerSec: Double,       // 공으로 볼 최대 속도 (픽셀/초)
    val ballDiameterPx: Double,         // 예상 공 지름 (픽셀)
    val accelNoisePxPerSec2: Double,    // 칼만 필터 가속도 잡음 (픽셀/초²)
    val minBrightness: Double,          // 후보 최소 밝기 (0이면 밝기 필터 끔)
    val maxMissedFrames: Int = 4,       // 연속으로 놓쳐도 되는 프레임 수
    val minHits: Int = 5                // 궤적으로 인정할 최소 점 개수
)

/**
 * 프레임별 공 후보들을 이어서 "가장 그럴듯한 궤적 하나"를 찾는다.
 *
 * 방법:
 * 1. 가까운 두 프레임의 후보 두 개를 골라 궤적의 시작으로 삼는다 (속도가 공 범위일 때만).
 * 2. 칼만 필터로 다음 프레임 위치를 예측하고, 예측 근처의 후보를 붙인다.
 * 3. 몇 프레임 놓치면 예측만으로 건너뛰고, 계속 놓치면 끝낸다.
 * 4. 점이 가장 많이 이어진 궤적을 고른다.
 */
object BallTracker {

    fun findBestTrack(frames: List<FrameCandidates>, settings: TrackerSettings): List<TrackPoint> {
        val frameCount = frames.size

        // 밝기 필터를 먼저 적용한다
        val filtered = ArrayList<List<BallCandidate>>()
        for (frame in frames) {
            val kept = ArrayList<BallCandidate>()
            for (candidate in frame.candidates) {
                if (candidate.brightness >= settings.minBrightness) {
                    kept.add(candidate)
                }
            }
            filtered.add(kept)
        }

        // 이미 긴 궤적에 쓰인 후보는 다시 시작점으로 쓰지 않는다 (시간 절약)
        val used = Array(frameCount) { BooleanArray(filtered[it].size) }

        var bestFrames: IntArray? = null
        var bestCandidates: IntArray? = null
        var bestScore = 0.0

        for (i in 0 until frameCount - 1) {
            for (a in filtered[i].indices) {
                if (used[i][a]) continue
                val first = filtered[i][a]

                val lastJ = if (i + 2 < frameCount - 1) i + 2 else frameCount - 1
                for (j in i + 1..lastJ) {
                    val dt = (frames[j].timeNs - frames[i].timeNs) / 1e9
                    if (dt <= 0.0) continue

                    for (b in filtered[j].indices) {
                        val second = filtered[j][b]
                        val vx = (second.x - first.x) / dt
                        val vy = (second.y - first.y) / dt
                        val speed = sqrt(vx * vx + vy * vy)

                        if (speed < settings.minSpeedPxPerSec) continue
                        if (speed > settings.maxSpeedPxPerSec) continue
                        // 옆에서 찍으므로 공은 주로 가로로 움직인다 (45도보다 가파르면 제외)
                        if (abs(vy) > abs(vx)) continue

                        val trackFrames = ArrayList<Int>()
                        val trackCandidates = ArrayList<Int>()
                        trackFrames.add(i); trackCandidates.add(a)
                        trackFrames.add(j); trackCandidates.add(b)

                        follow(frames, filtered, settings, j, second, vx, vy, dt, trackFrames, trackCandidates)

                        val hits = trackFrames.size
                        if (hits < settings.minHits) continue

                        if (hits >= 6) {
                            for (k in 0 until hits) {
                                used[trackFrames[k]][trackCandidates[k]] = true
                            }
                        }

                        // 점수 = 이어진 점 개수 + 이동 거리 보너스
                        val last = filtered[trackFrames[hits - 1]][trackCandidates[hits - 1]]
                        val dx = last.x - first.x
                        val dy = last.y - first.y
                        val distance = sqrt(dx * dx + dy * dy)
                        val score = hits + 0.05 * distance / settings.ballDiameterPx

                        if (score > bestScore) {
                            bestScore = score
                            bestFrames = trackFrames.toIntArray()
                            bestCandidates = trackCandidates.toIntArray()
                        }
                    }
                }
            }
        }

        val result = ArrayList<TrackPoint>()
        val finalFrames = bestFrames
        val finalCandidates = bestCandidates
        if (finalFrames != null && finalCandidates != null) {
            for (k in finalFrames.indices) {
                val frame = frames[finalFrames[k]]
                val candidate = filtered[finalFrames[k]][finalCandidates[k]]
                result.add(
                    TrackPoint(
                        frameIndex = frame.frameIndex,
                        timeNs = frame.timeNs,
                        x = candidate.x,
                        y = candidate.y,
                        isManual = false
                    )
                )
            }
        }
        return result
    }

    /** 시작 두 점 이후로 칼만 필터 예측을 따라가며 후보를 붙인다 */
    private fun follow(
        frames: List<FrameCandidates>,
        filtered: List<List<BallCandidate>>,
        settings: TrackerSettings,
        startFrame: Int,
        startCandidate: BallCandidate,
        startVx: Double,
        startVy: Double,
        startDt: Double,
        trackFrames: ArrayList<Int>,
        trackCandidates: ArrayList<Int>
    ) {
        val measurementNoise = 0.5
        val kalmanX = Kalman1D(startCandidate.x, startVx, measurementNoise, startDt)
        val kalmanY = Kalman1D(startCandidate.y, startVy, measurementNoise, startDt)

        var lastTimeNs = frames[startFrame].timeNs
        var missed = 0

        for (k in startFrame + 1 until frames.size) {
            // 실제 타임스탬프 차이를 쓰므로 프레임이 빠지거나 간격이 불규칙해도 예측이 맞는다
            val dt = (frames[k].timeNs - lastTimeNs) / 1e9
            if (dt <= 0.0) continue

            kalmanX.predict(dt, settings.accelNoisePxPerSec2)
            kalmanY.predict(dt, settings.accelNoisePxPerSec2)
            lastTimeNs = frames[k].timeNs

            val speed = sqrt(kalmanX.velocity * kalmanX.velocity + kalmanY.velocity * kalmanY.velocity)

            // 예측 위치에서 이 반경 안에 있는 후보만 같은 공으로 본다
            var gate = 2.5 * settings.ballDiameterPx
            if (gate < 5.0) gate = 5.0
            gate += 0.3 * speed * dt

            var bestIndex = -1
            var bestDistance = gate
            val candidates = filtered[k]
            for (c in candidates.indices) {
                val dx = candidates[c].x - kalmanX.position
                val dy = candidates[c].y - kalmanY.position
                val distance = sqrt(dx * dx + dy * dy)
                if (distance < bestDistance) {
                    bestDistance = distance
                    bestIndex = c
                }
            }

            if (bestIndex >= 0) {
                kalmanX.update(candidates[bestIndex].x)
                kalmanY.update(candidates[bestIndex].y)
                trackFrames.add(k)
                trackCandidates.add(bestIndex)
                missed = 0
            } else {
                missed++
                if (missed > settings.maxMissedFrames) break
            }
        }
    }
}

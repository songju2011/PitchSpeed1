package com.pitchspeed.app.data

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

/** 갤러리에서 고른 영상을 분석할 수 있게 준비한다 */
object VideoImporter {

    class ImportResult(
        val clip: ClipInfo,
        val firstFrame: Bitmap      // 거리 보정 화면에 띄울 첫 장면
    )

    /**
     * 영상을 앱 폴더로 복사하고, 시간 정보를 확인하고, 첫 장면을 뽑는다.
     * 백그라운드 스레드에서 불러야 한다. 실패하면 null.
     *
     * realFpsOverride: 사용자가 고른 "실제 촬영 fps". 0이면 자동 감지.
     *
     * 슬로모션 영상 주의:
     *   240fps로 찍었어도 파일 안에는 "30fps로 느리게 재생되는 영상"으로 저장되는 경우가 있다.
     *   그러면 영상 속 시간이 실제보다 8배 늘어나 있으므로, 그 비율(timeScale)을 구해서 바로잡는다.
     */
    fun prepare(context: Context, uri: Uri, realFpsOverride: Int): ImportResult? {
        try {
            // 1) 앱 폴더로 복사
            val directory = File(context.filesDir, "clips")
            directory.mkdirs()
            val file = File(directory, "import_" + System.currentTimeMillis() + ".mp4")
            val input = context.contentResolver.openInputStream(uri) ?: return null
            val output = FileOutputStream(file)
            input.copyTo(output)
            output.close()
            input.close()

            // 2) 영상 속 프레임 간격 (앞쪽 60프레임의 중앙값)
            val fileFps = measureFileFps(file.absolutePath)
            if (fileFps <= 0.0) {
                file.delete()
                return null
            }

            // 3) 촬영 fps 메타데이터와 첫 장면
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(file.absolutePath)
            var captureFps = 0.0
            val captureText = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
            if (captureText != null) {
                captureFps = captureText.toDoubleOrNull() ?: 0.0
            }
            val firstFrame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            retriever.release()
            if (firstFrame == null) {
                file.delete()
                return null
            }

            // 4) 시간 비율 결정
            var timeScale = 1.0
            if (realFpsOverride > 0) {
                timeScale = fileFps / realFpsOverride
            } else if (captureFps > fileFps * 1.5) {
                timeScale = fileFps / captureFps
            }
            val realFps = (fileFps / timeScale).roundToInt()

            val clip = ClipInfo(
                videoPath = file.absolutePath,
                isImported = true,
                clipPtsUs = null,
                clipTimesNs = null,
                timestampsExact = false,
                timeScale = timeScale,
                rollingShutterSkewNs = 0L,
                exposureNs = 0L,
                iso = 0,
                nominalFps = realFps
            )
            return ImportResult(clip, firstFrame)
        } catch (e: Exception) {
            return null
        }
    }

    /** 영상 파일에 기록된 프레임 시간으로 fps를 잰다 */
    private fun measureFileFps(path: String): Double {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(path)
            var trackIndex = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("video/")) {
                    trackIndex = i
                    break
                }
            }
            if (trackIndex < 0) return 0.0
            extractor.selectTrack(trackIndex)

            val times = ArrayList<Long>()
            while (times.size < 60) {
                val time = extractor.sampleTime
                if (time < 0) break
                times.add(time)
                if (!extractor.advance()) break
            }
            if (times.size < 3) return 0.0
            times.sort()

            val gaps = ArrayList<Long>()
            for (i in 0 until times.size - 1) {
                gaps.add(times[i + 1] - times[i])
            }
            gaps.sort()
            val medianGapUs = gaps[gaps.size / 2]
            if (medianGapUs <= 0) return 0.0
            return 1_000_000.0 / medianGapUs
        } catch (e: Exception) {
            return 0.0
        } finally {
            extractor.release()
        }
    }
}

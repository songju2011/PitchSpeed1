package com.pitchspeed.app.analysis

import kotlin.math.PI
import kotlin.math.sqrt

/**
 * 프레임 차분으로 공 후보를 찾는다.
 *
 * 입력은 연속한 세 프레임의 밝기(Y) 배열이다. (이전, 현재, 다음)
 * 1단계: "현재가 이전과도 다르고 다음과도 다른" 픽셀만 움직인 픽셀로 본다.
 *        (두 프레임만 비교하면 공이 떠난 자리도 같이 잡히는데, 세 프레임을 쓰면 그게 사라진다)
 * 2단계: 움직인 픽셀을 덩어리로 묶고, 크기가 공과 비슷한 것만 남긴다.
 * 3단계: 덩어리마다 밝기 가중 평균으로 서브픽셀 중심을 구하고, 원형도를 계산한다.
 */
class BallDetector(private val width: Int, private val height: Int) {

    /** 움직임으로 볼 최소 밝기 차이 (0~255) */
    var baseThreshold: Int = 12

    // 직전 프레임에서 잰 "평균 프레임 차이" — 센서 잡음 수준을 뜻한다
    private var noiseLevel: Double = 2.0

    // 움직인 픽셀 표시용 (1 = 움직임)
    private val mask = ByteArray(width * height)

    // 덩어리 채우기용 스택
    private val stack = IntArray(width * height)

    private val zero: Byte = 0
    private val one: Byte = 1

    fun detect(
        prev: ByteArray,
        cur: ByteArray,
        next: ByteArray,
        expectedDiameterPx: Double,
        maxCandidates: Int
    ): List<BallCandidate> {
        // 공이 5픽셀 이상으로 찍히면 2픽셀 간격으로 훑어서 시간을 아낀다 (중심 계산은 항상 원본 해상도)
        val step = if (expectedDiameterPx >= 5.0) 2 else 1
        val gridW = width / step
        val gridH = height / step

        // 잡음이 많은 영상에서는 임계값을 올린다
        var noiseTerm = (noiseLevel * 6.0).toInt() + 2
        if (noiseTerm > 40) noiseTerm = 40
        val threshold = if (baseThreshold > noiseTerm) baseThreshold else noiseTerm

        // ---------- 1단계: 움직인 픽셀 찾기 ----------
        var diffSum = 0L
        for (gy in 0 until gridH) {
            val rowStart = gy * step * width
            val maskRow = gy * gridW
            for (gx in 0 until gridW) {
                val idx = rowStart + gx * step
                val c = cur[idx].toInt() and 0xFF
                var d1 = c - (prev[idx].toInt() and 0xFF)
                if (d1 < 0) d1 = -d1
                diffSum += d1

                var moving = zero
                if (d1 > threshold) {
                    var d2 = c - (next[idx].toInt() and 0xFF)
                    if (d2 < 0) d2 = -d2
                    if (d2 > threshold) moving = one
                }
                mask[maskRow + gx] = moving
            }
        }
        noiseLevel = diffSum.toDouble() / (gridW * gridH)

        // ---------- 2단계: 덩어리로 묶기 ----------
        val maxDimPx = 3.0 * expectedDiameterPx + 6.0
        val maxDimCells = (maxDimPx / step).toInt() + 1
        val maxCells = maxDimCells * maxDimCells
        val expectedCells = PI * (expectedDiameterPx / 2.0) * (expectedDiameterPx / 2.0) / (step * step)
        var minCells = (expectedCells * 0.2).toInt()
        if (minCells < 2) minCells = 2

        val results = ArrayList<BallCandidate>()
        val totalCells = gridW * gridH

        for (start in 0 until totalCells) {
            if (mask[start] == zero) continue

            var top = 0
            stack[top] = start
            top++
            mask[start] = zero

            var count = 0
            var minX = gridW
            var maxX = -1
            var minY = gridH
            var maxY = -1

            while (top > 0) {
                top--
                val cell = stack[top]
                val cellX = cell % gridW
                val cellY = cell / gridW
                count++
                if (cellX < minX) minX = cellX
                if (cellX > maxX) maxX = cellX
                if (cellY < minY) minY = cellY
                if (cellY > maxY) maxY = cellY

                // 주변 8칸 확인
                for (ny in cellY - 1..cellY + 1) {
                    if (ny < 0 || ny >= gridH) continue
                    for (nx in cellX - 1..cellX + 1) {
                        if (nx < 0 || nx >= gridW) continue
                        val neighbor = ny * gridW + nx
                        if (mask[neighbor] != zero) {
                            mask[neighbor] = zero
                            stack[top] = neighbor
                            top++
                        }
                    }
                }
            }

            // 크기 필터: 너무 작으면 잡음, 너무 크면 사람 몸
            if (count < minCells || count > maxCells) continue
            if (maxX - minX + 1 > maxDimCells) continue
            if (maxY - minY + 1 > maxDimCells) continue

            // ---------- 3단계: 원본 해상도에서 중심·모양 계산 ----------
            val candidate = refine(
                prev, cur, next,
                minX * step - step - 1,
                minY * step - step - 1,
                maxX * step + step + 1,
                maxY * step + step + 1,
                threshold * 0.5,
                expectedDiameterPx,
                maxDimPx
            )
            if (candidate != null) {
                results.add(candidate)
            }
        }

        // 후보가 너무 많으면 대비가 큰 순서로 자른다
        if (results.size > maxCandidates) {
            results.sortByDescending { it.contrast * it.diameterMajor * it.diameterMinor }
            return ArrayList(results.subList(0, maxCandidates))
        }
        return results
    }

    /**
     * 상자 영역 안에서 밝기 가중 평균으로 서브픽셀 중심을 구한다.
     * 가중치 = |현재 밝기 - 배경 밝기|, 배경 = (이전 + 다음) / 2
     */
    private fun refine(
        prev: ByteArray,
        cur: ByteArray,
        next: ByteArray,
        boxLeft: Int,
        boxTop: Int,
        boxRight: Int,
        boxBottom: Int,
        weightThreshold: Double,
        expectedDiameterPx: Double,
        maxDimPx: Double
    ): BallCandidate? {
        val x0 = if (boxLeft < 0) 0 else boxLeft
        val y0 = if (boxTop < 0) 0 else boxTop
        val x1 = if (boxRight > width - 1) width - 1 else boxRight
        val y1 = if (boxBottom > height - 1) height - 1 else boxBottom

        var sumW = 0.0
        var sumWX = 0.0
        var sumWY = 0.0
        var sumWXX = 0.0
        var sumWYY = 0.0
        var sumWXY = 0.0
        var sumWBright = 0.0
        var pixelCount = 0

        for (y in y0..y1) {
            val row = y * width
            for (x in x0..x1) {
                val idx = row + x
                val c = cur[idx].toInt() and 0xFF
                val p = prev[idx].toInt() and 0xFF
                val n = next[idx].toInt() and 0xFF

                var dp = c - p
                if (dp < 0) dp = -dp
                var dn = c - n
                if (dn < 0) dn = -dn
                if (dp <= weightThreshold || dn <= weightThreshold) continue

                var w = c - (p + n) * 0.5
                if (w < 0) w = -w

                sumW += w
                sumWX += w * x
                sumWY += w * y
                sumWXX += w * x * x
                sumWYY += w * y * y
                sumWXY += w * x * y
                sumWBright += w * c
                pixelCount++
            }
        }

        if (pixelCount < 2 || sumW <= 0.0) return null

        val centerX = sumWX / sumW
        val centerY = sumWY / sumW

        // 2차 모멘트로 타원 모양을 구한다 (1/12는 픽셀 하나의 크기 보정)
        val varXX = sumWXX / sumW - centerX * centerX + 1.0 / 12.0
        val varYY = sumWYY / sumW - centerY * centerY + 1.0 / 12.0
        val varXY = sumWXY / sumW - centerX * centerY

        val halfTrace = (varXX + varYY) / 2.0
        val det = varXX * varYY - varXY * varXY
        var disc = halfTrace * halfTrace - det
        if (disc < 0.0) disc = 0.0
        val root = sqrt(disc)
        val lambdaBig = halfTrace + root
        var lambdaSmall = halfTrace - root
        if (lambdaSmall < 1e-6) lambdaSmall = 1e-6

        // 균일한 원판은 분산 = (반지름²)/4 이므로 지름 = 4 * sqrt(분산)
        val diameterMajor = 4.0 * sqrt(lambdaBig)
        val diameterMinor = 4.0 * sqrt(lambdaSmall)
        val circularity = sqrt(lambdaSmall / lambdaBig)

        // 모양 필터
        if (diameterMajor > maxDimPx) return null
        if (diameterMinor < expectedDiameterPx * 0.25) return null
        if (circularity < 0.3) return null   // 모션 블러로 살짝 길어지는 것까지는 허용

        return BallCandidate(
            x = centerX,
            y = centerY,
            diameterMajor = diameterMajor,
            diameterMinor = diameterMinor,
            circularity = circularity,
            brightness = sumWBright / sumW,
            contrast = sumW / pixelCount
        )
    }
}
